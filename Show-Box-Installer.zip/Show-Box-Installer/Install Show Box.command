#!/bin/bash
# Double-click to install or update Show Box (same as running install.sh).
cd "$(dirname "$0")" || exit 1
bash ./install.sh
echo
read -n 1 -s -r -p "Done. Press any key to close this window."

Show Box: install on the venue Mac (macOS 11 Big Sur or newer)

The Mac needs internet for the install and for entering the licence keys.
After that, shows run with no internet.

1. Double-click "Install Show Box" in this folder.
2. The first time, the Mac may say it can't check the file is safe.
   - macOS 14 or older: right-click (or Control-click) "Install Show Box",
     choose Open, then Open again.
   - macOS 15 or newer: click Done, open System Settings > Privacy &
     Security, scroll down and click "Open Anyway" next to "Install Show
     Box", then confirm with the Mac's password.
   (Only needed once per Mac.)
3. It downloads the app engine once (about 100 MB), installs "Show Box" in
   Applications, puts a shortcut on the Desktop and opens it.
4. In the Show Box, go to Admin > Licence > "Enter a licence key" and type
   your EntsOffice key (EO-XXXX-XXXX-XXXX-XXXX), then "Use this key".
   Each game has its own key: add them one at a time.

To update later, download the new installer and double-click "Install Show
Box" again. Your keys, saved lyric timings and settings are kept.

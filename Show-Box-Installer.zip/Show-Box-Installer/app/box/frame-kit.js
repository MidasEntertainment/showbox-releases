/* Show Box frame kit: the shared engine for seasonal frames (frames/<id>/index.html loads it from /box/frame-kit.js).
   Every frame has the same shape (Karl, 2026-11-02):
     - a border that is always there (draw), kept to the edges, nothing along the bottom unless the theme needs it
     - ambient life (optional): something slow that keeps the frame alive, e.g. balloons filling up
     - a small moment every couple of minutes (small)
     - a big moment every 4 to 7 minutes, one of several versions, each used once before any repeats (bigs)
   The operator's switch (showboxFrameAnim) stops everything but the border. Characters face the front; motion is smooth;
   nothing flashes more than 3 times a second. Only transforms and opacity are animated, so the graphics card does the work.
   Address options: ?anim=0, ?every=120, ?first=8, ?big=330, ?bigfirst=75, ?ambfirst=3 (seconds). */
(function () {
  window.FrameKit = function (cfg) {
    var q = new URLSearchParams(location.search), num = function (k, d) { return q.has(k) ? +q.get(k) : d; };
    var EVERY = num('every', cfg.every || 120), FIRST = num('first', 8), BIG = num('big', cfg.big || 330), BIGFIRST = num('bigfirst', 75), AMBFIRST = num('ambfirst', 3);
    var on = q.get('anim') !== '0';
    document.documentElement.style.cssText = 'margin:0;height:100%;background:transparent;overflow:hidden';
    var st = document.createElement('style');
    st.textContent = 'body{margin:0;height:100%;background:transparent;overflow:hidden}#fkBorder{position:fixed;inset:0;width:100%;height:100%;pointer-events:none}' +
      '#fkFx{position:fixed;inset:0;pointer-events:none;overflow:hidden}.fk{position:absolute;left:0;top:0;will-change:transform,opacity}.fk svg{display:block;overflow:visible}' + (cfg.css || '');
    document.head.appendChild(st);
    var under = document.createElement('div'); under.id = 'fkUnder'; under.style.cssText = 'position:fixed;inset:0;pointer-events:none';
    var border = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); border.id = 'fkBorder';
    var over = document.createElement('div'); over.id = 'fkOver'; over.style.cssText = 'position:fixed;inset:0;pointer-events:none;overflow:hidden';
    var fx = document.createElement('div'); fx.id = 'fkFx';
    document.body.appendChild(under); document.body.appendChild(border); document.body.appendChild(over); document.body.appendChild(fx);

    var live = [], timers = [];
    var k = {
      fx: fx, under: under, border: border, over: over, R: Math.random,
      between: function (a, b) { return a + (b - a) * Math.random(); },
      pick: function (a) { return a[Math.floor(Math.random() * a.length)]; },
      /* over: a layer above the border for decorations that move (lights, baubles, balloons); animating them there
         leaves the big border drawing alone so nothing has to be redrawn. The page gets class fkOff when animations are off. */
      /* a fixed "random" for the border, so it looks the same every time */
      seeded: function (seed) { var s = seed || 7; return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; },
      el: function (svg, w, h, parent) { var d = document.createElement('div'); d.className = 'fk'; d.innerHTML = svg; var s = d.querySelector('svg');
        if (s && w) { s.setAttribute('width', w); s.setAttribute('height', h || w); } (parent || fx).appendChild(d); return d; },
      anim: function (e, keys, o) { var a = e.animate(keys, o); live.push(a); return a; },
      go: function (d, keys, o) { var a = k.anim(d, keys, o); return a.finished.then(function () { d.remove(); }, function () { d.remove(); }); },
      T: function (x, y, r, s, sy) { return 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px) rotate(' + (r || 0).toFixed(1) + 'deg) scale(' + (s == null ? 1 : s) + (sy != null ? ',' + sy : '') + ')'; },
      path: function (n, f) { var p = []; for (var i = 0; i <= n; i++) p.push(f(i / n)); return p; },
      /* round off corners in a path so things glide instead of jerking */
      smooth: function (pts, passes) { for (var pass = 0; pass < (passes || 3); pass++) pts = pts.map(function (p, i) { if (!i || i === pts.length - 1) return p; var sx = 0, sy = 0, c = 0;
        for (var j = Math.max(0, i - 3); j <= Math.min(pts.length - 1, i + 3); j++) { sx += pts[j][0]; sy += pts[j][1]; c++; } return [sx / c, sy / c].concat(p.slice(2)); }); return pts; },
      /* follow a path (points evenly spaced in time): keyframes for an element of size w x h centred on the path; turn = point along the path (no sudden spins) */
      follow: function (pts, w, h, turn, extra) { var n = pts.length - 1, prev = null;
        return pts.map(function (p, i) { var r = 0;
          if (turn) { var a = pts[Math.max(0, i - 3)], b = pts[Math.min(n, i + 3)]; r = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI; if (prev != null) { while (r - prev > 180) r -= 360; while (r - prev < -180) r += 360; } prev = r; }
          var key = { transform: k.T(p[0] - w / 2, p[1] - h / 2, r + (p[2] || 0), p[3] == null ? 1 : p[3]), offset: i / n }; if (p[4] != null) key.opacity = p[4]; if (extra) extra(key, i / n); return key; }); },
      sleep: function (ms) { return new Promise(function (r, no) { var t = setTimeout(r, ms); live.push({ cancel: function () { clearTimeout(t); no(new Error('off')); } }); }); },
      later: function (fn, s) { timers.push(setTimeout(fn, s * 1000)); },
      get on() { return on; }
    };
    function size() { k.W = innerWidth; k.H = innerHeight; k.S = k.H / 1080; }
    function draw() { size(); border.setAttribute('viewBox', '0 0 ' + k.W + ' ' + k.H); border.innerHTML = cfg.draw ? cfg.draw(k) || '' : ''; document.documentElement.classList.toggle('fkOff', !on); if (cfg.bake) bake(); }
    /* bake: turn the drawn border into a plain picture once, so the screen never has to redraw thousands of shapes (or their shadows)
       while other things move. The live drawing stays (hidden) so its gradients can still be used by the moving parts. */
    var baked = document.createElement('img'), bakeUrl = null; baked.id = 'fkBaked'; baked.style.cssText = 'position:fixed;left:0;top:0;pointer-events:none;visibility:hidden';
    document.body.insertBefore(baked, over);
    function bake() { border.setAttribute('xmlns', 'http://www.w3.org/2000/svg'); border.setAttribute('width', k.W); border.setAttribute('height', k.H);
      var xml = new XMLSerializer().serializeToString(border), url = URL.createObjectURL(new Blob([xml], { type: 'image/svg+xml' }));
      baked.onload = function () { border.style.visibility = 'hidden'; baked.style.visibility = 'visible'; if (bakeUrl) URL.revokeObjectURL(bakeUrl); bakeUrl = url; };
      baked.width = k.W; baked.height = k.H; baked.src = url; }

    var deck = [];
    function big(which) { if (!on || !cfg.bigs || !cfg.bigs.length) return Promise.resolve();
      if (which == null) { if (!deck.length) { deck = cfg.bigs.map(function (f, i) { return i; }); for (var i = deck.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = deck[i]; deck[i] = deck[j]; deck[j] = t; } } which = deck.pop(); }
      return Promise.resolve().then(function () { return cfg.bigs[which](k); }).catch(function () {}); }
    function small() { return on && cfg.small ? Promise.resolve().then(function () { return cfg.small(k); }).catch(function () {}) : Promise.resolve(); }
    function nextSmall(first) { if (cfg.small) k.later(function () { small().then(function () { if (on) nextSmall(); }); }, first != null ? first : k.between(EVERY * .75, EVERY * 1.25)); }
    function nextBig(first) { if (cfg.bigs) k.later(function () { big().then(function () { if (on) nextBig(); }); }, first != null ? first : k.between(BIG * .75, BIG * 1.3)); }
    function start(first) { if (first) { nextSmall(FIRST); nextBig(BIGFIRST); if (cfg.ambient) k.later(function () { cfg.ambient(k); }, AMBFIRST); }
      else { nextSmall(6); nextBig(k.between(40, 70)); if (cfg.ambient) k.later(function () { cfg.ambient(k); }, 2); } }
    window.showboxFrameAnim = function (v) {
      v = !!v; if (v === on) return on; on = v;
      timers.forEach(clearTimeout); timers = []; live.splice(0).forEach(function (a) { try { a.cancel(); } catch (e) {} }); fx.innerHTML = '';
      document.documentElement.classList.toggle('fkOff', !on); if (cfg.onSwitch) cfg.onSwitch(k, on);
      if (on) start(false);
      return on;
    };
    addEventListener('resize', draw);
    draw(); if (cfg.init) cfg.init(k);
    if (on) start(true);
    /* for testing */
    window.__small = small; window.__big = big; window.__ambient = function () { return cfg.ambient && cfg.ambient(k); }; window.__kit = k;
    return k;
  };
})();

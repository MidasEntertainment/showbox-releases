/* Show Box guard: added by the Show Box to every show page it serves.
   - tells the relay what each device is (desk, stage or phone), so phones only get what they need
   - shows a small "Reconnecting" badge on phones and the iPad desk when the link to the Mac drops
   - keeps the iPad desk awake (a silent looping video, as Safari has no wake lock over plain http)
   - sends page errors to the Mac's log
   - on the Mac's own desk, shows Show Box warnings (only one screen found, stage closed) */
(function () {
  if (window.__showboxGuard) return; window.__showboxGuard = true;
  var h = location.hash.replace('#', '').split(/[?&]/)[0];
  var role = h === 'stage' ? 'stage' : (h === 'play' || h === 'phone') ? 'phone' : 'desk';
  var onMac = location.hostname === '127.0.0.1' || location.hostname === 'localhost';
  var inApp = /Electron/.test(navigator.userAgent);
  var show = location.pathname.split('/')[1] || '';

  /* ---------- relay: tag the connection, watch it ---------- */
  var Native = window.WebSocket, live = new Set(), everUp = false, downSince = Date.now();
  function Tagged(u, p) {
    var s = String(u);
    if (/\/live\?/.test(s) && !/[?&]role=/.test(s)) s += '&role=' + role;
    var ws = p === undefined ? new Native(s) : new Native(s, p);
    if (/\/live\?/.test(s)) {
      ws.addEventListener('open', function () { live.add(ws); everUp = true; downSince = 0; badge(); });
      ws.addEventListener('close', function () { live.delete(ws); if (!live.size && !downSince) downSince = Date.now(); badge(); });
    }
    return ws;
  }
  Tagged.prototype = Native.prototype;
  ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'].forEach(function (k) { Tagged[k] = Native[k]; });
  try { window.WebSocket = Tagged; } catch (e) {}

  /* ---------- the badge ---------- */
  var el = null;
  function badge() {
    if (role === 'stage') return;
    var down = !live.size && downSince && Date.now() - downSince > 2500;
    if (!down) { if (el) el.style.display = 'none'; return; }
    if (!document.body) return;
    if (!el) {
      el = document.createElement('div');
      el.setAttribute('role', 'status');
      el.style.cssText = 'position:fixed;left:50%;bottom:max(14px,env(safe-area-inset-bottom));transform:translateX(-50%);z-index:2147483647;max-width:92vw;' +
        'padding:10px 16px;border-radius:999px;background:rgba(20,10,40,.92);color:#fff;font:600 15px/1.3 Outfit,system-ui,sans-serif;text-align:center;' +
        'box-shadow:0 6px 24px rgba(0,0,0,.4);pointer-events:none;border:1px solid rgba(255,255,255,.18)';
      document.body.appendChild(el);
    }
    var long = Date.now() - downSince > 15000;
    el.textContent = !everUp || long
      ? (role === 'phone' ? 'Can’t reach the show. Check you’re on the park Wi-Fi, not mobile data.' : 'Can’t reach the Show Box. Check this device is on the same Wi-Fi as the show Mac.')
      : 'Reconnecting…';
    el.style.display = 'block';
  }
  setInterval(badge, 1000);
  /* when the page comes back from the background or the network returns, make sure it's live */
  window.addEventListener('pageshow', function (e) { if (e.persisted) location.reload(); });

  /* ---------- keep the iPad desk awake ---------- */
  if (role === 'desk' && !inApp && !onMac) {
    var v = null;
    var wake = function () {
      try { if (navigator.wakeLock && window.isSecureContext) navigator.wakeLock.request('screen').catch(function () {}); } catch (e) {}
      if (!v) {
        v = document.createElement('video');
        v.setAttribute('playsinline', ''); v.setAttribute('muted', ''); v.muted = true; v.loop = true; v.src = '/box/nosleep.mp4';
        v.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0.01;left:0;top:0;pointer-events:none';
        document.body.appendChild(v);
      }
      var p = v.play(); if (p && p.catch) p.catch(function () {});
    };
    ['pointerdown', 'touchend', 'keydown'].forEach(function (k) { document.addEventListener(k, wake, { capture: true, passive: true }); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden && v) wake(); });
  }

  /* ---------- anonymous show stats: games call showboxStat({...}) at the end of a game ----------
     Saved on the Mac. If this device can't reach the Mac (an iPad off the Wi-Fi), it keeps them and tries again. */
  var SQ = 'showbox-stats-queue';
  function sq() { try { return JSON.parse(localStorage.getItem(SQ)) || []; } catch (e) { return []; } }
  function flushStats() {
    var q = sq(); if (!q.length) return;
    fetch('/api/stats', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(q), keepalive: true })
      .then(function (r) { if (r.ok) { var left = sq().slice(q.length); try { localStorage.setItem(SQ, JSON.stringify(left)); } catch (e) {} } }).catch(function () {});
  }
  window.showboxStat = function (rec) {
    try { rec = Object.assign({ show: show, role: role }, rec); var q = sq(); q.push(rec); localStorage.setItem(SQ, JSON.stringify(q.slice(-500))); } catch (e) {}
    flushStats();
    if (rec && rec.kind === 'game') setTimeout(function () { window.showboxCheckReport && window.showboxCheckReport(); }, 4000);
  };
  setTimeout(flushStats, 3000); setInterval(flushStats, 60000);

  /* ---------- show report: after a show, the desk asks the operator a few quick questions ----------
     The Show Box decides when one is due (after a finished game, once per game per night; Kidz Karaoke after 20 quiet minutes). */
  var NAMES = { singo: 'Band-Bingo!', 'word-up': 'Word-Up!', 'think-you-know-me': 'Think You Know Me?', 'kidz-karaoke': 'Kidz Karaoke' };
  var Q = [
    { k: 'busy', q: 'How busy was it?', o: ['Under 10', '10–30', '30–60', '60–100', '100+'] },
    { k: 'ages', q: 'Who was watching or playing?', o: ['Mostly kids', 'Families', 'Mostly grown-ups'] },
    { k: 'stayed', q: 'Did everyone stay to the end?', o: ['Yes, nearly all', 'Most', 'About half', 'Only a few'] },
    { k: 'left', q: 'When did people start leaving?', o: ['Early on', 'Halfway', 'Near the end'], when: function (a) { return a.stayed && a.stayed !== 'Yes, nearly all'; } },
    { k: 'why', q: 'Why do you think they left? Pick any.', multi: true, o: ['Bedtime', 'Food or bar', 'Weather', 'Too long', 'Lost interest', 'Tech problem', 'Something else on', 'Not sure'], when: function (a) { return a.stayed && a.stayed !== 'Yes, nearly all'; } },
    { k: 'crowd', q: 'How much did the crowd love it?', stars: true },
    { k: 'smooth', q: 'How smoothly did it run for you?', stars: true },
    { k: 'tech', q: 'Any tech problems? Pick any.', multi: true, o: ['None', 'Phones or Wi-Fi', 'Sound', 'Screen', 'Show Box app', 'Other'] }
  ];
  var rp = null, due = null, ans = {};
  function snoozed(id) { try { return +localStorage.getItem('showbox-report-later-' + id) > Date.now(); } catch (e) { return false; } }
  function renderReport() {
    if (!rp) {
      rp = document.createElement('div'); rp.id = 'showboxReport';
      rp.style.cssText = 'position:fixed;inset:0;z-index:2147483645;overflow:auto;-webkit-overflow-scrolling:touch;background:rgba(8,4,22,.94);color:#f4f0ff;' +
        'font:500 16px/1.4 Outfit,system-ui,sans-serif;padding:clamp(12px,3vw,40px);box-sizing:border-box';
      var st = document.createElement('style');
      st.textContent = '#showboxReport .card{max-width:980px;margin:0 auto;background:#160d33;border:1px solid rgba(255,255,255,.14);border-radius:24px;padding:clamp(18px,3vw,36px);box-shadow:0 30px 80px rgba(0,0,0,.6)}' +
        '#showboxReport h2{font:900 clamp(24px,3vw,34px) Unbounded,system-ui;margin:0 0 6px}#showboxReport .sub{color:#b9b0dd;font-size:15px;margin:0 0 18px}' +
        '#showboxReport .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:4px 32px}' +
        '#showboxReport .q{margin:16px 0 8px;font-weight:700;font-size:17px}#showboxReport .ch{display:flex;flex-wrap:wrap;gap:8px}' +
        '#showboxReport .ch button{padding:11px 16px;min-height:44px;border-radius:999px;border:1px solid rgba(255,255,255,.25);background:transparent;color:#fff;font:600 16px Outfit,system-ui;cursor:pointer}' +
        '#showboxReport .ch button.on{background:#ff3d8b;border-color:#ff3d8b}#showboxReport .stars button{font-size:38px;line-height:1;padding:2px 6px;border:0;background:none;color:rgba(255,255,255,.28);cursor:pointer}' +
        '#showboxReport .stars button.on{color:#ffd23f}#showboxReport textarea{width:100%;box-sizing:border-box;min-height:80px;border-radius:14px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:#fff;font:inherit;padding:12px}' +
        '#showboxReport .acts{display:flex;gap:10px;margin-top:22px;flex-wrap:wrap;align-items:center;position:sticky;bottom:calc(-1 * clamp(12px,3vw,40px));background:#160d33;padding:14px 0;border-top:1px solid rgba(255,255,255,.1)}#showboxReport .acts button{padding:14px 22px;border-radius:14px;border:0;font:700 17px Outfit,system-ui;cursor:pointer;background:rgba(255,255,255,.12);color:#fff}' +
        '#showboxReport .acts .send{background:#ff3d8b;padding:14px 34px}#showboxReport .acts .send:disabled{opacity:.4}#showboxReport .acts .hint{color:#b9b0dd;font-size:14px}';
      rp.appendChild(st); var card = document.createElement('div'); card.className = 'card'; rp.appendChild(card);
      document.body.appendChild(rp);
    }
    var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var h = '<h2>Quick show report</h2><p class="sub">' + esc(NAMES[due.show] || due.show) + ' · ' + due.games + (due.show === 'kidz-karaoke' ? ' songs' : due.games === 1 ? ' game' : ' games') + ' · ' + due.minutes + ' min. Takes 30 seconds. No guest names, please.</p><div class="grid">';
    Q.forEach(function (x) {
      if (x.when && !x.when(ans)) return;
      h += '<div><div class="q">' + esc(x.q) + '</div>';
      if (x.stars) { h += '<div class="stars" data-k="' + x.k + '">'; for (var i = 1; i <= 5; i++) h += '<button data-v="' + i + '" class="' + (ans[x.k] >= i ? 'on' : '') + '" aria-label="' + i + ' out of 5">★</button>'; h += '</div></div>'; return; }
      h += '<div class="ch" data-k="' + x.k + '"' + (x.multi ? ' data-multi="1"' : '') + '>' + x.o.map(function (o) {
        var on = x.multi ? (ans[x.k] || []).indexOf(o) >= 0 : ans[x.k] === o; return '<button class="' + (on ? 'on' : '') + '" data-v="' + esc(o) + '">' + esc(o) + '</button>'; }).join('') + '</div></div>';
    });
    h += '</div><div class="q">Anything else we should know?</div><textarea id="sbNotes" maxlength="400" placeholder="What went well, what didn’t, ideas…">' + esc(ans.notes || '') + '</textarea>';
    h += '<div class="acts"><button class="send" ' + (ans.busy && ans.crowd ? '' : 'disabled title="Answer how busy it was and the crowd score first"') + '>Send report</button><button class="later">Remind me in 15 min</button><button class="skip">Skip tonight</button>' + (ans.busy && ans.crowd ? '' : '<span class="hint">Answer how busy it was and the crowd score to send.</span>') + '</div>';
    var sy = rp.scrollTop; rp.lastChild.innerHTML = h; rp.style.display = 'block'; rp.scrollTop = sy;
  }
  function closeReport() { if (rp) rp.style.display = 'none'; due = null; ans = {}; }
  function sendReport(skipped) {
    var d = due; if (!d) return;
    var notes = document.getElementById('sbNotes'); if (notes) ans.notes = notes.value;
    var r = { kind: 'report', id: d.id, game: d.id, start: d.start, end: Date.now(), completed: true, games: d.games, minutes: d.minutes, players: d.players, phones: d.phones };
    if (skipped) r.skipped = true;
    else Object.keys(ans).forEach(function (k) { r[k] = Array.isArray(ans[k]) ? ans[k].join(', ') : ans[k]; });
    window.showboxStat(r); closeReport();
  }
  function onReportClick(e) {
    var b = e.target.closest('button'); if (!b || !rp.contains(b)) return;
    var notes = document.getElementById('sbNotes'); if (notes) ans.notes = notes.value;
    if (b.classList.contains('send')) return sendReport(false);
    if (b.classList.contains('skip')) return sendReport(true);
    if (b.classList.contains('later')) { try { localStorage.setItem('showbox-report-later-' + due.id, Date.now() + 15 * 60000); } catch (x) {} return closeReport(); }
    var g = b.parentNode, k = g.getAttribute('data-k'), v = b.getAttribute('data-v');
    if (g.classList.contains('stars')) ans[k] = +v;
    else if (g.getAttribute('data-multi')) { var l = ans[k] || []; var i = l.indexOf(v); if (i >= 0) l.splice(i, 1); else { if (v === 'None' || v === 'Not sure') l = []; else l = l.filter(function (x) { return x !== 'None' && x !== 'Not sure'; }); l.push(v); } ans[k] = l; }
    else ans[k] = ans[k] === v ? undefined : v;
    renderReport();
  }
  function checkReport() {
    if (role !== 'desk' || !show || (due && rp && rp.style.display === 'block')) return;
    fetch('/api/stats/report-due?show=' + encodeURIComponent(show), { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) {
      var d = j && j.due; if (!d || snoozed(d.id) || !document.body) return;
      due = d; ans = {}; renderReport(); rp.onclick = onReportClick;
    }).catch(function () {});
  }
  if (role === 'desk' && show) { setTimeout(checkReport, 5000); setInterval(checkReport, 30000); }
  window.showboxCheckReport = checkReport;

  /* ---------- errors go to the Mac's log ---------- */
  var sent = 0;
  function report(msg, where) {
    if (++sent > 5) return;
    try {
      var body = JSON.stringify({ show: show, role: role, msg: String(msg).slice(0, 400), where: String(where || '').slice(0, 200), ua: navigator.userAgent });
      if (navigator.sendBeacon) navigator.sendBeacon('/api/log', new Blob([body], { type: 'application/json' }));
      else fetch('/api/log', { method: 'POST', body: body, keepalive: true }).catch(function () {});
    } catch (e) {}
  }
  window.addEventListener('error', function (e) { report(e.message, (e.filename || '').split('/').pop() + ':' + e.lineno); });
  window.addEventListener('unhandledrejection', function (e) { report('promise: ' + (e.reason && (e.reason.message || e.reason))); });

  /* ---------- seasonal frame switch on the desk (Mac desk and iPad) ----------
     Only appears when the Show Box has a frame installed. The frame itself is drawn by the Mac on top of the stage screen. */
  if (role === 'desk') {
    var fb = null, fm = null, fs = { current: null, frames: [] };
    var fesc = function (t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var fname = function () { var f = fs.frames.filter(function (x) { return x.id === fs.current; })[0]; return f ? f.name.split(':')[0] : 'Off'; };
    var fdraw = function () {
      if (!document.body || !fs.frames.length) { if (fb) fb.style.display = 'none'; return; }
      if (!fb) {
        var css = document.createElement('style');
        css.textContent = '#sbFrameBtn{position:fixed;right:14px;bottom:14px;z-index:2147483644;padding:8px 14px;border-radius:999px;border:1px solid rgba(255,255,255,.2);background:rgba(20,10,40,.88);color:#fff;font:700 13px Outfit,system-ui,sans-serif;cursor:pointer;opacity:.75;box-shadow:0 4px 16px rgba(0,0,0,.35)}' +
          '#sbFrameBtn:hover,#sbFrameBtn.on{opacity:1}#sbFrameBtn.on{background:#ff7a1a;border-color:#ff7a1a}' +
          '#sbFrameMenu{position:fixed;right:14px;bottom:56px;z-index:2147483644;min-width:240px;padding:8px;border-radius:16px;background:#160d33;border:1px solid rgba(255,255,255,.16);box-shadow:0 12px 40px rgba(0,0,0,.5);font:600 15px Outfit,system-ui,sans-serif;color:#fff}' +
          '#sbFrameMenu .t{font-size:12px;letter-spacing:1.5px;text-transform:uppercase;color:#b9b0dd;padding:6px 10px 8px}' +
          '#sbFrameMenu button{display:block;width:100%;text-align:left;padding:12px 12px;border:0;border-radius:10px;background:none;color:#fff;font:inherit;cursor:pointer}' +
          '#sbFrameMenu button:hover{background:rgba(255,255,255,.08)}#sbFrameMenu button.sel{background:#ff3d8b}' +
          '#sbFrameMenu .tog{display:flex;justify-content:space-between;align-items:center;gap:12px}#sbFrameMenu .sw{min-width:44px;text-align:center;padding:4px 10px;border-radius:999px;background:rgba(255,255,255,.14);font-size:13px}#sbFrameMenu .sw.on{background:#2ecc71;color:#0b2414}#sbFrameMenu .n{font-size:12px;color:#ffd23f;padding:6px 10px}';
        document.head.appendChild(css);
        fb = document.createElement('button'); fb.id = 'sbFrameBtn'; fb.type = 'button';
        fb.onclick = function (e) { e.stopPropagation(); fmenu(!fm || fm.style.display === 'none'); };
        document.body.appendChild(fb);
        document.addEventListener('click', function (e) { if (fm && !fm.contains(e.target)) fmenu(false); }, true);
      }
      var cf = fs.frames.filter(function (x) { return x.id === fs.current; })[0];
      fb.textContent = 'Frame: ' + fname() + (cf && cf.animations && !fs.anim ? ' (still)' : ''); fb.className = fs.current ? 'on' : ''; fb.style.display = 'block';
      if (fm && fm.style.display !== 'none') fmenu(true);
    };
    var fmenu = function (open) {
      if (!open) { if (fm) fm.style.display = 'none'; return; }
      if (!fm) { fm = document.createElement('div'); fm.id = 'sbFrameMenu'; document.body.appendChild(fm);
        fm.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; e.stopPropagation();
          if (b.hasAttribute('data-anim')) return fpost({ anim: !fs.anim }, false); fset(b.getAttribute('data-id') || null); }; }
      var curF = fs.frames.filter(function (x) { return x.id === fs.current; })[0];
      fm.innerHTML = '<div class="t">Frame on the stage screen</div>' + [{ id: '', name: 'No frame' }].concat(fs.frames).map(function (f) {
        return '<button type="button" data-id="' + fesc(f.id) + '" class="' + ((f.id || null) === fs.current ? 'sel' : '') + '">' + fesc(f.name) + '</button>'; }).join('') +
        (curF && curF.animations ? '<div class="t" style="padding-top:12px">Animations</div><button type="button" data-anim="1" class="tog">' + fesc(curF.animations) +
          '<span class="sw' + (fs.anim ? ' on' : '') + '">' + (fs.anim ? 'On' : 'Off') + '</span></button>' : '') +
        (fs.note ? '<div class="n">' + fesc(fs.note) + '</div>' : '');
      fm.style.display = 'block';
    };
    var fget = function () { fetch('/api/frame', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) { if (j && j.frames) { fs = j; fdraw(); } }).catch(function () {}); };
    var fpost = function (b, close) { fetch('/api/frame', { method: 'POST', body: JSON.stringify(b) }).then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.frames) fs = j; fdraw(); if (close && !fs.note) fmenu(false); }).catch(function () {}); };
    var fset = function (id) { fpost({ id: id }, true); };
    setTimeout(fget, 1500); setInterval(fget, 20000);
  }

  /* ---------- back to the Show Box dashboard (the Mac's own desk only; the show keeps running on the LED) ---------- */
  /* (inside the Show Box bar the bar has the button; this is for a desk opened on its own) */
  if (role === 'desk' && onMac && inApp && show && window.top === window) {
    var home = function () {
      if (!document.body || document.getElementById('sbHome')) return;
      var a = document.createElement('a'); a.id = 'sbHome'; a.href = '/'; a.title = 'Back to the Show Box dashboard (Cmd+Shift+H). The show stays on the stage screen.';
      a.setAttribute('aria-label', 'Back to the Show Box dashboard');
      a.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="flex:none"><rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/></svg><span>Show Box</span>';
      var st = document.createElement('style');
      /* a small round button in the corner; it opens out to "Show Box" when the mouse is on it, so it covers as little of the desk as possible */
      st.textContent = '#sbHome{position:fixed;left:8px;bottom:8px;z-index:2147483644;display:flex;align-items:center;gap:8px;height:38px;max-width:38px;padding:0 9px;box-sizing:border-box;overflow:hidden;white-space:nowrap;border-radius:999px;' +
        'border:1px solid rgba(255,255,255,.22);background:rgba(20,10,40,.9);color:#fff;font:700 13px Outfit,system-ui,sans-serif;text-decoration:none;opacity:.7;box-shadow:0 4px 18px rgba(0,0,0,.35);transition:max-width .2s,opacity .2s,background .2s}' +
        '#sbHome:hover,#sbHome:focus-visible{max-width:160px;opacity:1;background:#ff3d8b;border-color:#ff3d8b}';
      document.head.appendChild(st);
      document.body.appendChild(a);
    };
    if (document.body) home(); else document.addEventListener('DOMContentLoaded', home);
  }

  /* ---------- iPad desk: full screen (Karl 2026-11-02: the address bar and tabs stayed visible) ----------
     Uses the browser's full screen where it has one; otherwise explains Add to Home Screen, which opens the desk
     without any browser bars from then on. Not shown once it's already full screen or opened from the Home Screen. */
  if (role === 'desk' && !onMac && !inApp && show) {
    var standalone = function () { return navigator.standalone === true || (window.matchMedia && matchMedia('(display-mode: standalone), (display-mode: fullscreen)').matches); };
    var isFull = function () { return !!(document.fullscreenElement || document.webkitFullscreenElement) || standalone(); };
    var fsb = null, tip = null;
    var fsShow = function () {
      if (!document.body) return;
      if (!fsb) {
        fsb = document.createElement('button'); fsb.type = 'button'; fsb.id = 'sbFull';
        fsb.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg> Full screen';
        fsb.style.cssText = 'position:fixed;left:14px;bottom:14px;z-index:2147483644;display:flex;align-items:center;gap:8px;padding:10px 16px;border-radius:999px;border:1px solid rgba(255,255,255,.25);background:rgba(20,10,40,.92);color:#fff;font:700 15px Outfit,system-ui,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.4)';
        fsb.onclick = function () {
          var el = document.documentElement, rq = el.requestFullscreen || el.webkitRequestFullscreen, p = null;
          if (rq) { try { p = rq.call(el); } catch (e) { p = null; } }
          var fail = function () { if (!isFull()) showTip(); };
          if (p && p.then) p.then(function () { setTimeout(fail, 400); }, fail); else setTimeout(fail, 600);
        };
        document.body.appendChild(fsb);
      }
      fsb.style.display = isFull() ? 'none' : 'flex';
    };
    var showTip = function () {
      if (tip) { tip.style.display = 'block'; return; }
      tip = document.createElement('div');
      tip.style.cssText = 'position:fixed;left:14px;bottom:64px;z-index:2147483645;max-width:380px;padding:16px 18px;border-radius:16px;background:#160d33;border:1px solid rgba(255,255,255,.18);color:#f4f0ff;font:500 15px/1.45 Outfit,system-ui,sans-serif;box-shadow:0 12px 40px rgba(0,0,0,.5)';
      tip.innerHTML = '<b style="font-size:16px">Run this desk full screen</b><br>Tap the browser\'s <b>Share</b> button (the square with an arrow, top right), then <b>Add to Home Screen</b>. Open <b>Show Box</b> from the iPad\'s home screen and it fills the screen, with no address bar or tabs.<div style="margin-top:12px;text-align:right"><button type="button" style="padding:8px 16px;border-radius:999px;border:0;background:#ff3d8b;color:#fff;font:700 14px Outfit,system-ui,sans-serif">Got it</button></div>';
      tip.querySelector('button').onclick = function () { tip.style.display = 'none'; };
      document.body.appendChild(tip);
    };
    ['fullscreenchange', 'webkitfullscreenchange'].forEach(function (k) { document.addEventListener(k, fsShow); });
    setTimeout(fsShow, 1200); setInterval(fsShow, 5000);
  }

  /* ---------- Show Box warnings on the Mac's desk ---------- */
  if (role === 'desk' && onMac) {
    var wl = null, hidden = '';
    var check = function () {
      fetch('/api/health', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (hh) {
        var w = (hh && hh.warnings) || [];
        if (!document.body) return;
        if (!wl) {
          wl = document.createElement('div');
          wl.style.cssText = 'position:fixed;left:14px;bottom:' + (inApp && show && window.top === window ? 54 : 14) + 'px;z-index:2147483646;max-width:440px;padding:10px 16px;border-radius:14px;' +
            'background:#ffd23f;color:#1b1030;font:600 13px/1.35 Outfit,system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.35);cursor:pointer';
          wl.title = 'Click to hide';
          wl.onclick = function () { hidden = wl.textContent; wl.style.display = 'none'; };
          document.body.appendChild(wl);
        }
        wl.textContent = w.join(' ');
        wl.style.display = w.length && wl.textContent !== hidden ? 'block' : 'none';
      }).catch(function () {});
    };
    setTimeout(check, 2500); setInterval(check, 8000);
  }
})();

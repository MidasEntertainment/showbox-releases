/* Show Box fireworks: realistic fireworks drawn on a canvas, for seasonal frames (New Year's Eve, Bonfire Night...).
   Load after frame-kit.js: <script src="/box/fireworks.js"></script>, then var fw = Fireworks(k).
   What makes them look real (Karl 2026-11-02 asked for detail):
     - shells burst as a 3D sphere (so the edge looks denser), stars slow down with air drag and droop under gravity
     - every star leaves a glowing trail that fades; stars start white-hot, turn their colour, and die as a dim orange ember
     - types: peony, chrysanthemum (embers drip from each star), willow (long drooping gold trails that hang), crackle (stars split
       into tiny glittering sparks), ring, and a glitter that twinkles (never faster than 3 times a second)
     - rockets climb with a sparking tail and a slight wobble, and each burst leaves drifting smoke lit by its colour
     - a soft local glow at each burst, never a full-screen flash
   The canvas only exists while fireworks are in the air, so it costs nothing the rest of the time. */
(function () {
  window.Fireworks = function (k) {
    var cv, sm, ctx, sctx, parts = [], smoke = [], glows = [], raf = null, last = 0, pending = 0, done = [], R = Math.random, T = 0;
    function between(a, b) { return a + (b - a) * R(); }
    function ensure() {
      if (cv && cv.isConnected) return;
      sm = document.createElement('canvas'); cv = document.createElement('canvas');
      [sm, cv].forEach(function (c) { c.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none'; c.width = k.W; c.height = k.H; k.fx.appendChild(c); });
      ctx = cv.getContext('2d'); sctx = sm.getContext('2d'); parts = []; smoke = []; glows = [];
    }
    function hexRgb(h) { var n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
    function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
    var WHITE = [255, 250, 235], EMBER = [255, 120, 40];
    function star(o) { o.age = 0; o.px = o.x; o.py = o.y; parts.push(o); return o; }
    function colourAt(p, t) { /* white-hot, then the star's colour, then a dim ember */
      if (t < .08) return mix(WHITE, p.c, t / .08); if (t < .7) return p.c; return mix(p.c, EMBER, (t - .7) / .3); }

    var emitters = [];
    function step(dt) {
      T += dt;
      for (var e = emitters.length - 1; e >= 0; e--) { var em = emitters[e]; em.t += dt; if (em.t >= em.dur) { emitters.splice(e, 1); pending--; em.res(); continue; } em.fn(dt, em.t / em.dur, em.t); }
      /* trails: fade what is already drawn a little every frame */
      ctx.globalCompositeOperation = 'destination-out'; ctx.fillStyle = 'rgba(0,0,0,' + (1 - Math.exp(-dt * 7.5)).toFixed(3) + ')'; ctx.fillRect(0, 0, k.W, k.H);
      ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
      var add = [];
      for (var i = parts.length - 1; i >= 0; i--) { var p = parts[i];
        p.age += dt; var t = p.age / p.life;
        if (t >= 1) { if (p.onDie) p.onDie(p, add); parts.splice(i, 1); continue; }
        var dr = Math.exp(-p.drag * dt); p.vx *= dr; p.vy *= dr; p.vy += p.g * dt; p.px = p.x; p.py = p.y; p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.rocket) { p.x += Math.sin(p.age * 9 + p.ph) * 18 * k.S * dt;
          if (R() < dt * 60) add.push({ x: p.x, y: p.y, vx: between(-40, 40) * k.S, vy: between(20, 90) * k.S, drag: 2, g: 200 * k.S, life: between(.3, .7), c: [255, 200, 120], w: 1.4, a: .8 });
          if (p.vy > -60 * k.S || t > .98) { p.age = p.life; parts.splice(i, 1); if (p.onTop) p.onTop(p.x, p.y); continue; } }
        if (p.drip && R() < dt * p.drip) add.push({ x: p.x, y: p.y, vx: p.vx * .05, vy: p.vy * .05 + 10 * k.S, drag: 3, g: 60 * k.S, life: between(.5, 1.1) * (p.dripLife || 1), c: p.dripC || p.c, w: p.w * .6, a: .55 });
        var c = colourAt(p, t), a = (p.a || 1) * (t < .75 ? 1 : 1 - (t - .75) / .25);
        if (p.twinkle) a *= .35 + .65 * Math.max(0, Math.sin(T * Math.PI * 2 * p.twinkle + p.ph));
        ctx.strokeStyle = 'rgba(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ',' + a.toFixed(3) + ')'; ctx.lineWidth = (p.w || 2) * k.S;
        ctx.beginPath(); ctx.moveTo(p.seg ? p.seg[0] : p.px, p.seg ? p.seg[1] : p.py); ctx.lineTo(p.x, p.y); ctx.stroke();
        if (!p.flat && t < .5 && (p.w || 2) > 1.6) { ctx.fillStyle = 'rgba(255,255,255,' + (a * .5).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(p.x, p.y, (p.w || 2) * .8 * k.S, 0, 6.283); ctx.fill(); }
      }
      add.forEach(function (o) { star(o); });
      /* local glows where shells burst */
      for (i = glows.length - 1; i >= 0; i--) { var g = glows[i]; g.age += dt; var u = g.age / g.life; if (u >= 1) { glows.splice(i, 1); continue; }
        var al = .32 * (1 - u) * (1 - u), rr = g.r * (.6 + .4 * u), gr = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, rr);
        gr.addColorStop(0, 'rgba(' + g.c.join(',') + ',' + al + ')'); gr.addColorStop(1, 'rgba(' + g.c.join(',') + ',0)'); ctx.fillStyle = gr; ctx.fillRect(g.x - rr, g.y - rr, rr * 2, rr * 2); }
      /* smoke: drawn fresh each frame on its own canvas so it drifts without smearing */
      sctx.clearRect(0, 0, k.W, k.H);
      for (i = smoke.length - 1; i >= 0; i--) { var s = smoke[i]; s.age += dt; if (s.age < 0) continue; var v = s.age / s.life; if (v >= 1) { smoke.splice(i, 1); continue; }
        s.x += s.vx * dt; s.y += s.vy * dt; var r = s.r0 + (s.r1 - s.r0) * (1 - Math.pow(1 - v, 2)), al2 = s.a * Math.sin(Math.PI * Math.min(1, v * 1.4)) * (1 - v * .3), lit = Math.max(0, 1 - s.age / 1.2);
        var col = mix([150, 146, 160], s.c, lit * .6), gs = sctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, r);
        gs.addColorStop(0, 'rgba(' + (col[0] | 0) + ',' + (col[1] | 0) + ',' + (col[2] | 0) + ',' + al2.toFixed(3) + ')'); gs.addColorStop(1, 'rgba(' + (col[0] | 0) + ',' + (col[1] | 0) + ',' + (col[2] | 0) + ',0)');
        sctx.fillStyle = gs; sctx.fillRect(s.x - r, s.y - r, r * 2, r * 2); }
    }
    function loop(t) { var dt = last ? Math.min(.05, (t - last) / 1000) : 1 / 60; last = t; step(dt);
      if (parts.length || glows.length || smoke.length || pending > 0) raf = requestAnimationFrame(loop);
      else { raf = null; last = 0; cv.remove(); sm.remove(); done.splice(0).forEach(function (f) { f(); }); } }
    function run() { ensure(); if (!raf) raf = requestAnimationFrame(loop); }

    /* the shells */
    function sphere(n, f) { for (var i = 0; i < n; i++) { var u = R() * 2 - 1, th = R() * Math.PI * 2, s = Math.sqrt(1 - u * u); f(Math.cos(th) * s, u, i); } }
    var TYPES = {
      peony: function (x, y, c, sz) { sphere(Math.round(110 * sz), function (dx, dy, i) { var sp = 600 * k.S * sz * between(.92, 1.05);
        star({ x: x, y: y, vx: dx * sp, vy: dy * sp, drag: 2.3, g: 70 * k.S, life: between(1.5, 2), c: c[i % c.length], w: 2.4 }); }); },
      chrysanthemum: function (x, y, c, sz) { sphere(Math.round(95 * sz), function (dx, dy, i) { var sp = 640 * k.S * sz * between(.92, 1.05);
        star({ x: x, y: y, vx: dx * sp, vy: dy * sp, drag: 2.2, g: 80 * k.S, life: between(1.7, 2.2), c: c[i % c.length], w: 2.3, drip: 8, dripC: [255, 205, 120] }); }); },
      willow: function (x, y, c, sz) { sphere(Math.round(80 * sz), function (dx, dy) { var sp = 520 * k.S * sz * between(.9, 1.05);
        star({ x: x, y: y, vx: dx * sp, vy: dy * sp, drag: 1.7, g: 120 * k.S, life: between(3.6, 4.6), c: [255, 196, 96], w: 2.2, drip: 10, dripC: [255, 170, 70], dripLife: 2 }); }); },
      crackle: function (x, y, c, sz) { sphere(Math.round(70 * sz), function (dx, dy, i) { var sp = 560 * k.S * sz * between(.92, 1.05);
        star({ x: x, y: y, vx: dx * sp, vy: dy * sp, drag: 2.4, g: 70 * k.S, life: between(1, 1.25), c: c[i % c.length], w: 2.2,
          onDie: function (p, add) { for (var j = 0; j < 4; j++) { var a = R() * 6.283, v = between(40, 110) * k.S;
            add.push({ x: p.x, y: p.y, vx: Math.cos(a) * v + p.vx * .3, vy: Math.sin(a) * v + p.vy * .3, drag: 2.5, g: 90 * k.S, life: between(.5, .9), c: [255, 248, 230], w: 1.5, twinkle: between(1.8, 2.8), ph: R() * 6 }); } } }); }); },
      ring: function (x, y, c, sz) { var tilt = between(.3, .8), rot = between(0, Math.PI), n = Math.round(70 * sz);
        for (var i = 0; i < n; i++) { var a = i / n * 6.283, ex = Math.cos(a), ey = Math.sin(a) * tilt, sp = 520 * k.S * sz;
          star({ x: x, y: y, vx: (ex * Math.cos(rot) - ey * Math.sin(rot)) * sp, vy: (ex * Math.sin(rot) + ey * Math.cos(rot)) * sp, drag: 2.3, g: 60 * k.S, life: between(1.5, 1.8), c: c[i % c.length], w: 2.4 }); }
        TYPES.peony(x, y, [[255, 250, 235]], .35); },
      glitter: function (x, y, c, sz) { sphere(Math.round(90 * sz), function (dx, dy, i) { var sp = 580 * k.S * sz * between(.9, 1.05);
        star({ x: x, y: y, vx: dx * sp, vy: dy * sp, drag: 2.1, g: 90 * k.S, life: between(2, 2.6), c: c[i % c.length], w: 1.9, twinkle: between(1.5, 2.8), ph: R() * 6 }); }); }
    };
    function burst(type, x, y, cols, size) { var c = cols.map(function (h) { return typeof h === 'string' ? hexRgb(h) : h; }), sz = size || 1;
      (TYPES[type] || TYPES.peony)(x, y, c, sz);
      glows.push({ x: x, y: y, r: 340 * k.S * sz, c: c[0].map(function (v) { return v | 0; }), age: 0, life: .9 });
      for (var i = 0; i < 6; i++) smoke.push({ x: x + between(-120, 120) * k.S * sz, y: y + between(-80, 120) * k.S * sz, vx: between(6, 22) * k.S, vy: between(-8, 6) * k.S, r0: 40 * k.S, r1: between(170, 260) * k.S * sz, a: between(.07, .12), c: c[0], age: -between(.2, .6), life: between(6, 9) }); }
    /* launch(x0: where it leaves the ground, x, y: where it bursts, type, colours, size, delay ms) -> promise when it bursts */
    function launch(o) { pending++; return k.sleep(o.delay || 0).then(function () { run();
        return new Promise(function (res) { var dy = (k.H + 10) - o.y, v = Math.sqrt(2 * 380 * k.S * dy) * 1.06, dur = v / (380 * k.S);
          star({ x: o.x0 == null ? o.x : o.x0, y: k.H + 10, vx: ((o.x - (o.x0 == null ? o.x : o.x0)) / dur), vy: -v, drag: 0, g: 380 * k.S, life: dur * 1.2, c: [255, 225, 170], w: 2.6, rocket: true, ph: R() * 6,
            onTop: function (bx, by) { burst(o.type, bx, by, o.cols, o.size); pending--; res(); } }); }); }, function () { pending--; }); }
    function finished() { return new Promise(function (res) { if (!raf && pending <= 0) res(); else done.push(res); }); }
    /* emit(ms, fn(dt, progress, seconds)): call fn every frame for a while; fn adds stars with spark() -> promise when it ends */
    function emit(ms, fn, delay) { pending++; return k.sleep(delay || 0).then(function () { run(); return new Promise(function (res) { emitters.push({ t: 0, dur: ms / 1000, fn: fn, res: res }); }); }, function () { pending--; }); }
    function spark(o) { if (typeof o.c === 'string') o.c = hexRgb(o.c); return star(o); }
    function glow(x, y, r, c, life) { glows.push({ x: x, y: y, r: r, c: typeof c === 'string' ? hexRgb(c) : c, age: 0, life: life || .9 }); }
    return { emit: emit, spark: spark, glow: glow, hex: hexRgb, launch: launch, burst: function (t, x, y, c, s) { run(); burst(t, x, y, c, s); }, finished: finished };
  };
})();

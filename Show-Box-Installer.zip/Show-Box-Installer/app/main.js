/* Show Box: runs the park shows on one Mac, offline.
   - the web server and relay live in server.js (see there)
   - opens the desk on the operator screen and the stage fullscreen on the LED screen, with sound allowed
   - keeps both windows running at full speed even when hidden behind QLab, and reloads them if they crash or hang
   An iPad on the same Wi-Fi opens http://<mac>:8737/<name>/ to run the show. */
const { app, BrowserWindow, screen, Menu, dialog, powerSaveBlocker, shell } = require('electron');
const fs = require('fs'), path = require('path');
const { createBox } = require('./server');

const PORT = 8737;
const SHOW_NAMES = { 'kidz-karaoke': 'Kidz Karaoke', 'word-up': 'Word-Up!', 'think-you-know-me': 'Think You Know Me?', 'singo': 'Band-Bingo!', 'muiz': 'Muiz' };

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
/* Chrome slows down windows that are hidden or covered (by QLab, say). The desk runs the show clocks, so never slow it. */
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
/* macOS: Chrome stops drawing a window it thinks is covered. The seasonal frame is a see-through window lying over the whole LED,
   so the stage counted as covered: it kept its first picture and never updated (Karl 2026-11-02: holding screen showed, the game
   didn't play). Never treat a window as covered. (CalculateNativeWinOcclusion is the same thing on Windows.) */
app.commandLine.appendSwitch('disable-features', 'MacWebContentsOcclusion,CalculateNativeWinOcclusion');
if (!app.requestSingleInstanceLock()) { app.quit(); }

/* ---------- settings (kept in the Mac's app data folder) ---------- */
let DATA, box, cfg = { show: '', stageDisplay: null, stageLabel: '', stageSize: '', deskDisplay: null, deskLabel: '', deskSize: '', frame: null, frameAnim: true };
function loadCfg() { try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(path.join(DATA, 'config.json'), 'utf8')) }; } catch (e) {} }
function saveCfg() { try { fs.writeFileSync(path.join(DATA, 'config.json') + '.tmp', JSON.stringify(cfg, null, 1)); fs.renameSync(path.join(DATA, 'config.json') + '.tmp', path.join(DATA, 'config.json')); } catch (e) {} }
const log = (...a) => box ? box.log(...a) : console.log(...a);
process.on('uncaughtException', e => log('main error', String(e && e.stack || e)));
process.on('unhandledRejection', e => log('main rejection', String(e && e.stack || e)));

/* ---------- screens ---------- */
const dLabel = (d, i) => d.label || `Screen ${i + 1}`;
const dSize = d => `${d.size.width}x${d.size.height}`;
/* The stage screen is remembered by its id, and by name and size too: macOS can hand a screen a new id after a reboot or a different cable. */
function stageDisplay() {
  const all = screen.getAllDisplays(), prim = screen.getPrimaryDisplay();
  return all.find(d => d.id === cfg.stageDisplay)
    || (cfg.stageLabel && all.find(d => d.label === cfg.stageLabel && dSize(d) === cfg.stageSize))
    || (cfg.stageLabel && all.find(d => d.label === cfg.stageLabel))
    /* first time: a screen that isn't the laptop's own; on a Mac mini with two monitors, the one that isn't the main display */
    || all.find(d => !d.internal && d.id !== prim.id) || all.find(d => !d.internal && all.some(x => x.internal))
    || all.find(d => d.id !== prim.id) || prim;
}
/* The desk goes on the screen picked on the dashboard; otherwise on whichever screen isn't the stage, so they never land on the same one
   when the LED is set as the main display. */
function deskDisplay() {
  const all = screen.getAllDisplays(), s = stageDisplay(); if (all.length < 2) return screen.getPrimaryDisplay();
  const picked = all.find(d => d.id === cfg.deskDisplay) || (cfg.deskLabel && all.find(d => d.label === cfg.deskLabel && dSize(d) === cfg.deskSize));
  if (picked && picked.id !== s.id) return picked;
  return all.find(d => d.id !== s.id && d.id === screen.getPrimaryDisplay().id) || all.find(d => d.id !== s.id);
}
function rememberStage(d) { cfg.stageDisplay = d.id; cfg.stageLabel = d.label || ''; cfg.stageSize = dSize(d); saveCfg(); }
function rememberDesk(d) { cfg.deskDisplay = d.id; cfg.deskLabel = d.label || ''; cfg.deskSize = dSize(d); saveCfg(); }
function stageDisplayId() { if (!stageWin || stageWin.isDestroyed()) return null; return screen.getDisplayMatching(stageWin.getBounds()).id; }
function warnings() {
  const w = [], all = screen.getAllDisplays();
  if (all.length < 2) w.push('Only one screen found, so the stage screen is not showing. Check the HDMI cable to the stage screen, and turn off Mirror Displays in System Settings > Displays.');
  if (stageBlank && stageWin && !stageWin.isDestroyed()) w.push('The stage screen looks black. Press "Restart the stage screen" on the Show Box Operator Desk.');
  return w;
}

/* ---------- windows ---------- */
let deskWin = null, stageWin = null;
const base = () => `http://127.0.0.1:${PORT}`;
/* If a window's page crashes, reload it. If it stops answering for 20 seconds, restart it.
   (The games save their state as they go, so the show carries on where it was.) */
function guard(win, name) {
  const wc = win.webContents; let asked = 0, restarting = false;
  const restart = why => { if (restarting || win.isDestroyed()) return; restarting = true; log(name, 'restarting:', why);
    try { wc.forcefullyCrashRenderer(); } catch (e) {} setTimeout(() => { restarting = false; asked = 0; if (!win.isDestroyed()) wc.reload(); }, 800); };
  wc.on('render-process-gone', (e, d) => { log(name, 'page gone', d && d.reason); if (restarting || (d && d.reason === 'clean-exit')) return; setTimeout(() => { asked = 0; if (!win.isDestroyed()) wc.reload(); }, 1000); });
  win.on('unresponsive', () => log(name, 'not responding'));
  const dog = setInterval(() => {
    if (win.isDestroyed()) return clearInterval(dog);
    if (restarting || wc.isLoading() || wc.isCrashed()) return;
    if (asked && Date.now() - asked > 20000) return restart('page frozen for 20 s');
    if (asked) return;
    asked = Date.now(); wc.executeJavaScript('1', true).then(() => { asked = 0; }).catch(() => { asked = 0; });
  }, 4000);
  wc.on('did-fail-load', (e, code, desc, u, main) => { if (!main || code === -3) return; log(name, 'load failed', code, desc); setTimeout(() => { if (!win.isDestroyed()) wc.reload(); }, 2000); });
  wc.on('console-message', (e, level, message, line, src) => { if (level >= 3) log(name, 'console error', String(message).slice(0, 300), (src || '').split('/').pop() + ':' + line); });
}
function openDesk(home, fresh) {
  const d = deskDisplay().workArea;
  if (!deskWin || deskWin.isDestroyed()) {
    deskWin = new BrowserWindow({ x: d.x, y: d.y, width: d.width, height: d.height, backgroundColor: '#0e0824', title: 'Show Box', webPreferences: { contextIsolation: true, backgroundThrottling: false } });
    deskWin.on('closed', () => { deskWin = null; });
    deskWin.webContents.on('did-navigate', (e, to) => deskNavigated(to));
    guard(deskWin, 'desk');
    deskWin.webContents.setWindowOpenHandler(({ url: to }) => {
      if (/#stage\b/.test(to)) { openStage(); return { action: 'deny' }; }
      if (to.startsWith(base())) return { action: 'allow', overrideBrowserWindowOptions: { webPreferences: { backgroundThrottling: false } } };
      shell.openExternal(to); return { action: 'deny' };
    });
  }
  deskWin.loadURL(home ? `${base()}/` : `${base()}/desk/${cfg.show}/${fresh ? '?fresh=1' : ''}`);   /* fresh: Load show starts a new show on its holding screen */
}
/* The desk starts on the Show Box dashboard. Starting a show there loads that show's desk and, if a stage screen is set up,
   opens that show's stage. Going back to the dashboard leaves the show on the LED; "End show" closes it.
   (Karl 2026-11-02: no show should take over the stage by itself; the Show Box is the operator's hub.) */
/* On the Mac a show's desk sits inside the Show Box bar: /desk/<show>/ (an iPad opens /<show>/ directly) */
function showOfUrl(u) { try { const seg = new URL(u).pathname.split('/').map(x => decodeURIComponent(x)); return seg[1] === 'desk' ? seg[2] || '' : seg[1] || ''; } catch (e) { return null; } }
const onShow = () => { try { return !!deskWin && box.shows().includes(showOfUrl(deskWin.webContents.getURL())); } catch (e) { return false; } };
function deskNavigated(to) {
  const first = showOfUrl(to); if (first === null) return;
  if (!first) { setTimeout(() => box.packs.applyWaiting(), 500); return; }   /* the dashboard: whatever is on the LED stays on (End show there closes it); a game update that was waiting can go in now */
  if (!box.shows().includes(first)) return;
  if (!box.licence.canServe(first)) return;   /* its "not in your package" page: nothing is loaded */
  if (first !== cfg.show) { cfg.show = first; saveCfg(); buildMenu(); }
  loadedShow = first;
  /* Loading a show opens its desk only, so the operator can set it up (names, timings) first. The show goes up on the LED when
     they press "Put on the LED" in the Show Box bar, or the show's own "Open stage screen". (Karl 2026-11-02) */
}
let stageWanted = false, loadedShow = null;   /* the operator put the show on the LED (so a screen coming back reopens it) */
function stageOn() { if (!box.shows().includes(cfg.show)) return { ok: false };
  if (!box.licence.canServe(cfg.show)) return { ok: false, error: box.licence.canLoad(cfg.show).text };
  stageWanted = true;
  if (screen.getAllDisplays().length < 2 && cfg.stageDisplay !== screen.getPrimaryDisplay().id) return { ok: false, error: 'No stage screen connected.' };
  openStage(); return { ok: true }; }
function placeDesk() { if (!deskWin || deskWin.isDestroyed()) return; const d = deskDisplay(); if (screen.getDisplayMatching(deskWin.getBounds()).id !== d.id) deskWin.setBounds(d.workArea); }
/* The stage fades in over whatever was on the LED (QLab, the desktop) instead of snapping on, and fades out when the show ends.
   (Karl 2026-11-02.) Window opacity works on Mac and Windows; elsewhere it simply appears. */
const FADE_IN_MS = 1500, FADE_OUT_MS = 900;
function fadeWin(w, to, ms, done) {
  if (!w || w.isDestroyed()) { done && done(); return; }
  clearInterval(w._fadeT); const from = w.getOpacity(), t0 = Date.now();
  if (from === to) { done && done(); return; }
  w._fadeT = setInterval(() => {
    if (w.isDestroyed()) { clearInterval(w._fadeT); return; }
    const k = Math.min(1, (Date.now() - t0) / ms), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;   /* ease in and out */
    w.setOpacity(from + (to - from) * e);
    if (k >= 1) { clearInterval(w._fadeT); done && done(); }
  }, 16);
}
function fadeStage(to, ms, done) { fadeWin(stageWin, to, ms, done); }
function openStage() {
  if (!box.licence.canServe(cfg.show)) { log('stage not opened: licence does not cover', cfg.show); return; }
  const d = stageDisplay(), b = d.bounds; stageWanted = true;
  if (stageWin && !stageWin.isDestroyed() && stageWin.ending) { clearInterval(stageWin._fadeT); stageWin.destroy(); stageWin = null; }   /* a show was fading out: start fresh */
  if (stageWin && !stageWin.isDestroyed()) {
    const want = `${base()}/${cfg.show}/#stage`;
    if (stageDisplayId() !== d.id) placeStage(b);
    stageWin.showInactive(); placeDesk(); placeFrame();
    if (stageWin.webContents.getURL() !== want) {   /* another show: fade the old one out, load, fade the new one in */
      fadeStage(0, FADE_OUT_MS, () => { if (!stageWin || stageWin.isDestroyed()) return;
        stageWin.webContents.once('did-finish-load', () => setTimeout(() => fadeStage(1, FADE_IN_MS), 500));
        stageWin.loadURL(want); });
    } else fadeStage(1, FADE_IN_MS);
    return;
  }
  stageWin = new BrowserWindow({ x: b.x, y: b.y, width: b.width, height: b.height, frame: false, show: false, opacity: 0, backgroundColor: '#000000', title: 'Stage',
    hasShadow: false, resizable: false, movable: false, minimizable: false, maximizable: false, roundedCorners: false, autoHideMenuBar: true, enableLargerThanScreen: true, webPreferences: { contextIsolation: true, backgroundThrottling: false } });
  { const me = stageWin; me.on('closed', () => { if (stageWin === me) stageWin = null; }); }
  guard(stageWin, 'stage');
  stageWin.webContents.on('did-finish-load', () => { stageWin && stageWin.webContents.insertCSS('html,body,*{cursor:none!important}::-webkit-scrollbar{display:none}').catch(() => {}); });
  /* show the window first, then make it full screen: going full screen while still hidden can leave a black window on some Macs */
  stageWin.once('ready-to-show', () => { stageWin.showInactive(); setTimeout(() => { if (!stageWin || stageWin.isDestroyed()) return;
    placeStage(stageDisplay().bounds); stageWin.webContents.invalidate(); placeDesk(); placeFrame(); if (deskWin) deskWin.focus(); stageReport();
    setTimeout(() => fadeStage(1, FADE_IN_MS), 450); }, 250); });   /* give the holding screen a moment to draw, then fade it in */
  stageWin.webContents.on('did-finish-load', () => { clearTimeout(blankTimer); blankTimer = setTimeout(checkBlank, 5000); });
  stageBlank = false; blankTries = 0;
  stageWin.loadURL(`${base()}/${cfg.show}/#stage`);
}
/* Is the LED actually showing something? Look at the stage window's picture a few seconds after it loads. Every show's stage has a
   bright holding screen, so an all-black picture means something went wrong: reload once, then warn on the desk. */
let stageBlank = false, blankTries = 0, blankTimer = null;
function checkBlank() {
  if (!stageWin || stageWin.isDestroyed()) return;
  stageWin.webContents.capturePage().then(img => {
    if (!stageWin || stageWin.isDestroyed()) return;
    const sz = img.getSize(), bmp = img.toBitmap(); let max = 0;
    if (!sz.width || !bmp.length) { log('stage check: no picture', JSON.stringify(stageWin.getBounds())); return; }
    for (let i = 0; i < bmp.length; i += 4 * 97) { const v = Math.max(bmp[i], bmp[i + 1], bmp[i + 2]); if (v > max) max = v; if (max > 40) break; }
    const blank = max <= 40;
    /* what the stage page itself has drawn, next to the log (to compare with what the LED shows) */
    try { fs.writeFileSync(path.join(DATA, 'logs', 'stage-snapshot.jpg'), img.resize({ width: 640 }).toJPEG(70)); } catch (e) {}
    log('stage check:', blank ? 'BLACK' : 'ok', 'brightest', max, stageReport(true));
    stageWin.webContents.executeJavaScript('document.visibilityState', true).then(v => log('stage page is', v)).catch(() => {});
    stageBlank = blank;
    if (blank && blankTries++ < 1) { log('stage looks black: reloading it'); stageWin.webContents.reload(); }
  }).catch(e => log('stage check failed', String(e)));
}
/* every minute: is the stage page being drawn? ("hidden" means macOS has paused it). Logged when it changes. */
let lastVis = '';
setInterval(() => { if (!stageWin || stageWin.isDestroyed()) { lastVis = ''; return; }
  stageWin.webContents.executeJavaScript('document.visibilityState', true).then(v => { if (v !== lastVis) { lastVis = v; log('stage page now', v); } }).catch(() => {}); }, 60000).unref();
/* one line in the log about where the stage window is and what state it's in (to sort out a black LED from afar) */
function stageReport(text) {
  if (!stageWin || stageWin.isDestroyed()) return '';
  const d = screen.getDisplayMatching(stageWin.getBounds()), all = screen.getAllDisplays();
  const r = `stage window ${JSON.stringify(stageWin.getBounds())} on ${dLabel(d, all.findIndex(x => x.id === d.id))} ${dSize(d)} (wanted ${stageDisplay().id === d.id ? 'yes' : 'NO'}), visible ${stageWin.isVisible()}, ${STAGE_AS_WINDOW ? 'window over the screen, on top ' + stageWin.isAlwaysOnTop() : 'full ' + stageWin.isFullScreen()}, url ${stageWin.webContents.getURL().replace(base(), '')}`;
  if (!text) log(r); return r;
}
function screensSig() { return screen.getAllDisplays().map(d => [d.id, d.bounds.x, d.bounds.y, d.bounds.width, d.bounds.height, d.scaleFactor, d.rotation].join(',')).join('|'); }
/* On the Mac the stage is NOT made "full screen": it is a plain borderless window laid exactly over the LED, above the menu bar
   and Dock, the same way the seasonal frame is (and the frame always drew fine on Karl's Mac). Mac "simple full screen" on the
   second screen froze the stage on its very first picture, before the show had drawn anything (Karl 2026-11-02, screen
   recording: an empty dark screen while the desk ran the game). Elsewhere (Windows) normal full screen. */
const STAGE_AS_WINDOW = process.platform === 'darwin' || !!process.env.SB_STAGE_WINDOW;
function placeStage(b) {
  if (!stageWin || stageWin.isDestroyed()) return;
  const now = stageWin.getBounds(), same = now.x === b.x && now.y === b.y && now.width === b.width && now.height === b.height;
  if (STAGE_AS_WINDOW) {
    if (!same) stageWin.setBounds(b);
    stageWin.setAlwaysOnTop(true, 'status');   /* over the menu bar and Dock; the frame (screen-saver level) stays above it */
    try { stageWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true }); } catch (e) {}
    placeFrame(); return;
  }
  const full = stageWin.isFullScreen();
  if (full && same) return;   /* already right: don't flip full screen off and on */
  /* safety net: never flip the stage more than 4 times in 10 seconds, whatever asks for it */
  const t = Date.now(); placeStage.times = (placeStage.times || []).filter(x => t - x < 10000); if (placeStage.times.length >= 4) { log('stage placing paused: too many in 10 s'); return; } placeStage.times.push(t);
  stageWin.setFullScreen(false); stageWin.setBounds(b); stageWin.setFullScreen(true);
}
/* ---------- seasonal frame: a see-through, click-through window on top of everything on the stage screen ----------
   It sits above our own stage and above anything else shown there (QLab, videos, slides), and never takes a click or the keyboard. */
let frameWin = null;
const oneScreen = () => screen.getAllDisplays().length < 2 && cfg.stageDisplay !== screen.getPrimaryDisplay().id;
/* The frame fades in when it's switched on, fades out when it's switched off, and cross-fades (out, then the new one in)
   when the theme changes. (Karl 2026-11-02) */
const FRAME_IN_MS = 1400, FRAME_OUT_MS = 1000;
function showFrame() {
  const id = cfg.frame;
  if (!id || oneScreen()) { const w = frameWin; frameWin = null; if (w && !w.isDestroyed()) fadeWin(w, 0, FRAME_OUT_MS, () => { if (!w.isDestroyed()) w.destroy(); }); return; }
  const b = stageDisplay().bounds, want = `${base()}/frames/${id}/?anim=${cfg.frameAnim === false ? 0 : 1}`;
  if (frameWin && !frameWin.isDestroyed()) { placeFrame();
    if (frameWin.webContents.getURL().split('?')[0] !== want.split('?')[0]) { const w = frameWin;
      fadeWin(w, 0, FRAME_OUT_MS, () => { if (w.isDestroyed()) return; w.webContents.once('did-finish-load', () => setTimeout(() => fadeWin(w, 1, FRAME_IN_MS), 300)); w.loadURL(want); }); }
    else fadeWin(frameWin, 1, FRAME_IN_MS);
    return; }
  frameWin = new BrowserWindow({ x: b.x, y: b.y, width: b.width, height: b.height, transparent: true, backgroundColor: '#00000000', frame: false, hasShadow: false, opacity: 0,
    resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false, focusable: false, skipTaskbar: true, show: false, enableLargerThanScreen: true,
    title: 'Seasonal frame', webPreferences: { contextIsolation: true, backgroundThrottling: false } });
  frameWin.setIgnoreMouseEvents(true);
  frameWin.setAlwaysOnTop(true, 'screen-saver');
  try { frameWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true }); } catch (e) {}
  { const me = frameWin; me.on('closed', () => { if (frameWin === me) frameWin = null; }); }
  guard(frameWin, 'frame');
  frameWin.once('ready-to-show', () => { placeFrame(); frameWin.showInactive(); setTimeout(() => fadeWin(frameWin, 1, FRAME_IN_MS), 200); });
  frameWin.loadURL(want);
}
function placeFrame() { if (!frameWin || frameWin.isDestroyed()) return; frameWin.setBounds(stageDisplay().bounds); frameWin.setAlwaysOnTop(true, 'screen-saver'); frameWin.moveTop(); }
function setFrame(id) { if (id && id !== cfg.frame && !box.licence.frameOk(id)) return { ok: false, error: 'This frame isn’t in your package.' };
  cfg.frame = id || null; saveCfg(); showFrame(); buildMenu(); return { ok: true, note: frameNote() }; }
/* the frame's moving parts (spider, ghosts) on or off; the cobwebs stay. Switched live, no reload. */
function setFrameAnim(v) {
  cfg.frameAnim = !!v; saveCfg(); buildMenu();
  if (frameWin && !frameWin.isDestroyed()) frameWin.webContents.executeJavaScript(`window.showboxFrameAnim && showboxFrameAnim(${cfg.frameAnim})`).catch(() => {});
  return { ok: true };
}
function frameNote() { return cfg.frame && oneScreen() ? 'Only one screen is connected, so the frame is waiting for the stage screen.' : ''; }

/* which show is on the LED right now (null when the stage is closed) */
function runningShow() { if (!stageWin || stageWin.isDestroyed() || stageWin.ending) return null; try { return decodeURIComponent(new URL(stageWin.webContents.getURL()).pathname.split('/')[1] || '') || null; } catch (e) { return null; } }
/* The licence decides which shows can be loaded (licence.js). A show loaded while it was allowed keeps going after the licence ends. */
function startShow(n) { if (!box.shows().includes(n)) return { ok: false };
  const lic = box.licence.canLoad(n); if (!lic.ok) { log('load refused by licence:', n, lic.why); return { ok: false, error: lic.text, lock: lic.why }; }
  box.licence.grant(n);
  if (runningShow() && runningShow() !== n) endShow();   /* loading another show clears the LED; the new one goes up when it's ready */ cfg.show = n; saveCfg(); buildMenu(); openDesk(false, true); return { ok: true }; }
function endShow() {
  const w = stageWin; stageBlank = false; stageWanted = false;
  if (w && !w.isDestroyed()) { w.ending = true; } else return { ok: true };
  if (w && !w.isDestroyed()) fadeStage(0, FADE_OUT_MS, () => { if (!w.isDestroyed()) w.destroy(); if (stageWin === w) stageWin = null; buildMenu(); box.packs.applyWaiting(); });
  return { ok: true };
}
function goDashboard() { openDesk(true); }

/* "Show numbers on the screens": a big number and its job on every screen for a few seconds, so the operator can tell them apart */
let idWins = [];
function identify() {
  idWins.forEach(w => { if (!w.isDestroyed()) w.destroy(); }); idWins = [];
  const all = screen.getAllDisplays(), sid = stageDisplay().id, did = deskDisplay().id, one = all.length < 2;
  all.forEach((d, i) => {
    const job = one ? 'Only screen' : d.id === sid ? 'Stage screen' : d.id === did ? 'Operator desk' : 'Not used', b = d.bounds;
    const w = Math.min(760, Math.round(b.width * .6)), h = Math.min(460, Math.round(b.height * .5));
    const win = new BrowserWindow({ x: b.x + Math.round((b.width - w) / 2), y: b.y + Math.round((b.height - h) / 2), width: w, height: h, frame: false, transparent: true, backgroundColor: '#00000000',
      hasShadow: false, resizable: false, movable: false, focusable: false, skipTaskbar: true, show: false, alwaysOnTop: true, webPreferences: { contextIsolation: true } });
    win.setIgnoreMouseEvents(true); win.setAlwaysOnTop(true, 'screen-saver');
    try { win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true }); } catch (e) {}
    const esc = t => String(t).replace(/[<>&"]/g, '');
    const html = `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="${base()}/fonts/fonts.css"><style>html,body{margin:0;height:100%;background:transparent;overflow:hidden}
      .c{position:absolute;inset:0;border-radius:36px;background:rgba(14,8,36,.92);border:4px solid ${job === 'Stage screen' ? '#ff3d8b' : job === 'Operator desk' ? '#3ddcff' : '#8a80b0'};color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:Outfit,system-ui,sans-serif;box-sizing:border-box;animation:in .35s ease-out}
      b{font:900 ${Math.round(h * .42)}px/1 Unbounded,system-ui}i{font-style:normal;font:800 ${Math.round(h * .1)}px Unbounded,system-ui;margin-top:6px;color:${job === 'Stage screen' ? '#ff6aa8' : job === 'Operator desk' ? '#7fe8ff' : '#c9c1ea'}}
      span{font-size:${Math.round(h * .06)}px;color:#b9b0dd;margin-top:10px}@keyframes in{from{opacity:0;transform:scale(.94)}}</style></head>
      <body><div class="c"><b>${i + 1}</b><i>${job}</i><span>${esc(dLabel(d, i))} · ${d.size.width}×${d.size.height}</span></div></body></html>`;
    win.once('ready-to-show', () => { win.showInactive(); win.moveTop(); });
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    idWins.push(win);
  });
  setTimeout(() => { idWins.forEach(w => { if (!w.isDestroyed()) w.destroy(); }); idWins = []; }, 6000);
  return { ok: true };
}
/* the dashboard picks which screen is the LED stage and which is the operator desk */
function setScreens(b) {
  const all = screen.getAllDisplays(), st = all.find(d => d.id === +b.stage), dk = all.find(d => d.id === +b.desk);
  if (all.length > 1 && st && dk && st.id === dk.id) return { ok: false, error: 'The operator desk and the stage screen need different screens.' };
  if (st) rememberStage(st);
  if (dk) rememberDesk(dk); else if (st && all.length > 1 && deskDisplay().id === st.id) { const o = all.find(d => d.id !== st.id); if (o) rememberDesk(o); }
  const ix = d => all.findIndex(x => x.id === d.id);
  log('screens set: stage', dLabel(stageDisplay(), ix(stageDisplay())), 'desk', dLabel(deskDisplay(), ix(deskDisplay())));
  placeDesk(); if (stageWin && !stageWin.isDestroyed()) placeStage(stageDisplay().bounds); showFrame(); placeFrame(); buildMenu();
  return { ok: true };
}
/* a small picture of the stage screen (and of the frame window on top of it) for the launch window on the Operator Desk.
   At most one capture a second each, so it costs next to nothing even on an older Mac. */
const pvCache = {};
async function preview(kind) {
  const w = kind === 'frame' ? frameWin : stageWin;
  if (!w || w.isDestroyed() || w.ending) return null;
  const c = pvCache[kind]; if (c && Date.now() - c.at < 1000 && c.w === w) return c.buf;
  try { const img = await w.webContents.capturePage(); if (img.isEmpty()) return null;
    const small = img.resize({ width: 640, quality: 'good' }), buf = kind === 'frame' ? small.toPNG() : small.toJPEG(75);
    pvCache[kind] = { at: Date.now(), w, buf }; return buf; } catch (e) { return null; }
}
function dashboardInfo() {
  const all = screen.getAllDisplays(), prim = screen.getPrimaryDisplay().id, sid = stageDisplay().id, did = deskDisplay().id;
  return { displays: all.map((d, i) => ({ id: d.id, n: i + 1, label: dLabel(d, i), w: d.size.width, h: d.size.height, x: d.bounds.x, y: d.bounds.y, primary: d.id === prim, internal: !!d.internal,
      stage: all.length > 1 && d.id === sid, desk: all.length < 2 || d.id === did })),
    running: runningShow(), show: cfg.show, loaded: loadedShow, ledOk: all.length > 1 || cfg.stageDisplay === prim, stageBlank, stageOpen: !!(stageWin && !stageWin.isDestroyed()), platform: process.platform };
}
/* "Add a game from a file": a .sbpack from a USB stick or an email, for a Mac with no internet */
async function importPack() {
  const r = await dialog.showOpenDialog(deskWin && !deskWin.isDestroyed() ? deskWin : undefined, { title: 'Add a game from a file', buttonLabel: 'Add game', properties: ['openFile'], filters: [{ name: 'Show Box game', extensions: ['sbpack'] }] });
  if (r.canceled || !r.filePaths[0]) return { ok: false, cancelled: true };
  const x = await box.packs.importFile(r.filePaths[0]); buildMenu(); return x;
}
async function dashAction(b) {
  switch (b.do) {
    case 'start': return startShow(String(b.show || ''));
    case 'end': return endShow();
    case 'stageOn': if (b.show && b.show !== cfg.show) return { ok: false, error: 'Load that show first.' }; return stageOn();
    case 'restartStage': if (!stageWin && !runningShow() && !b.show) return { ok: false }; if (stageWin) { stageWin.destroy(); stageWin = null; } openStage(); return { ok: true };
    case 'identify': return identify();
    case 'screens': return setScreens(b);
    case 'log': shell.showItemInFolder(box.LOG); return { ok: true };
    case 'stats': openStats(); return { ok: true };
    case 'health': healthInfo(); return { ok: true };
    case 'licenceChanged': buildMenu(); if (cfg.frame && !box.licence.frameOk(cfg.frame) && !box.licence.status().state.match(/ended/)) setFrame(null); return { ok: true };
    case 'importPack': return importPack();
    case 'website': if (/^https:\/\//.test(String(b.url || ''))) { shell.openExternal(String(b.url)); return { ok: true }; } return { ok: false };
  }
  return { ok: false, error: 'unknown' };
}

function switchShow(n) { if (n === cfg.show && onShow()) return;
  const lic = box.licence.canLoad(n); if (!lic.ok) { dialog.showMessageBox(deskWin || undefined, { type: 'info', title: 'Show Box', message: box.title(n), detail: lic.text, buttons: ['OK'] }); return; }
  box.licence.grant(n); cfg.show = n; saveCfg(); openDesk(false, true); buildMenu(); }

function ipadInfo() {
  const urls = box.lanUrls().map(u => `${u}/${cfg.show}/`);
  dialog.showMessageBox(deskWin || undefined, { type: 'info', title: 'Run the show from an iPad', message: 'Run the show from an iPad',
    detail: `Join the iPad to the same Wi-Fi as this Mac, then open this address in Safari:\n\n${urls[0] || '(no network found: connect this Mac to Wi-Fi)'}\n\n` + (urls.length > 1 ? 'If that doesn’t work, try:\n' + urls.slice(1).join('\n') : ''), buttons: ['OK'] });
}
function healthInfo() {
  const h = box.health(), lines = [];
  lines.push(`Show Box ${h.version}, running ${h.uptimeMin} min, memory ${h.memMB.rss} MB` + (h.extraMemMB ? ` (+${h.extraMemMB} MB windows)` : ''));
  lines.push(''); h.shows.forEach(s => lines.push(`${s.title}: build ${s.build}`));
  const live = Object.entries(h.live).filter(([, c]) => c.desk + c.stage + c.phone + c.other);
  if (live.length) { lines.push(''); live.forEach(([n, c]) => lines.push(`${SHOW_NAMES[n] || n} now: ${c.phone} phones, ${c.desk + c.other} desks, ${c.stage} stage (peak ${c.peak})`)); }
  if (h.warnings.length) { lines.push(''); h.warnings.forEach(w => lines.push('⚠ ' + w)); }
  dialog.showMessageBox(deskWin || undefined, { type: 'info', title: 'Show Box health', message: 'Show Box health', detail: lines.join('\n'), buttons: ['OK', 'Open the log'] })
    .then(r => { if (r.response === 1) shell.showItemInFolder(h.log); });
}

let statsWin = null;
function openStats() {
  if (statsWin && !statsWin.isDestroyed()) { statsWin.focus(); return; }
  const d = deskDisplay().workArea;
  statsWin = new BrowserWindow({ x: d.x + 60, y: d.y + 40, width: Math.min(1040, d.width - 120), height: Math.min(860, d.height - 80), backgroundColor: '#0e0824', title: 'Show stats', webPreferences: { contextIsolation: true } });
  statsWin.on('closed', () => { statsWin = null; });
  statsWin.loadURL(`${base()}/box/stats.html`);
}

function buildMenu() {
  const disp = screen.getAllDisplays(), prim = screen.getPrimaryDisplay().id, sd = stageDisplay().id;
  const tpl = [
    ...(process.platform === 'darwin' ? [{ label: 'Show Box', submenu: [{ role: 'about' }, { label: 'Health and version…', click: healthInfo }, { label: 'Show stats…', click: openStats }, { type: 'separator' }, { role: 'hide' }, { role: 'hideOthers' }, { type: 'separator' }, { role: 'quit', label: 'Quit Show Box' }] }] : []),
    { label: 'Show', submenu: [...box.shows().map(n => ({ label: box.title(n) + (box.licence.canLoad(n).ok ? '' : ' (locked)'), type: 'radio', checked: n === cfg.show, enabled: box.licence.canServe(n), click: () => switchShow(n) })), { type: 'separator' },
      { label: 'Show Box dashboard', accelerator: 'CmdOrCtrl+Shift+H', click: goDashboard },
      { label: 'Reload desk', accelerator: 'CmdOrCtrl+R', click: () => deskWin && deskWin.reload() }] },
    { label: 'Stage', submenu: [{ label: 'Open or restart stage screen', accelerator: 'CmdOrCtrl+Shift+O', click: () => { if (stageWin) { stageWin.destroy(); stageWin = null; } openStage(); } },
      { type: 'separator' }, ...disp.map((d, i) => ({ label: `Show stage on ${dLabel(d, i)}${d.id === prim ? ' (main screen)' : ''}`, type: 'radio', checked: sd === d.id,
        click: () => { rememberStage(d); if (stageWin && !stageWin.isDestroyed()) openStage(); placeDesk(); showFrame(); buildMenu(); } })), { type: 'separator' },
      { label: 'Show numbers on the screens', click: identify },
      { label: 'Close stage screen (end show)', click: endShow }] },
    { label: 'Frame', submenu: [{ label: 'No frame', type: 'radio', checked: !cfg.frame, click: () => setFrame(null) }, { type: 'separator' },
      ...Object.values(box.frames()).map(f => ({ label: f.name + (box.licence.frameOk(f.id) ? '' : ' (locked)'), type: 'radio', checked: cfg.frame === f.id, enabled: box.licence.frameOk(f.id) || cfg.frame === f.id, click: () => setFrame(f.id) })),
      ...((box.frames()[cfg.frame] || {}).animations ? [{ type: 'separator' }, { label: `${box.frames()[cfg.frame].animations} (animations)`, type: 'checkbox', checked: cfg.frameAnim !== false, click: m => setFrameAnim(m.checked) }] : [])] },
    { label: 'iPad', submenu: [{ label: 'Run the show from an iPad…', click: ipadInfo }] },
    { role: 'editMenu' },
    { label: 'View', submenu: [{ role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }, { type: 'separator' }, { role: 'toggleDevTools' }] }];
  if (process.platform !== 'darwin') tpl.push({ label: 'Help', submenu: [{ label: 'Health and version…', click: healthInfo }, { label: 'Show stats…', click: openStats }] });
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

app.on('second-instance', () => { if (deskWin) { if (deskWin.isMinimized()) deskWin.restore(); deskWin.focus(); } });
app.whenReady().then(() => {
  DATA = app.getPath('userData'); try { fs.mkdirSync(DATA, { recursive: true }); } catch (e) {}
  loadCfg();
  box = createBox({ port: PORT, dataDir: DATA, version: app.getVersion(), names: SHOW_NAMES, hooks: {
    currentShow: () => cfg.show,
    frame: () => cfg.frame, setFrame, frameNote, frameAnim: () => cfg.frameAnim !== false, setFrameAnim,
    warnings, dashboard: dashboardInfo, action: dashAction, preview,
    /* a downloaded game is never swapped while it's loaded or on the stage screen (packs.js) */
    inUse: n => n === runningShow() || (!!deskWin && !deskWin.isDestroyed() && showOfUrl(deskWin.webContents.getURL()) === n), packInstalled: () => { buildMenu(); if (!box.shows().includes(cfg.show)) { cfg.show = box.shows()[0]; saveCfg(); } },
    memory: () => { try { return Math.round(app.getAppMetrics().reduce((t, m) => t + (m.memory ? m.memory.workingSetSize : 0), 0) / 1024); } catch (e) { return undefined; } },
    displays: () => { const prim = screen.getPrimaryDisplay().id, sid = stageDisplayId(); return screen.getAllDisplays().map((d, i) => ({ id: d.id, label: dLabel(d, i), bounds: d.bounds, primary: d.id === prim, stage: sid === d.id })); },
    setStage: (b, list) => {
      if (b.show && list.includes(b.show) && b.show !== cfg.show) { cfg.show = b.show; saveCfg(); openDesk(); buildMenu(); }
      if (b.display != null) { const d = screen.getAllDisplays().find(x => x.id === +b.display); if (d) rememberStage(d); }
      openStage(); showFrame(); buildMenu(); return { ok: true, display: stageDisplayId() };
    } } });
  if (!box.shows().includes(cfg.show)) cfg.show = box.shows().includes('kidz-karaoke') ? 'kidz-karaoke' : box.shows()[0];
  box.server.on('error', e => { log('server error', String(e)); dialog.showErrorBox('Show Box could not start', e.code === 'EADDRINUSE' ? `Something else on this Mac is using port ${PORT}. Quit any other copy of Show Box and try again.` : String(e)); app.quit(); });
  box.listen(() => {
    /* keep the screen on, and stop macOS putting the app to sleep (App Nap) while it sits behind QLab */
    powerSaveBlocker.start('prevent-display-sleep'); powerSaveBlocker.start('prevent-app-suspension');
    log('screens', screen.getAllDisplays().map((d, i) => `${dLabel(d, i)} ${dSize(d)}${d.id === screen.getPrimaryDisplay().id ? ' main' : ''}`).join(', '));
    if (cfg.frame && (!box.frames()[cfg.frame] || !box.licence.frameOk(cfg.frame))) cfg.frame = null;
    buildMenu(); openDesk(true); showFrame();   /* home screen first; the stage opens when a show is picked */
    /* licence stage changes (countdown starts, grace, ended): note it in the log and refresh the menu's locks */
    let licState = box.licence.status().state; log('licence:', licState);
    setInterval(() => { const st = box.licence.status().state; if (st !== licState) { log('licence now', st, '(was', licState + ')'); licState = st; buildMenu(); } }, 20000);
    screen.on('display-added', () => { log('screen added'); buildMenu(); setTimeout(() => { if (stageWanted && onShow()) openStage(); showFrame(); }, 800); });
    screen.on('display-removed', () => { log('screen removed'); buildMenu(); setTimeout(() => { if (stageWanted && onShow() && (screen.getAllDisplays().length > 1 || cfg.stageDisplay === screen.getPrimaryDisplay().id)) openStage(); else if (stageWin) stageWin.destroy(); placeDesk(); showFrame(); }, 800); });
    /* Only react when a screen really changes size, position, scale or rotation. macOS also reports a "change" every time the menu bar
       hides or shows (work area), and the stage going full screen hides the menu bar, so reacting to that made an endless loop that
       froze a one-screen Mac (Karl, 2026-11-02). Debounced, and skipped when nothing we care about moved. */
    let metricsTimer = null, lastScreens = screensSig();
    screen.on('display-metrics-changed', (e, d, changed) => {
      if (!(changed || []).some(c => c === 'bounds' || c === 'scaleFactor' || c === 'rotation')) return;
      clearTimeout(metricsTimer);
      metricsTimer = setTimeout(() => { const sig = screensSig(); if (sig === lastScreens) return; lastScreens = sig; log('screen changed');
        buildMenu(); if (stageWin) placeStage(stageDisplay().bounds); placeFrame(); }, 700);
    });
  });
});
app.on('window-all-closed', () => app.quit());
app.on('activate', () => { if (!deskWin) openDesk(true); });

/* for the screen tests (tests/screens-test.js) */
module.exports = { setFrame, setScreens, _frameWin: () => frameWin, stageDisplay, deskDisplay, rememberStage, warnings, _cfg: () => cfg, _setCfg: c => { cfg = { ...cfg, ...c }; } };

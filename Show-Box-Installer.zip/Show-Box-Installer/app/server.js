/* Show Box web server and relay. Plain Node, no Electron, so it can be load-tested on its own.
   - serves each show from shows/<name>/ at http://<mac>:8737/<name>/ (fonts and the guard script are added to every page)
   - relays messages between the devices of a show over ws://<mac>:8737/live?show=<name>&role=<desk|stage|phone>&id=<id>
       * a phone's messages go only to the screens (desk, stage, iPad), never to the other phones
       * a message with "_to":"screens" | "phones" | "id:<id>" goes only to those devices
       * anything else goes to every other device of that show, unchanged
   - keeps a log file and a health report (/api/health) */
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), url = require('url'), crypto = require('crypto');
const { WebSocketServer } = require('ws');
const QR = require('qrcode');
const { createStats } = require('./stats');
const { createLicence } = require('./licence');
const { createPacks } = require('./packs');

const ROOT = __dirname, SHOWS = path.join(ROOT, 'shows'), FONTS = path.join(ROOT, 'fonts'), BOX = path.join(ROOT, 'box'), FRAMES = path.join(ROOT, 'frames');
const LIMITS = {
  phoneMsgBytes: 16 * 1024,      /* a phone only ever sends small messages */
  anyMsgBytes: 8 * 1024 * 1024,  /* desk state can be big (question banks) */
  phoneRate: 20, phoneBurst: 40, /* messages a second per phone, and the burst allowed */
  slowClientBytes: 4 * 1024 * 1024, /* skip a device that has this much still waiting to send */
  clientsPerShow: 600
};

function createBox(opts) {
  const o = Object.assign({ port: 8737, dataDir: path.join(os.tmpdir(), 'showbox'), version: '0', names: {}, hooks: {} }, opts);
  const PORT = o.port, DATA = o.dataDir, H = o.hooks;
  try { fs.mkdirSync(path.join(DATA, 'logs'), { recursive: true }); } catch (e) {}
  const started = Date.now();
  let showStats = null; /* set up below, once the log exists */

  /* ---------- log file (kept under 2 MB, one old copy) ---------- */
  const LOG = path.join(DATA, 'logs', 'showbox.log');
  function log(...a) {
    const line = new Date().toISOString() + ' ' + a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ') + '\n';
    try { const st = fs.statSync(LOG); if (st.size > 2e6) fs.renameSync(LOG, LOG + '.1'); } catch (e) {}
    try { fs.appendFileSync(LOG, line); } catch (e) {}
    if (o.echo) process.stdout.write(line);
  }

  showStats = createStats({ dataDir: DATA, version: o.version, log: (...a) => log(...a), defaultPark: o.defaultPark || '', firstUploadMs: o.firstUploadMs, uploadEveryMs: o.uploadEveryMs });
  /* the park's licence (see licence.js). requireKey comes from licence-config.json in the app: off in Karl's test builds. */
  let licCfg = {}; try { licCfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'licence-config.json'), 'utf8')); } catch (e) {}
  const L = createLicence({ dataDir: DATA, publicKey: o.publicKey, log: (...a) => log(...a), requireKey: o.requireKey != null ? o.requireKey : !!licCfg.requireKey, now: o.now, fetch: o.fetch, park: () => { try { return showStats.config().park || ''; } catch (e) { return ''; } } });
  let PRODUCTS = {}; try { PRODUCTS = JSON.parse(fs.readFileSync(path.join(BOX, 'products.json'), 'utf8')); } catch (e) {}
  const local = req => /^(::ffff:)?127\.0\.0\.1$|^::1$/.test(req.socket.remoteAddress || '');

  /* Games: a game can come in the installer (app/shows/<id>) or be downloaded when the licence key covers it (DATA/packs/<id>, see packs.js).
     A download wins over the installer copy. Every product in products.json gets a tile, installed or not. */
  const bundled = n => fs.existsSync(path.join(SHOWS, n, 'index.html'));
  let packCfg = {}; try { packCfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'packs-config.json'), 'utf8')); } catch (e) {}
  const P = createPacks({ dataDir: DATA, url: o.packsUrl != null ? o.packsUrl : packCfg.url || '', log: (...a) => log(...a), keyText: () => L.keyText(), canLoad: n => L.canLoad(n),
    products: () => ids(), bundled, inUse: n => H.inUse ? !!H.inUse(n) : false, publicKey: o.publicKey,
    changed: (n, st) => { if (H.packChanged) H.packChanged(n, st); }, installed: n => { delete stampCache[n]; if (H.packInstalled) H.packInstalled(n); } });
  const ID_OK = /^[a-z0-9][a-z0-9-]{0,40}$/;
  const ids = () => { const set = new Set(Object.keys(PRODUCTS.shows || {}).filter(n => ID_OK.test(n)));
    try { for (const n of fs.readdirSync(SHOWS)) if (bundled(n)) set.add(n); } catch (e) {}
    for (const n of P.list()) set.add(n); return [...set].sort(); };
  const showDir = n => P.dirOf(n) || (bundled(n) ? path.join(SHOWS, n) : null);
  const shows = () => ids().filter(n => showDir(n));
  const title = n => o.names[n] || ((PRODUCTS.shows || {})[n] || {}).title || n;
  /* build stamp per show: date + short hash of its page, so you can tell which version a park is running */
  const stampCache = {};
  function stamp(n) {
    const d = showDir(n), f = d && path.join(d, 'index.html');
    try { const st = fs.statSync(f), k = st.mtimeMs + ':' + st.size;
      if (stampCache[n] && stampCache[n].k === k) return stampCache[n].v;
      const v = st.mtime.toISOString().slice(0, 10) + '-' + crypto.createHash('sha1').update(fs.readFileSync(f)).digest('hex').slice(0, 7);
      stampCache[n] = { k, v }; return v; } catch (e) { return null; }
  }

  /* ---------- stored documents (Kidz Karaoke lyric timings and the like) ---------- */
  const docs = {};
  const docFile = show => path.join(DATA, 'docs', show.replace(/[^a-z0-9-]/gi, '') + '.json');
  function docsOf(show) { if (!docs[show]) { try { docs[show] = JSON.parse(fs.readFileSync(docFile(show), 'utf8')); } catch (e) { docs[show] = {}; } } return docs[show]; }
  const saveT = {};
  function saveDocs(show) { clearTimeout(saveT[show]); saveT[show] = setTimeout(() => {
    try { fs.mkdirSync(path.dirname(docFile(show)), { recursive: true }); fs.writeFileSync(docFile(show) + '.tmp', JSON.stringify(docs[show])); fs.renameSync(docFile(show) + '.tmp', docFile(show)); } catch (e) { log('doc save failed', show, String(e)); } }, 300); }

  /* ---------- network addresses for the iPad and phones ---------- */
  function lanUrls() {
    const out = [];
    for (const [name, list] of Object.entries(os.networkInterfaces())) for (const a of list || [])
      if (a.family === 'IPv4' && !a.internal && !/^169\.254\./.test(a.address)) out.push({ u: `http://${a.address}:${PORT}`, wifi: /^en/.test(name) });
    out.sort((a, b) => b.wifi - a.wifi); /* Wi-Fi/Ethernet first, VPNs and the like last */
    const urls = out.map(x => x.u);
    try { urls.push(`http://${os.hostname().replace(/\.local$/, '')}.local:${PORT}`); } catch (e) {}
    return urls;
  }

  /* ---------- web server ---------- */
  const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4',
    '.wav': 'audio/wav', '.mp4': 'video/mp4', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.ico': 'image/x-icon', '.webp': 'image/webp', '.webm': 'video/webm', '.mov': 'video/quicktime', '.gif': 'image/gif' };
  const GFONTS = /<link[^>]+fonts\.(googleapis|gstatic)\.com[^>]*>/g;
  function send(res, code, body, type) { res.writeHead(code, { 'Content-Type': type || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' }); res.end(body); }
  function json(res, obj, code) { send(res, code || 200, JSON.stringify(obj), 'application/json'); }
  function readBody(req, max) { return new Promise(r => { let b = ''; req.on('data', c => { b += c; if (b.length > (max || 8e6)) req.destroy(); }); req.on('end', () => r(b)); req.on('error', () => r('')); }); }
  const htmlCache = {};
  function serveFile(req, res, file, raw) {
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) return send(res, 404, 'Not found');
      const ext = path.extname(file).toLowerCase(), type = TYPES[ext] || 'application/octet-stream';
      if (ext === '.html' && !raw) { /* fonts come from the box, not the internet; the guard keeps devices awake and reconnecting */
        const k = st.mtimeMs + ':' + st.size;
        if (!htmlCache[file] || htmlCache[file].k !== k) {
          let h = fs.readFileSync(file, 'utf8').replace(GFONTS, '');
          const add = '<link rel="stylesheet" href="/fonts/fonts.css"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black"><link rel="apple-touch-icon" href="/box/touch-icon.png"><script src="/box/guard.js"></script>';
          h = /<head(\s[^>]*)?>/i.test(h) ? h.replace(/<head(\s[^>]*)?>/i, m => m + add) : /<title>/i.test(h) ? h.replace(/<title>/i, add + '<title>') : add + h;
          htmlCache[file] = { k, h };
        }
        return send(res, 200, htmlCache[file].h, type);
      }
      const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
      if (range) { let a = range[1] === '' ? st.size - (+range[2]) : +range[1], b = range[1] !== '' && range[2] !== '' ? +range[2] : st.size - 1;
        if (a < 0) a = 0; if (b >= st.size) b = st.size - 1; if (a > b) return send(res, 416, '');
        res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${a}-${b}/${st.size}`, 'Content-Length': b - a + 1, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-cache' });
        return fs.createReadStream(file, { start: a, end: b }).on('error', () => res.destroy()).pipe(res); }
      res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-cache' });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
    });
  }
  function safeJoin(base, rel) { const p = path.normalize(path.join(base, rel)); return p.startsWith(base + path.sep) || p === base ? p : null; }

  /* ---------- seasonal frames: a see-through layer the Mac lays over everything on the stage screen ----------
     Each frame is a folder in frames/ (comes with the app) or <app data>/frames/ (seasonal content updates, wins over the app's copy):
       frame.json  {"name": "Halloween: cobwebs and spider"}
       and one of: index.html (animated, transparent background) | frame.png (transparent PNG) | frame.webm (video with transparency) */
  const frameDirs = () => [path.join(DATA, 'frames'), FRAMES];
  function frames() {
    const out = {};
    frameDirs().slice().reverse().forEach(dir => { let names = []; try { names = fs.readdirSync(dir); } catch (e) {}
      names.forEach(id => { if (!/^[a-z0-9-]+$/i.test(id)) return; const d = path.join(dir, id); let meta = {};
        try { meta = JSON.parse(fs.readFileSync(path.join(d, 'frame.json'), 'utf8')); } catch (e) {}
        const kind = ['index.html', 'frame.png', 'frame.webm', 'frame.mov', 'frame.gif', 'frame.webp'].find(f => fs.existsSync(path.join(d, f)));
        if (kind) out[id] = { id, name: String(meta.name || id), kind, dir: d, animations: meta.animations ? String(meta.animations) : '' }; }); });
    return out;
  }
  function frameState() {
    return { current: H.frame ? H.frame() : null, anim: H.frameAnim ? H.frameAnim() : true, note: H.frameNote ? H.frameNote() : '',
      frames: Object.values(frames()).map(f => ({ id: f.id, name: f.name, animations: f.animations, locked: !L.frameOk(f.id) })) };
  }
  function frameWrapper(f) {
    const file = '/frames/' + f.id + '/' + f.kind, vid = /\.(webm|mov)$/.test(f.kind);
    return `<!doctype html><html><head><meta charset="utf-8"><title>${f.name.replace(/[<>&]/g, '')}</title><style>html,body{margin:0;height:100%;background:transparent;overflow:hidden}img,video{position:fixed;inset:0;width:100%;height:100%;object-fit:fill}</style></head><body>` +
      (vid ? `<video src="${file}" autoplay loop muted playsinline></video>` : `<img src="${file}" alt="">`) + `</body></html>`;
  }

  function licenceInfo() { return Object.assign(L.status(), { kept: L.granted(), framesUrl: (PRODUCTS.frames || {}).url || '' }); }
  /* what a show's page shows instead, when the park's licence doesn't cover it (or has ended) */
  function lockedPage(n) {
    const k = L.canLoad(n), s = L.status();
    const head = k.why === 'package' ? 'Not in your package' : k.why === 'ended' ? 'Licence ended' : 'Licence key needed';
    const body = k.why === 'package' ? `${title(n)} isn't part of this park's Show Box package. You can ask to add it on the Show Box dashboard.`
      : k.why === 'ended' ? `The Show Box licence for this park has ended, so new shows can't be loaded.${s.contact ? ' To renew, contact ' + s.contact + '.' : ' Contact us to renew.'}`
      : 'Enter the park\'s licence key on the Show Box dashboard, then load the show again.';
    const e = t => String(t).replace(/[<>&"]/g, '');
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${e(title(n))}</title><link rel="stylesheet" href="/fonts/eo-fonts.css">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(40% 55% at 100% 0%,rgba(232,108,40,.42),transparent 70%),radial-gradient(45% 55% at 100% 100%,rgba(120,48,170,.40),transparent 72%),radial-gradient(40% 50% at 0% 100%,rgba(110,32,72,.38),transparent 72%),#0d0812;color:#fff;font:400 18px/1.5 Inter,system-ui,sans-serif;padding:24px;text-align:center}
.c{max-width:560px;padding:36px 32px;border-radius:28px;background:linear-gradient(100deg,rgba(64,24,40,.70),rgba(118,38,42,.62) 55%,rgba(186,78,32,.62));border:1px solid rgba(255,255,255,.16);box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 24px 60px rgba(0,0,0,.4)}.i{width:72px;height:72px;margin:0 auto 18px;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.2)}
h1{font:900 32px Inter,system-ui;letter-spacing:-.03em;margin:0 0 10px}p{color:rgba(255,255,255,.78);margin:0 0 20px}a{color:#fff;background:linear-gradient(100deg,#f37b3c,#ea5b40 55%,#de4458);padding:12px 24px;border-radius:999px;text-decoration:none;font-weight:700;display:inline-block;box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 10px 28px rgba(234,91,64,.35)}</style></head>
<body><div class="c"><div class="i"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></div>
<h1>${head}</h1><p>${e(body)}</p><a href="/" target="_top">Back to the Show Box</a></div></body></html>`;
  }

  /* The show picker for an iPad (and the Mac with ?picker). A desk opened at #desk takes the controls over from the Mac's desk,
     so the iPad really runs the show (Kidz Karaoke shares one live state, so it needs no takeover). The show loaded on the
     Show Box comes first. Saved to the iPad's Home Screen it opens full screen, without the browser's address bar. */
  function home() {
    const urls = lanUrls(), D = H.dashboard ? H.dashboard() : {}, cur = D.running || D.loaded || '';
    const link = n => `/${n}/` + (n === 'kidz-karaoke' ? '' : '#desk');
    const list = shows().slice().sort((a, b) => (b === cur) - (a === cur));
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="apple-mobile-web-app-title" content="Show Box"><link rel="apple-touch-icon" href="/box/touch-icon.png">
<title>Show Box</title>
<link rel="stylesheet" href="/fonts/eo-fonts.css"><style>body{margin:0;min-height:100vh;background:radial-gradient(40% 55% at 100% 0%,rgba(232,108,40,.42),transparent 70%),radial-gradient(45% 55% at 100% 100%,rgba(120,48,170,.40),transparent 72%),radial-gradient(40% 50% at 0% 100%,rgba(110,32,72,.38),transparent 72%),#0d0812;background-attachment:fixed;color:#fff;font:400 18px Inter,system-ui,sans-serif;display:grid;place-content:center;padding:24px;gap:16px;text-align:center}
h1{font:900 44px Inter,system-ui;letter-spacing:-.03em;margin:0}a{display:block;padding:18px 28px;border-radius:24px;background:linear-gradient(160deg,rgba(255,255,255,.10),rgba(255,255,255,.04));color:#fff;font-weight:700;font-size:22px;text-decoration:none;border:1px solid rgba(255,255,255,.18);box-shadow:inset 0 1px 0 rgba(255,255,255,.16)}
a.lock{opacity:.4;pointer-events:none}a.cur{background:linear-gradient(100deg,rgba(64,24,40,.75),rgba(118,38,42,.70) 55%,rgba(186,78,32,.70));border-color:rgba(255,170,130,.5);font-size:26px;padding:22px 28px}a small{display:block;font-size:14px;font-weight:500;opacity:.85;margin-top:4px}p{color:rgba(255,255,255,.7);margin:0}</style></head>
<body><h1>Show Box</h1><p>Pick the show to run from this iPad. It takes the controls over from the Mac.</p>${list.map(n => !L.canServe(n) ? `<a class="lock" aria-disabled="true">${title(n)}<small>${L.canLoad(n).why === 'package' ? 'Not in this park\'s package' : 'Licence ended'}</small></a>` : `<a class="${n === cur ? 'cur' : ''}" href="${link(n)}">${title(n)}${n === cur ? `<small>${D.running === n ? 'On the stage screen now' : 'Loaded on the Show Box'}</small>` : cur ? '<small>Not loaded on the Show Box: load it on the Mac first</small>' : ''}</a>`).join('')}<p>${urls[0] || ''}</p></body></html>`; }

  /* client error reports (phones, iPad, desk) end up in the Mac's log, a few a minute per device at most */
  const logBudget = new Map();
  setInterval(() => logBudget.clear(), 60000).unref();

  function health() {
    const per = {};
    for (const [show, set] of Object.entries(rooms)) {
      const c = { desk: 0, stage: 0, phone: 0, other: 0 };
      for (const ws of set) c[ws.role in c ? ws.role : 'other']++;
      per[show] = Object.assign(c, roundStats(stats[show] || {}));
    }
    const m = process.memoryUsage();
    return { version: o.version, uptimeMin: Math.round((Date.now() - started) / 60000), clock: new Date().toISOString(),
      memMB: { rss: Math.round(m.rss / 1048576), heap: Math.round(m.heapUsed / 1048576) }, extraMemMB: H.memory ? H.memory() : undefined,
      shows: shows().map(n => ({ id: n, title: title(n), build: stamp(n) })), live: per, warnings: H.warnings ? H.warnings() : [], log: LOG };
  }

  async function api(req, res, u) {
    const p = u.pathname;
    if (p === '/api/info') return json(res, { box: true, port: PORT, lanUrls: lanUrls(), shows: shows().map(n => ({ id: n, title: title(n), build: stamp(n) })), show: H.currentShow ? H.currentShow() : '', version: o.version });
    if (p === '/api/health') return json(res, health());
    if (p === '/api/displays') return json(res, H.displays ? H.displays() : []);
    if (p === '/api/stage' && req.method === 'POST') { let b = {}; try { b = JSON.parse(await readBody(req, 1e4) || '{}'); } catch (e) {}
      return json(res, H.setStage ? H.setStage(b, shows()) : { ok: false }); }
    if (p === '/api/frame' && req.method === 'POST') { let b = {}; try { b = JSON.parse(await readBody(req, 1e4) || '{}'); } catch (e) {}
      let r = { ok: true };
      if ('anim' in b) { r = H.setFrameAnim ? H.setFrameAnim(!!b.anim) : { ok: false }; log('frame animations', b.anim ? 'on' : 'off'); }
      if ('id' in b) { const id = b.id && frames()[b.id] ? b.id : null; if (b.id && !id) return json(res, { error: 'no such frame' }, 404);
        if (id && !L.frameOk(id) && id !== (H.frame ? H.frame() : null)) return json(res, Object.assign(frameState(), { ok: false, error: 'This frame isn\u2019t in your package.' }), 403);
        r = H.setFrame ? H.setFrame(id) : { ok: false }; log('frame', id || 'off'); }
      return json(res, Object.assign(frameState(), r)); }
    if (p === '/api/frame') return json(res, frameState());
    /* the Show Box dashboard (the operator's home screen on the Mac): everything that isn't part of one show. Only from the Mac itself. */
    if (p === '/api/dashboard') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403);
      const c = showStats.config(), h = health();
      return json(res, Object.assign({ version: o.version, park: c.park || '', lanUrls: lanUrls(), licence: licenceInfo(), shows: ids().map(n => { const k = L.canLoad(n), has = !!showDir(n);
          return { id: n, title: title(n), build: has ? stamp(n) : null, installed: has, dl: P.state(n), lock: k.ok ? null : k.why, kept: !k.ok && L.granted() === n, product: (PRODUCTS.shows || {})[n] || null }; }),
        frame: frameState(), warnings: h.warnings, uptimeMin: h.uptimeMin, memMB: h.memMB.rss + (h.extraMemMB || 0), live: h.live }, H.dashboard ? H.dashboard() : {})); }
    if (p === '/api/box' && req.method === 'POST') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403);
      let b = {}; try { b = JSON.parse(await readBody(req, 1e4) || '{}'); } catch (e) {}
      return json(res, H.action ? (await H.action(b, shows())) || { ok: true } : { ok: false }); }
    /* the licence: status, enter or remove a key, "Ask to add this". Only from the Mac itself. */
    if (p === '/api/licence') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403);
      if (req.method !== 'POST') return json(res, licenceInfo());
      let b = {}; try { b = JSON.parse(await readBody(req, 2e4) || '{}'); } catch (e) {}
      if (typeof b.key === 'string') { const r = await L.install(b.key); if (r.ok) P.sync().catch(e => log('sync failed', String(e)));   /* fetch the games the new key covers */
        return json(res, r.ok ? { ok: true, eo: r.eo || null, licence: licenceInfo() } : { ok: false, error: r.error }); }
      if (b.remove) { L.remove(); return json(res, { ok: true, licence: licenceInfo() }); }
      if (b.ask && (b.kind === 'show' ? ids().includes(b.ask) : frames()[b.ask])) {
        const t = b.kind === 'show' ? title(b.ask) : frames()[b.ask].name.split(':')[0], c = showStats.config(), at = Date.now();
        L.ask(b.kind === 'show' ? 'show' : 'frame', b.ask, t);
        /* sent with the next upload when the Mac is online; the sheet emails the client's administrator and tech manager
           (its Clients tab, which Karl or their administrator can change), not Karl (2026-11-03) */
        showStats.add({ show: b.kind === 'show' ? b.ask : 'frame:' + b.ask, id: 'ask-' + b.ask, kind: 'request', start: at, end: at, completed: false, item: t,
          client: L.status().client || c.client || '', notes: String(b.note || '').slice(0, 300) });
        showStats.upload('request').catch(() => {});
        return json(res, { ok: true, licence: licenceInfo() }); }
      return json(res, { ok: false, error: 'unknown' }, 400); }
    /* game downloads: { download: id } (or try again), { sync: true }. Only from the Mac itself. */
    if (p === '/api/packs') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403);
      if (req.method !== 'POST') return json(res, { states: P.states() });
      let b = {}; try { b = JSON.parse(await readBody(req, 1e4) || '{}'); } catch (e) {}
      if (typeof b.download === 'string' && ids().includes(b.download)) { P.download(b.download).catch(() => {}); return json(res, { ok: true }); }
      if (b.sync) { let r; try { r = await P.sync(); } catch (e) { r = { result: 'error', error: String(e.message || e) }; } log('check for updates:', r && r.result, (r && r.games || []).join(',')); return json(res, Object.assign({ ok: true }, r)); }
      return json(res, { ok: false, error: 'unknown' }, 400); }
    /* the live picture of the stage screen and the frame on top, for the Operator Desk's launch window. Only on the Mac. */
    { const pm = /^\/api\/preview\/(stage\.jpg|frame\.png)$/.exec(p); if (pm) { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403);
      const buf = H.preview ? await H.preview(pm[1] === 'stage.jpg' ? 'stage' : 'frame') : null;
      if (!buf) return send(res, 404, '');
      res.writeHead(200, { 'Content-Type': pm[1] === 'stage.jpg' ? 'image/jpeg' : 'image/png', 'Cache-Control': 'no-store', 'Content-Length': buf.length }); return res.end(buf); } }
    if (p === '/api/qr') { const t = u.query.text || ''; try { return send(res, 200, await QR.toString(String(t), { type: 'svg', margin: 1, color: { dark: '#000000', light: '#ffffff' } }), 'image/svg+xml'); } catch (e) { return send(res, 400, 'bad text'); } }
    if (p === '/api/log' && req.method === 'POST') {
      const who = req.socket.remoteAddress || '?', n = (logBudget.get(who) || 0) + 1; logBudget.set(who, n);
      const b = await readBody(req, 8000);
      if (n <= 6) { let d = {}; try { d = JSON.parse(b); } catch (e) { d = { text: b.slice(0, 500) }; }
        log('device-error', who, String(d.show || '').slice(0, 40), String(d.role || '').slice(0, 10), String(d.msg || d.text || '').slice(0, 400), String(d.where || '').slice(0, 200), String(d.ua || '').slice(0, 120)); }
      return send(res, 204, '');
    }
    /* anonymous show stats (see stats.js). Settings and clearing only from the Mac itself. */
    if (p === '/api/stats' && req.method === 'POST') { let b; try { b = JSON.parse(await readBody(req, 5e5)); } catch (e) { return json(res, { error: 'bad json' }, 400); } return json(res, { ok: true, added: showStats.add(b) }); }
    if (p === '/api/stats') return json(res, showStats.summary());
    if (p === '/api/stats/report-due') return json(res, { due: showStats.reportDue(String(u.query.show || '')) });
    if (p === '/api/stats/export.csv') { res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="show-stats-${(showStats.config().park || 'park').replace(/[^a-z0-9]+/gi, '-')}-${new Date().toISOString().slice(0, 10)}.csv"`, 'Cache-Control': 'no-store' }); return res.end(showStats.csv()); }
    if (p === '/api/stats/config' && req.method === 'POST') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403); let b = {}; try { b = JSON.parse(await readBody(req, 1e4)); } catch (e) {} return json(res, showStats.setConfig(b)); }
    if (p === '/api/stats/config') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403); const c = showStats.config(); return json(res, { park: c.park, client: c.client, uploadUrl: c.uploadUrl, token: c.token ? '••••' : '', count: c.count }); }
    if (p === '/api/stats/upload' && req.method === 'POST') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403); return json(res, await showStats.upload('button')); }
    if (p === '/api/stats/clear' && req.method === 'POST') { if (!local(req)) return json(res, { error: 'only on the show Mac' }, 403); showStats.clear(); return json(res, showStats.summary()); }
    const m = /^\/api\/doc\/([a-z0-9-]+)\/(.+)$/i.exec(p);
    if (m) { const show = m[1], key = decodeURIComponent(m[2]), D = docsOf(show);
      if (req.method === 'GET') return json(res, key in D ? { exists: true, data: D[key] } : { exists: false });
      if (req.method === 'PUT' || req.method === 'POST') { let d; try { d = JSON.parse(await readBody(req)); } catch (e) { return json(res, { error: 'bad json' }, 400); }
        D[key] = d; saveDocs(show); broadcast(show, JSON.stringify({ t: 'doc', path: key, data: d }), null); return json(res, { ok: true }); }
      if (req.method === 'DELETE') { delete D[key]; saveDocs(show); broadcast(show, JSON.stringify({ t: 'doc', path: key, data: null }), null); return json(res, { ok: true }); } }
    return json(res, { error: 'not found' }, 404);
  }

  const server = http.createServer((req, res) => {
    let u, p;
    try { u = url.parse(req.url, true); p = decodeURIComponent(u.pathname || '/'); } catch (e) { return send(res, 400, 'Bad address'); }
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE', 'Access-Control-Allow-Headers': 'Content-Type' }); return res.end(); }
    if (p.startsWith('/api/')) return api(req, res, u).catch(e => { log('api error', p, String(e)); json(res, { error: String(e) }, 500); });
    /* "/" is the dashboard on the Mac's own screen; an iPad or phone gets the simple show picker */
    if (p === '/' || p === '/index.html') return H.dashboard && local(req) && !('picker' in u.query) ? serveFile(req, res, path.join(BOX, 'dashboard.html'), true) : send(res, 200, home(), TYPES['.html']);
    /* a show's desk inside the Show Box bar, on the Mac (anyone else goes straight to the show) */
    { const dm = /^\/desk\/([^/]+)\/?$/.exec(p); if (dm) { if (!shows().includes(dm[1])) return send(res, 404, 'Not found');
      if (!local(req)) { res.writeHead(302, { Location: '/' + dm[1] + '/' }); return res.end(); }
      if (!L.canServe(dm[1])) return send(res, 200, lockedPage(dm[1]), TYPES['.html']);
      return serveFile(req, res, path.join(BOX, 'desk.html'), true); } }
    if (p.startsWith('/fonts/')) { const f = safeJoin(FONTS, p.slice(7)); return f ? serveFile(req, res, f) : send(res, 404, ''); }
    if (p.startsWith('/frames/')) { const mm = /^\/frames\/([a-z0-9-]+)(\/.*)?$/i.exec(p), f = mm && frames()[mm[1]]; if (!f) return send(res, 404, '');
      if (!mm[2]) { res.writeHead(302, { Location: '/frames/' + f.id + '/' }); return res.end(); }
      if (mm[2] === '/') return f.kind === 'index.html' ? serveFile(req, res, path.join(f.dir, 'index.html'), true) : send(res, 200, frameWrapper(f), TYPES['.html']);
      const ff = safeJoin(f.dir, mm[2].slice(1)); return ff ? serveFile(req, res, ff, true) : send(res, 404, ''); }
    if (p.startsWith('/box/')) { const f = safeJoin(BOX, p.slice(5)); return f ? serveFile(req, res, f) : send(res, 404, ''); }
    const m = /^\/([^/]+)(\/.*)?$/.exec(p); if (!m || !shows().includes(m[1])) return send(res, 404, 'Not found');
    if (!m[2]) { res.writeHead(302, { Location: '/' + m[1] + '/' + (u.search || '') }); return res.end(); }
    const rel = m[2] === '/' ? 'index.html' : m[2].slice(1), f = safeJoin(showDir(m[1]), rel);
    if (rel === 'index.html' && !L.canServe(m[1])) return send(res, 200, lockedPage(m[1]), TYPES['.html']);
    return f ? serveFile(req, res, f) : send(res, 404, '');
  });
  server.keepAliveTimeout = 30000;

  /* ---------- relay ---------- */
  const wss = new WebSocketServer({ noServer: true, maxPayload: LIMITS.anyMsgBytes, perMessageDeflate: false }), rooms = {}, stats = {};
  const st = show => stats[show] || (stats[show] = { msgsIn: 0, msgsOut: 0, kbOut: 0, dropped: 0, peak: 0 });
  const roundStats = o => { const r = {}; for (const k in o) r[k] = Math.round(o[k]); return r; };
  let bytesOut = 0;
  function deliver(c, msg, s) {
    if (c.readyState !== 1) return;
    if (c.bufferedAmount > LIMITS.slowClientBytes) { s.dropped++; return; }
    c.send(msg); s.msgsOut++; s.kbOut += msg.length / 1024; bytesOut += msg.length;
    const r = 'to_' + c.role; s[r] = (s[r] || 0) + 1;
  }
  function broadcast(show, msg, from) {
    const set = rooms[show]; if (!set) return; const s = st(show);
    for (const c of set) if (c !== from) deliver(c, msg, s);
  }
  function route(show, msg, from) {
    const set = rooms[show]; if (!set) return; const s = st(show);
    let to = null;
    if (msg.indexOf('"_to"') !== -1) { const m = /"_to"\s*:\s*"([^"]{1,80})"/.exec(msg); if (m) to = m[1]; }
    const fromPhone = from.role === 'phone';
    for (const c of set) {
      if (c === from) continue;
      const phone = c.role === 'phone';
      if (to === 'screens' && phone) continue;
      if (to === 'phones' && !phone) continue;
      if (to && to.startsWith('id:') && c.cid !== to.slice(3)) continue;
      if (!to && fromPhone && phone) continue; /* phones never need each other's messages */
      deliver(c, msg, s);
    }
  }
  server.on('upgrade', (req, sock, head) => {
    let u; try { u = url.parse(req.url, true); } catch (e) { return sock.destroy(); }
    if (u.pathname !== '/live') return sock.destroy();
    const show = String(u.query.show || '').slice(0, 60);
    if (rooms[show] && rooms[show].size >= LIMITS.clientsPerShow) { log('relay full', show); return sock.destroy(); }
    wss.handleUpgrade(req, sock, head, ws => {
      const set = rooms[show] = rooms[show] || new Set(); set.add(ws);
      ws.role = ['desk', 'stage', 'phone'].includes(u.query.role) ? u.query.role : 'other';
      ws.cid = u.query.id ? String(u.query.id).slice(0, 60) : '';
      ws.isAlive = true; ws.tokens = LIMITS.phoneBurst; ws.tokAt = Date.now();
      const s = st(show); if (set.size > s.peak) s.peak = set.size;
      ws.on('pong', () => ws.isAlive = true);
      ws.on('message', (data, isBin) => {
        if (isBin) return;
        s.msgsIn++;
        if (ws.role === 'phone') {
          if (data.length > LIMITS.phoneMsgBytes) { s.dropped++; return; }
          const now = Date.now(); ws.tokens = Math.min(LIMITS.phoneBurst, ws.tokens + (now - ws.tokAt) * LIMITS.phoneRate / 1000); ws.tokAt = now;
          if (ws.tokens < 1) { s.dropped++; return; } ws.tokens--;
        }
        route(show, data.toString(), ws);
      });
      ws.on('close', () => set.delete(ws)); ws.on('error', () => {});
    });
  });
  const pinger = setInterval(() => { for (const set of Object.values(rooms)) for (const ws of set) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; try { ws.ping(); } catch (e) {} } }, 15000);
  /* a line in the log every 10 minutes: who's connected, traffic, memory */
  let lastBytes = 0;
  const summary = setInterval(() => {
    const live = {}; for (const [show, set] of Object.entries(rooms)) if (set.size) { const c = {}; for (const ws of set) c[ws.role] = (c[ws.role] || 0) + 1; live[show] = c; }
    const m = process.memoryUsage();
    log('status', { live, kbPerSec: Math.round((bytesOut - lastBytes) / 600 / 1024), rssMB: Math.round(m.rss / 1048576), heapMB: Math.round(m.heapUsed / 1048576) });
    lastBytes = bytesOut;
  }, 600000);
  summary.unref && summary.unref();

  /* look for new or updated games: soon after start, then every 6 hours (quiet when offline) */
  const packStart = setTimeout(() => P.sync().catch(() => {}), o.packSyncDelayMs != null ? o.packSyncDelayMs : 20000), packTimer = setInterval(() => P.sync().catch(() => {}), 6 * 3600e3);
  /* a game in the package that isn't on the Mac yet (e.g. the Mac was offline): try again every 5 minutes */
  const packRetry = setInterval(() => { if (L.keyText() && ids().some(n => !showDir(n) && L.canLoad(n).ok)) P.sync().catch(() => {}); }, 5 * 60e3);
  packStart.unref && packStart.unref(); packTimer.unref && packTimer.unref(); packRetry.unref && packRetry.unref();
  function listen(cb) { server.listen(PORT, '0.0.0.0', () => { log('Show Box', o.version, 'listening on', PORT, lanUrls()[0] || '(no network)'); cb && cb(); }); }
  function close() { clearInterval(pinger); clearInterval(summary); showStats.stop(); L.stop(); clearTimeout(packStart); clearInterval(packTimer); clearInterval(packRetry); for (const set of Object.values(rooms)) for (const ws of set) ws.terminate(); server.close(); }
  return { server, listen, close, log, lanUrls, shows, title, health, broadcast, rooms, LOG, stats: showStats, frames, licence: L, packs: P, ids };
}

module.exports = { createBox, LIMITS };

/* run on its own (for tests):  node server.js [port] [dataDir] */
if (require.main === module) {
  const box = createBox({ port: +process.argv[2] || 8737, dataDir: process.argv[3], version: require('./package.json').version, echo: true, firstUploadMs: +process.env.SB_FIRST_UPLOAD || undefined, uploadEveryMs: +process.env.SB_UPLOAD_EVERY || undefined,
    names: { 'kidz-karaoke': 'Kidz Karaoke', 'word-up': 'Word-Up!', 'think-you-know-me': 'Think You Know Me?', 'singo': 'Band-Bingo!', 'muiz': 'Muiz' } });
  box.listen();
}

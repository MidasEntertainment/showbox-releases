/* Show Box game downloads (Karl 2026-11-03). The installer carries Show Box and a "shell" for each product (tile, preview, pitch).
   When the park's licence key covers a game, its files are downloaded once, checked, and from then on it runs offline.
   - Store: a private Supabase store. A small check there reads the licence key and only hands out short-lived links for
     games that key covers (see licence-tools/supabase/pack/index.ts).
   - Each game is a "pack": a signed manifest plus parts of up to 45 MB. The manifest is signed with the same private key as the
     licences (Show Box only has the public half), and every part has a SHA-256, so a broken or altered download is never installed.
   - Downloads resume: finished parts are kept, a half part carries on from where it stopped (HTTP Range).
   - Offline fallback: one .sbpack file (manifest + all parts) can be added from a USB stick or an email attachment.
   - A game that is loaded or on the stage screen is never swapped mid-show: a new version waits until it isn't in use.
   Plain Node (fetch, crypto, fs), so it works the same on Windows later. */
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const { PUBLIC_KEY } = require('./licence');
const b64d = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
const MAGIC = Buffer.from('SBPACK1\n');
const ID = /^[a-z0-9][a-z0-9-]{0,40}$/;

/* a signed manifest: { body: "<json>", sig: "<b64url>" }, signed over "SBPACK1." + body */
function readManifest(m, pub) {
  try {
    if (typeof m === 'string') m = JSON.parse(m);
    const good = crypto.verify(null, Buffer.from('SBPACK1.' + m.body), crypto.createPublicKey({ key: b64d(pub || PUBLIC_KEY), format: 'der', type: 'spki' }), b64d(m.sig));
    if (!good) return { ok: false, error: 'This game file isn\'t genuine or has been changed.' };
    const b = JSON.parse(m.body);
    if (b.v !== 1 || !ID.test(b.product) || !/^[0-9A-Za-z.-]{1,40}$/.test(b.version) || !Array.isArray(b.parts) || !b.parts.length) return { ok: false, error: 'This game file is for a newer Show Box.' };
    return { ok: true, m, b };
  } catch (e) { return { ok: false, error: 'This game file can\'t be read.' }; }
}

/* the archive inside a pack: repeated [u32 path length][path][u64 size][bytes]; read as a stream over the parts */
function unpack(files, dest) {
  const fdOf = []; let fi = 0, fd = null, buf = Buffer.alloc(0), count = 0;
  const readMore = n => { /* make sure buf holds at least n bytes, reading on through the part files */
    while (buf.length < n) {
      if (!fd) { if (fi >= files.length) return false; fd = fs.openSync(files[fi++], 'r'); fdOf.push(fd); }
      const chunk = Buffer.alloc(Math.max(n - buf.length, 1 << 20)), got = fs.readSync(fd, chunk, 0, chunk.length, null);
      if (!got) { fs.closeSync(fd); fd = null; continue; }
      buf = Buffer.concat([buf, chunk.subarray(0, got)]);
    }
    return true;
  };
  try {
    for (;;) {
      if (!readMore(4)) break;
      const pl = buf.readUInt32BE(0); if (pl < 1 || pl > 1024) throw new Error('bad entry');
      if (!readMore(4 + pl + 8)) throw new Error('cut short');
      const rel = buf.subarray(4, 4 + pl).toString('utf8'), size = Number(buf.readBigUInt64BE(4 + pl));
      buf = buf.subarray(4 + pl + 8);
      const out = path.resolve(dest, rel);
      if (!out.startsWith(path.resolve(dest) + path.sep) || rel.includes('..')) throw new Error('bad path ' + rel);
      fs.mkdirSync(path.dirname(out), { recursive: true });
      const w = fs.openSync(out, 'w'); let left = size;
      while (left > 0) {
        if (!buf.length && !readMore(1)) throw new Error('cut short');
        const take = Math.min(left, buf.length); fs.writeSync(w, buf, 0, take); buf = buf.subarray(take); left -= take;
      }
      fs.closeSync(w); count++;
    }
  } finally { if (fd) try { fs.closeSync(fd); } catch (e) {} }
  return count;
}

function createPacks(o) {
  const DIR = path.join(o.dataDir, 'packs'), DL = path.join(DIR, '.downloads'), log = o.log || (() => {}), pub = o.publicKey || PUBLIC_KEY;
  try { fs.mkdirSync(DL, { recursive: true }); } catch (e) {}
  const url = o.url || '', products = o.products || (() => []), keyText = o.keyText || (() => null), canLoad = o.canLoad || (() => ({ ok: true })), inUse = o.inUse || (() => false);
  const st = {};   /* per product: { state: 'downloading'|'checking'|'waiting'|'error'|'ready', done, total, error, version } */
  const changed = o.changed || (() => {});
  const installed = id => { try { return JSON.parse(fs.readFileSync(path.join(DIR, id, '.pack.json'), 'utf8')); } catch (e) { return null; } };
  const dirOf = id => fs.existsSync(path.join(DIR, id, 'index.html')) ? path.join(DIR, id) : null;
  const list = () => { try { return fs.readdirSync(DIR).filter(n => ID.test(n) && fs.existsSync(path.join(DIR, n, 'index.html'))); } catch (e) { return []; } };
  const sha = f => new Promise((ok, bad) => { const h = crypto.createHash('sha256'); fs.createReadStream(f).on('data', d => h.update(d)).on('end', () => ok(h.digest('hex'))).on('error', bad); });
  const set = (id, v) => { st[id] = Object.assign({}, st[id], v); changed(id, st[id]); };

  /* move a checked, unpacked game into place (only when it isn't loaded or on the stage screen) */
  const waitingSwap = {};
  function swapIn(id, staged, b) {
    if (inUse(id)) { waitingSwap[id] = { staged, b }; set(id, { state: 'waiting', version: b.version }); return false; }
    const live = path.join(DIR, id), old = path.join(DIR, '.old-' + id + '-' + Date.now());
    try { if (fs.existsSync(live)) fs.renameSync(live, old); fs.renameSync(staged, live); }
    catch (e) { log('pack swap failed', id, String(e)); set(id, { state: 'error', error: 'Couldn\'t install the download. Try again.' }); return false; }
    fs.writeFileSync(path.join(live, '.pack.json'), JSON.stringify({ product: b.product, version: b.version, title: b.title || '', at: new Date().toISOString() }));
    try { fs.rmSync(old, { recursive: true, force: true }); } catch (e) {}
    delete waitingSwap[id]; set(id, { state: 'ready', version: b.version, done: null, total: null, error: null });
    log('game ready', id, b.version); o.installed && o.installed(id, b.version); return true;
  }
  function applyWaiting() { for (const [id, w] of Object.entries(waitingSwap)) if (!inUse(id)) swapIn(id, w.staged, w.b); }

  /* parts on disk -> checked -> unpacked into a staging folder -> swapped in */
  async function finish(id, b, files) {
    set(id, { state: 'checking' });
    for (let i = 0; i < b.parts.length; i++) if (await sha(files[i]) !== b.parts[i].sha256) { try { fs.unlinkSync(files[i]); } catch (e) {} throw new Error('Part of the game arrived damaged, so it wasn\'t installed. Try again, or ask us for a new copy.'); }
    const staged = path.join(DIR, '.staging-' + id); try { fs.rmSync(staged, { recursive: true, force: true }); } catch (e) {}
    fs.mkdirSync(staged, { recursive: true });
    const n = unpack(files, staged);
    if (b.files && n !== b.files) throw new Error('The download was incomplete. Try again.');
    if (!fs.existsSync(path.join(staged, 'index.html'))) throw new Error('This game download is missing its main page.');
    return swapIn(id, staged, b);
  }

  async function api(body) {
    if (!url) throw new Error('No download address in this build.');
    const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j.error || 'The download service said no (' + r.status + ').'); e.status = r.status; throw e; }
    return j;
  }
  /* one part, carrying on from what's already on disk */
  async function getPart(href, file, part, onBytes) {
    let have = 0; try { have = fs.statSync(file).size; } catch (e) {}
    if (have === part.size) return;
    if (have > part.size) { fs.unlinkSync(file); have = 0; }
    const r = await fetch(href, { headers: have ? { range: `bytes=${have}-` } : {}, signal: AbortSignal.timeout(10 * 60000) });
    if (!(r.ok || r.status === 206)) throw new Error('Download stopped (' + r.status + ').');
    if (have && r.status !== 206) have = 0;            /* the store ignored the range: start this part again */
    const w = fs.createWriteStream(file, { flags: have ? 'a' : 'w' });
    try { for await (const chunk of r.body) { if (!w.write(chunk)) await new Promise(ok => w.once('drain', ok)); onBytes(chunk.length); } }
    finally { await new Promise(ok => w.end(ok)); }
    if (fs.statSync(file).size !== part.size) throw new Error('Download was cut off.');
  }

  const busy = {};
  async function download(id) {
    if (busy[id]) return busy[id];
    return (busy[id] = (async () => {
      try {
        const key = keyText(); if (!key) throw new Error('Enter the park\'s licence key first.');
        if (!canLoad(id).ok) throw new Error('This game isn\'t in your package.');
        set(id, { state: 'downloading', done: 0, total: null, error: null });
        const j = await api({ action: 'get', key, product: id });
        const r = readManifest(j.manifest, pub); if (!r.ok) throw new Error(r.error);
        const b = r.b; if (b.product !== id) throw new Error('The store sent the wrong game.');
        const cur = installed(id); if (cur && cur.version === b.version && dirOf(id)) { set(id, { state: 'ready', version: b.version }); return true; }
        const dir = path.join(DL, id, b.version); fs.mkdirSync(dir, { recursive: true });
        try { for (const d of fs.readdirSync(path.join(DL, id))) if (d !== b.version) fs.rmSync(path.join(DL, id, d), { recursive: true, force: true }); } catch (e) {}
        const files = b.parts.map((p, i) => path.join(dir, 'part-' + String(i + 1).padStart(3, '0')));
        const total = b.parts.reduce((a, p) => a + p.size, 0);
        let done = files.reduce((a, f, i) => { try { return a + Math.min(fs.statSync(f).size, b.parts[i].size); } catch (e) { return a; } }, 0);
        set(id, { total, done, version: b.version });
        let last = 0; const tick = n => { done += n; const t = Date.now(); if (t - last > 400) { last = t; set(id, { done }); } };
        let urls = j.urls;
        for (let i = 0; i < b.parts.length; i++) {
          for (let tries = 0; ; tries++) {
            try { await getPart(urls[i], files[i], b.parts[i], tick); break; }
            catch (e) {
              if (tries >= 4) throw e;
              log('download', id, 'part', i + 1, 'retry', tries + 1, String(e.message || e));
              await new Promise(ok => setTimeout(ok, 2000 * 2 ** tries));
              try { urls = (await api({ action: 'get', key, product: id })).urls; } catch (e2) {}   /* links only last a few minutes */
              try { done = files.reduce((a, f, k) => { try { return a + Math.min(fs.statSync(f).size, b.parts[k].size); } catch (x) { return a; } }, 0); } catch (x) {}
            }
          }
        }
        set(id, { done: total });
        const ok = await finish(id, b, files);
        if (ok) try { fs.rmSync(path.join(DL, id), { recursive: true, force: true }); } catch (e) {}
        return ok;
      } catch (e) {
        const msg = e.cause && /ENOTFOUND|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN|fetch failed/i.test(String(e.cause.code || e.cause.message || e.message)) || /fetch failed|timeout|aborted/i.test(String(e.message))
          ? 'No internet connection. It will try again when this Mac is online.' : String(e.message || e);
        log('download failed', id, String(e.message || e)); set(id, { state: 'error', error: msg }); return false;
      } finally { delete busy[id]; }
    })());
  }

  /* fetch every game the key covers that isn't on this Mac yet, or has a newer version; quiet when offline */
  let syncing = null;
  /* sync(): look up what the key covers and fetch anything missing or newer. Answers straight away with what it found
     ({ result: 'nokey'|'nostore'|'offline'|'refused'|'uptodate'|'downloading', games, error }); the downloads carry on in the background. */
  async function sync() {
    if (syncing) return syncing;
    return (syncing = (async () => {
      try {
        const key = keyText(); if (!url) return { result: 'nostore' }; if (!key) return { result: 'nokey' };
        let latest = {}; try { latest = (await api({ action: 'list', key })).products || {}; }
        catch (e) { const off = !e.status; for (const id of products()) if (canLoad(id).ok && !dirOf(id) && !(o.bundled && o.bundled(id))) set(id, { state: 'error', error: off ? 'No internet connection. It will try again when this Mac is online.' : String(e.message) });
          return { result: off ? 'offline' : 'refused', error: String(e.message || e) }; }
        const todo = [];
        for (const id of products()) {
          if (!canLoad(id).ok || !latest[id]) continue;
          const cur = installed(id);
          if (dirOf(id) && cur && cur.version === latest[id]) { if (!st[id] || st[id].state !== 'ready') set(id, { state: 'ready', version: cur.version }); continue; }
          todo.push(id);
        }
        if (!todo.length) return { result: 'uptodate', games: Object.keys(latest) };
        (async () => { for (const id of todo) await download(id); })().catch(() => {});
        return { result: 'downloading', games: todo };
      } finally { syncing = null; }
    })());
  }

  /* a whole game in one file, for a Mac with no internet: MAGIC, u32 manifest length, signed manifest, then the parts back to back */
  async function importFile(file) {
    let fd; try {
      fd = fs.openSync(file, 'r'); const head = Buffer.alloc(12); fs.readSync(fd, head, 0, 12, 0);
      if (!head.subarray(0, 8).equals(MAGIC)) return { ok: false, error: 'That isn\'t a Show Box game file.' };
      const ml = head.readUInt32BE(8); if (ml > 1e6) return { ok: false, error: 'That game file can\'t be read.' };
      const mb = Buffer.alloc(ml); fs.readSync(fd, mb, 0, ml, 12);
      const r = readManifest(mb.toString('utf8'), pub); if (!r.ok) return r;
      const b = r.b, id = b.product, dir = path.join(DL, id, 'import'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
      set(id, { state: 'checking', error: null, version: b.version });
      let pos = 12 + ml; const files = [];
      for (let i = 0; i < b.parts.length; i++) {
        const f = path.join(dir, 'part-' + String(i + 1).padStart(3, '0')); files.push(f);
        const w = fs.openSync(f, 'w'), chunk = Buffer.alloc(1 << 20); let left = b.parts[i].size;
        while (left > 0) { const got = fs.readSync(fd, chunk, 0, Math.min(chunk.length, left), pos); if (!got) { fs.closeSync(w); throw new Error('The game file is incomplete.'); } fs.writeSync(w, chunk, 0, got); pos += got; left -= got; }
        fs.closeSync(w);
      }
      const ok = await finish(id, b, files); try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {}
      log('game added from a file', id, b.version, file);
      return { ok: true, product: id, version: b.version, waiting: !ok, licensed: canLoad(id).ok };
    } catch (e) { log('game file failed', file, String(e.message || e)); return { ok: false, error: String(e.message || e) }; }
    finally { if (fd) try { fs.closeSync(fd); } catch (e) {} }
  }

  /* tidy leftovers from an interrupted install */
  try { for (const d of fs.readdirSync(DIR)) if (/^\.(old|staging)-/.test(d)) fs.rmSync(path.join(DIR, d), { recursive: true, force: true }); } catch (e) {}
  for (const id of list()) { const v = installed(id); st[id] = { state: 'ready', version: v ? v.version : null }; }

  return { dirOf, list, state: id => st[id] || null, states: () => Object.assign({}, st), download, sync, importFile, applyWaiting, installed };
}
module.exports = { createPacks, readManifest, unpack, MAGIC };

/* St David's Day artwork for the Show Box frame: painted daffodils, a carved Welsh lovespoon and a red kite, lit from the top left.
   DaffArt.piece(name, w, h) -> complete SVG sized w x h px. Boxes in design units (screen 1080 high): DaffArt.BOX[name] = [x, y, w, h]; the anchor is 0,0. */
(function () {
  function f1(n) { return (+n).toFixed(1); }
  function seeded(s) { return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
  var uid = 0;
  function open(p) { var n = p.length, s = 'M' + f1(p[0][0]) + ' ' + f1(p[0][1]);
    for (var i = 0; i < n - 1; i++) { var p0 = p[Math.max(0, i - 1)], p1 = p[i], p2 = p[i + 1], p3 = p[Math.min(n - 1, i + 2)];
      s += ' C' + f1(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + f1(p1[1] + (p2[1] - p0[1]) / 6) + ' ' + f1(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + f1(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + f1(p2[0]) + ' ' + f1(p2[1]); }
    return s; }
  /* a smooth tapered shape around a centre line */
  function taper(pts, ws) { var L = [], R = [], n = pts.length;
    for (var i = 0; i < n; i++) { var a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy) || 1, nx = -dy / d, ny = dx / d, w = ws[i] / 2;
      L.push([pts[i][0] + nx * w, pts[i][1] + ny * w]); R.push([pts[i][0] - nx * w, pts[i][1] - ny * w]); }
    return open(L) + ' L' + f1(R[n - 1][0]) + ' ' + f1(R[n - 1][1]) + open(R.reverse()).replace(/^M[^C]+/, ' ') + 'Z'; }
  function svgWrap(box, body, w, h) { return '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="' + box.join(' ') + '">' + body + '</svg>'; }

  function defs(P) { return '<defs>' +
    '<radialGradient id="' + P + 'pet" cx=".5" cy=".05" r="1.05"><stop offset="0" stop-color="#e9b800"/><stop offset=".25" stop-color="#ffd83a"/><stop offset=".7" stop-color="#ffe979"/><stop offset="1" stop-color="#fff4b8"/></radialGradient>' +
    '<radialGradient id="' + P + 'petB" cx=".5" cy=".05" r="1.05"><stop offset="0" stop-color="#c99200"/><stop offset=".35" stop-color="#f2c21a"/><stop offset="1" stop-color="#f9dc6a"/></radialGradient>' +
    '<linearGradient id="' + P + 'cor" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d77800"/><stop offset=".3" stop-color="#ffb41e"/><stop offset=".55" stop-color="#ffd04a"/><stop offset=".8" stop-color="#f39a0c"/><stop offset="1" stop-color="#b85d00"/></linearGradient>' +
    '<linearGradient id="' + P + 'corV" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc83a"/><stop offset=".3" stop-color="#ffd85e"/><stop offset=".7" stop-color="#f29a10"/><stop offset="1" stop-color="#b45a00"/></linearGradient>' +
    '<radialGradient id="' + P + 'corIn" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#7a3a00"/><stop offset=".55" stop-color="#c46a00"/><stop offset="1" stop-color="#f3a21c"/></radialGradient>' +
    '<linearGradient id="' + P + 'stem" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3f6e34"/><stop offset=".45" stop-color="#8dbb6e"/><stop offset="1" stop-color="#2f5a2a"/></linearGradient>' +
    '<linearGradient id="' + P + 'leaf" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2e5f3a"/><stop offset=".35" stop-color="#6fa27a"/><stop offset=".55" stop-color="#9cc79f"/><stop offset="1" stop-color="#2a5634"/></linearGradient>' +
    '<linearGradient id="' + P + 'spa" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f1dfb8"/><stop offset=".5" stop-color="#c3a170"/><stop offset="1" stop-color="#8a6a3e"/></linearGradient>' +
    '<linearGradient id="' + P + 'bud" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#a98f2a"/><stop offset=".4" stop-color="#f3d65a"/><stop offset=".6" stop-color="#ffe68a"/><stop offset="1" stop-color="#b9961e"/></linearGradient>' +
    '<linearGradient id="' + P + 'wood" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6e4422"/><stop offset=".3" stop-color="#c08850"/><stop offset=".55" stop-color="#e1b27c"/><stop offset=".8" stop-color="#a86e3c"/><stop offset="1" stop-color="#5c3517"/></linearGradient>' +
    '<filter id="' + P + 'grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".035 .9" numOctaves="3" seed="8"/><feColorMatrix type="matrix" values="0 0 0 0 .3  0 0 0 0 .15  0 0 0 0 .05  2.4 0 0 0 -1.05"/></filter>' +
    '<linearGradient id="' + P + 'rib" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#7d0f1c"/><stop offset=".4" stop-color="#d42a3a"/><stop offset=".6" stop-color="#ef5a64"/><stop offset="1" stop-color="#8a1220"/></linearGradient>' +
    '<filter id="' + P + 'sh" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="2" dy="6" stdDeviation="5" flood-color="#0c0614" flood-opacity=".5"/></filter>' +
    '<filter id="' + P + 'b1"><feGaussianBlur stdDeviation="1"/></filter><filter id="' + P + 'b3" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3"/></filter>' +
    '<linearGradient id="' + P + 'ruf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d77a42"/><stop offset=".5" stop-color="#a84a22"/><stop offset="1" stop-color="#6e2a12"/></linearGradient>' +
    '<linearGradient id="' + P + 'wingU" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b9643a"/><stop offset=".55" stop-color="#8a3c1c"/><stop offset="1" stop-color="#3a1a0c"/></linearGradient>' +
    '<radialGradient id="' + P + 'head" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#f1ece4"/><stop offset=".6" stop-color="#c9bfb2"/><stop offset="1" stop-color="#8a7d6e"/></radialGradient>' +
    '</defs>'; }

  /* ---- a daffodil, seen three-quarters on. Centre of the flower at x,y; s scale; tilt = which way the trumpet points (degrees, 0 = at us, + = to the right) ---- */
  function daffodil(P, x, y, s, tilt, rot, rnd) { var o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot || 0) + ') scale(' + f1(s) + ')">';
    var t = (tilt || 0) * Math.PI / 180, sq = Math.cos(t), dx = Math.sin(t);
    /* six petals: three behind (shaded), three in front; the whole ring foreshortened in the direction of the tilt */
    var pet = function (a, L, W, back) { var ca = Math.cos(a), sa = Math.sin(a), tip = [ca * L, sa * L], r = [-sa * W, ca * W];
      var d = 'M' + f1(ca * 6 + r[0] * .3) + ' ' + f1(sa * 6 + r[1] * .3) + ' C' + f1(ca * L * .35 + r[0] * 1.1) + ' ' + f1(sa * L * .35 + r[1] * 1.1) + ' ' + f1(ca * L * .8 + r[0] * .85) + ' ' + f1(sa * L * .8 + r[1] * .85) + ' ' + f1(tip[0]) + ' ' + f1(tip[1]) +
        ' C' + f1(ca * L * .8 - r[0] * .85) + ' ' + f1(sa * L * .8 - r[1] * .85) + ' ' + f1(ca * L * .35 - r[0] * 1.1) + ' ' + f1(sa * L * .35 - r[1] * 1.1) + ' ' + f1(ca * 6 - r[0] * .3) + ' ' + f1(sa * 6 - r[1] * .3) + 'Z';
      var v = ''; for (var i = -2; i <= 2; i++) v += 'M' + f1(ca * 8) + ' ' + f1(sa * 8) + ' Q' + f1(ca * L * .5 + r[0] * i * .25) + ' ' + f1(sa * L * .5 + r[1] * i * .25) + ' ' + f1(ca * L * .9 + r[0] * i * .1) + ' ' + f1(sa * L * .9 + r[1] * i * .1);
      return '<path d="' + d + '" fill="url(#' + P + (back ? 'petB' : 'pet') + ')" stroke="#c99a00" stroke-width=".5" stroke-opacity=".5"/><path d="' + v + '" stroke="#d9a400" stroke-width=".55" fill="none" opacity=".45"/>' +
        '<path d="M' + f1(ca * 10 + r[0] * .4) + ' ' + f1(sa * 10 + r[1] * .4) + ' Q' + f1(ca * L * .5 + r[0] * .6) + ' ' + f1(sa * L * .5 + r[1] * .6) + ' ' + f1(ca * L * .85) + ' ' + f1(sa * L * .85) + '" stroke="#fffbe0" stroke-width="1.6" fill="none" opacity=".55"/>'; };
    o += '<g transform="scale(' + f1(Math.max(.55, sq)) + ' 1) skewY(' + f1(dx * 6) + ')">';
    var a0 = -Math.PI / 2 + (rnd() - .5) * .2;
    for (var i = 0; i < 6; i += 2) o += pet(a0 + Math.PI / 6 + i * Math.PI / 3, 34 + rnd() * 3, 15, true);
    for (i = 0; i < 6; i += 2) o += pet(a0 + i * Math.PI / 3, 35 + rnd() * 3, 16, false);
    o += '<circle cx="0" cy="0" r="9" fill="#c98f00" opacity=".55" filter="url(#' + P + 'b3)"/></g>';
    /* the trumpet: a flared tube from the centre to a frilled rim, pointing out along the tilt */
    var tx = dx * 38, ty = 3, rx = 16 * Math.max(.32, sq) + 1, ry = 16.5, rim = [];
    for (i = 0; i <= 36; i++) { var a = i / 36 * Math.PI * 2, rr = 1 + Math.sin(a * 9) * .07 + Math.sin(a * 4 + 1) * .03; rim.push([tx + Math.cos(a) * rx * rr, ty + Math.sin(a) * ry * rr]); }
    /* the tube from the flower's centre out to the rim, shaded across its width */
    o += '<path d="M0 -9 C' + f1(tx * .5) + ' -10 ' + f1(tx * .8) + ' ' + f1(ty - ry * .7) + ' ' + f1(tx) + ' ' + f1(ty - ry * .95) + ' L' + f1(tx) + ' ' + f1(ty + ry * .95) + ' C' + f1(tx * .8) + ' ' + f1(ty + ry * .7) + ' ' + f1(tx * .5) + ' 10 0 9Z" fill="url(#' + P + 'corV)"/>';
    o += '<path d="M2 -5 C' + f1(tx * .5) + ' -6 ' + f1(tx * .8) + ' ' + f1(ty - ry * .45) + ' ' + f1(tx * .95) + ' ' + f1(ty - ry * .55) + '" stroke="#ffe9a0" stroke-width="2.2" fill="none" opacity=".7"/>';
    o += '<path d="M2 6 C' + f1(tx * .5) + ' 7 ' + f1(tx * .8) + ' ' + f1(ty + ry * .5) + ' ' + f1(tx * .95) + ' ' + f1(ty + ry * .6) + '" stroke="#a85200" stroke-width="1" fill="none" opacity=".45"/>';
    o += '<path d="' + open(rim) + 'Z" fill="url(#' + P + 'cor)" stroke="#a85200" stroke-width=".8"/>';
    o += '<ellipse cx="' + f1(tx + dx * 2) + '" cy="' + f1(ty) + '" rx="' + f1(rx * .74) + '" ry="' + f1(ry * .78) + '" fill="url(#' + P + 'corIn)"/>';
    o += '<path d="M' + f1(tx - 3) + ' ' + f1(ty + 4) + ' l2 -8 M' + f1(tx) + ' ' + f1(ty + 4) + ' l0 -9 M' + f1(tx + 3) + ' ' + f1(ty + 4) + ' l-1 -8" stroke="#ffe27a" stroke-width="1.3" stroke-linecap="round"/>';
    o += '<path d="' + open(rim.slice(20, 33)) + '" stroke="#fff3b0" stroke-width="1.6" fill="none" opacity=".75"/></g>';
    return o; }
  /* the neck behind a flower: the stem bends over, with the papery spathe */
  function stem(P, pts, w) { var ws = pts.map(function (p, i) { return w * (1 - i / pts.length * .25); }); return '<path d="' + taper(pts, ws) + '" fill="url(#' + P + 'stem)"/>'; }
  function spathe(P, x, y, ang) { return '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(ang) + ')"><path d="M-3 0 C-6 -8 -4 -18 2 -24 C4 -16 6 -8 4 0Z" fill="url(#' + P + 'spa)"/><path d="M0 -2 L1 -20" stroke="#fff6dc" stroke-width=".8" opacity=".6"/></g>'; }
  function leaf(P, pts, w) { var n = pts.length, ws = pts.map(function (p, i) { var u = i / (n - 1); return w * (u < .85 ? 1 - u * .2 : (1 - u) / .15 * .8); });
    return '<path d="' + taper(pts, ws) + '" fill="url(#' + P + 'leaf)"/><path d="' + open(pts.slice(0, n - 1)) + '" stroke="#c9e6c4" stroke-width="1.1" fill="none" opacity=".5"/>'; }
  /* a closed bud on its stem: papery tip, yellow showing through */
  function bud(P, x, y, s, rot) { return '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot) + ') scale(' + f1(s) + ')"><path d="M0 0 C-9 -4 -10 -26 0 -44 C10 -26 9 -4 0 0Z" fill="url(#' + P + 'bud)"/>' +
    '<path d="M-2 -6 C-6 -14 -4 -30 0 -40" stroke="#fff6c0" stroke-width="1.5" fill="none" opacity=".7"/><path d="M0 -40 C2 -46 1 -54 4 -58 C0 -52 -2 -46 -2 -40Z" fill="url(#' + P + 'spa)"/><path d="M-5 -2 C-6 -10 -2 -16 0 -18" stroke="#6b5a1e" stroke-width=".7" fill="none" opacity=".5"/></g>'; }

  /* ---- the top-left corner spray (mirrored for the right): daffodils and leaves reaching in from the corner. Anchor = the screen corner ---- */
  function spray(P) { var rnd = seeded(31), o = defs(P), g = '';
    /* leaves fan out from off the corner */
    [[[-30, -20], [60, 40], [150, 70], [230, 80]], [[-30, 0], [40, 70], [90, 150], [120, 220]], [[-20, -30], [90, 10], [190, 18], [270, 30]], [[-30, 10], [20, 100], [50, 180], [56, 250]]].forEach(function (L, i) { g += leaf(P, L, 14 - i); });
    /* three flowers on stems that arch over */
    var fl = [[[-30, -10], [70, 30], [120, 70], [138, 104]], [[-30, 20], [30, 90], [64, 150], [70, 178]], [[-30, -30], [110, -6], [180, 26], [206, 48]]];
    fl.forEach(function (st, i) { g += stem(P, st, 6.5); var e = st[st.length - 1]; g += spathe(P, e[0] - 2, e[1] - 4, 160 + i * 20); });
    g += daffodil(P, 70, 200, 1.1, 58, 30, rnd) + daffodil(P, 150, 126, 1.12, 35, 12, rnd) + daffodil(P, 228, 66, 1.02, 62, 20, rnd);
    g += '<g transform="translate(0 0)">' + leaf(P, [[-20, 40], [40, 90], [70, 140], [84, 170]], 11) + '</g>';
    g += stem(P, [[-30, 40], [10, 110], [20, 170], [16, 236]], 5) + bud(P, 16, 240, .8, 172);
    o += '<g filter="url(#' + P + 'sh)">' + g + '</g>';
    return o; }

  /* ---- a carved Welsh lovespoon hanging on a red ribbon. Anchor = the top of the ribbon loop ---- */
  function lovespoon(P) { var o = defs(P), id = P + 'ls';
    /* outline with carved hearts and a keyhole, evenodd so the cut-outs are holes */
    var outer = 'M-16 24 C-16 14 16 14 16 24 L14 120 C30 128 34 150 22 166 C14 176 8 186 8 196 L8 236 C26 246 34 268 30 292 C26 316 12 330 0 330 C-12 330 -26 316 -30 292 C-34 268 -26 246 -8 236 L-8 196 C-8 186 -14 176 -22 166 C-34 150 -30 128 -14 120Z';
    var heart = function (x, y, s) { return 'M' + f1(x) + ' ' + f1(y + 6 * s) + ' C' + f1(x - 9 * s) + ' ' + f1(y - 1 * s) + ' ' + f1(x - 7 * s) + ' ' + f1(y - 9 * s) + ' ' + f1(x) + ' ' + f1(y - 5 * s) + ' C' + f1(x + 7 * s) + ' ' + f1(y - 9 * s) + ' ' + f1(x + 9 * s) + ' ' + f1(y - 1 * s) + ' ' + f1(x) + ' ' + f1(y + 6 * s) + 'Z'; };
    var holes = heart(0, 46, 1.1) + heart(0, 80, 1.2) + heart(0, 146, 1.5) + 'M-3 102 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0Z M-2 106 L2 106 L3 114 L-3 114Z';
    var d = outer + ' ' + holes;
    o += '<path d="M-4 0 C-14 -6 -14 14 -6 22 M4 0 C14 -6 14 14 6 22" stroke="url(#' + P + 'rib)" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M-8 18 C-20 26 -22 40 -16 52 M8 18 C20 26 24 42 18 54" stroke="url(#' + P + 'rib)" stroke-width="5" fill="none" stroke-linecap="round"/>';
    o += '<g filter="url(#' + P + 'sh)"><path d="' + d + '" fill="url(#' + P + 'wood)" fill-rule="evenodd"/></g>';
    o += '<clipPath id="' + id + '"><path d="' + d + '" clip-rule="evenodd"/></clipPath><g clip-path="url(#' + id + ')"><rect x="-40" y="10" width="80" height="330" filter="url(#' + P + 'grain)" opacity=".85"/>' +
      /* the bowl is hollowed: darker inside, a bright lip */
      '<ellipse cx="2" cy="290" rx="22" ry="32" fill="#3a1e0a" opacity=".35" filter="url(#' + P + 'b3)"/><ellipse cx="-8" cy="276" rx="6" ry="14" fill="#fff3dc" opacity=".35" filter="url(#' + P + 'b1)"/>' +
      '<path d="' + holes + '" fill="none" stroke="#2a1405" stroke-width="2.4" opacity=".7"/><path d="M-8 30 L-6 112 M-4 196 L-4 232" stroke="#fff1d6" stroke-width="2" opacity=".35"/></g>';
    o += '<path d="M-14 22 C-8 12 8 12 14 22" stroke="url(#' + P + 'rib)" stroke-width="7" fill="none"/><path d="M-6 16 L-10 30 L-2 24Z M6 16 L10 30 L2 24Z" fill="#a51a28"/>';
    return o; }

  /* ---- a red kite gliding, seen from below; pose 0 wings level, 1 raised, 2 lowered. Body points right ---- */
  function kite(P, pose) { var o = defs(P), lift = [0, -24, 16][pose];
    var Y = function (sgn, y, k) { return f1(sgn * y + (k || 0) * lift); };
    var wing = function (sgn) { var g = '', id = P + 'w' + (uid++);
      /* the arm: long, narrow, angled back at the wrist */
      var arm = 'M14 ' + Y(sgn, 10) + ' C26 ' + Y(sgn, 30, .1) + ' 32 ' + Y(sgn, 52, .3) + ' 34 ' + Y(sgn, 80, .5) + ' L28 ' + Y(sgn, 96, .6) + ' L-16 ' + Y(sgn, 110, .6) + ' C-30 ' + Y(sgn, 92, .4) + ' -40 ' + Y(sgn, 56, .2) + ' -36 ' + Y(sgn, 10) + 'Z';
      var hand = 'M34 ' + Y(sgn, 80, .5) + ' C30 ' + Y(sgn, 112, .8) + ' 18 ' + Y(sgn, 140, .9) + ' 2 ' + Y(sgn, 162, 1) + ' L-30 ' + Y(sgn, 124, .8) + ' L-16 ' + Y(sgn, 110, .6) + ' L28 ' + Y(sgn, 96, .6) + 'Z';
      /* splayed primaries: the fingers */
      for (var i = 0; i < 6; i++) { var u = i / 5, bx = 30 - u * 52, by = 96 + u * 22, tx = bx - 6 - u * 22, ty = by + 58 - u * 16, w = 9 - u * 2;
        g += '<path d="M' + f1(bx - w / 2) + ' ' + Y(sgn, by, .8) + ' C' + f1(bx - w / 2 - 2) + ' ' + Y(sgn, by + 30, .9) + ' ' + f1(tx - 3) + ' ' + Y(sgn, ty - 8, 1) + ' ' + f1(tx) + ' ' + Y(sgn, ty, 1) + ' C' + f1(tx + 4) + ' ' + Y(sgn, ty - 10, 1) + ' ' + f1(bx + w / 2 + 2) + ' ' + Y(sgn, by + 26, .9) + ' ' + f1(bx + w / 2) + ' ' + Y(sgn, by, .8) + 'Z" fill="#1c0e08" stroke="#3a2214" stroke-width=".6"/>'; }
      g += '<path d="' + hand + '" fill="#2a160c"/>';
      g += '<clipPath id="' + id + '"><path d="' + arm + '"/></clipPath><path d="' + arm + '" fill="url(#' + P + 'ruf)"/><g clip-path="url(#' + id + ')">' +
        /* darker secondaries along the trailing edge, fine barring, a pale streak on the leading edge */
        '<path d="M-34 ' + Y(sgn, 12) + ' C-38 ' + Y(sgn, 56, .2) + ' -30 ' + Y(sgn, 92, .4) + ' -16 ' + Y(sgn, 110, .6) + '" stroke="#3a160a" stroke-width="16" fill="none" opacity=".6" filter="url(#' + P + 'b3)"/>' +
        '<path d="M-24 ' + Y(sgn, 20) + ' L-26 ' + Y(sgn, 70, .3) + ' M-14 ' + Y(sgn, 20) + ' L-14 ' + Y(sgn, 80, .4) + ' M-4 ' + Y(sgn, 20) + ' L-2 ' + Y(sgn, 88, .5) + ' M6 ' + Y(sgn, 20) + ' L10 ' + Y(sgn, 92, .5) + '" stroke="#5a1e0a" stroke-width="1.2" opacity=".55"/>' +
        '<path d="M16 ' + Y(sgn, 14) + ' C26 ' + Y(sgn, 32, .1) + ' 31 ' + Y(sgn, 54, .3) + ' 32 ' + Y(sgn, 78, .5) + '" stroke="#f3c09a" stroke-width="3" fill="none" opacity=".7"/></g>';
      /* the white window at the base of the primaries */
      g += '<path d="M28 ' + Y(sgn, 96, .6) + ' C24 ' + Y(sgn, 112, .75) + ' 14 ' + Y(sgn, 124, .8) + ' 2 ' + Y(sgn, 128, .85) + ' C-6 ' + Y(sgn, 122, .8) + ' -10 ' + Y(sgn, 114, .7) + ' -12 ' + Y(sgn, 108, .6) + 'Z" fill="#f4efe6" opacity=".9"/>' +
        '<path d="M22 ' + Y(sgn, 100, .6) + ' L18 ' + Y(sgn, 118, .75) + ' M12 ' + Y(sgn, 104, .6) + ' L8 ' + Y(sgn, 122, .8) + ' M2 ' + Y(sgn, 106, .6) + ' L-2 ' + Y(sgn, 120, .8) + '" stroke="#8a7a6a" stroke-width="1" opacity=".6"/>';
      return g; };
    var body = 'M60 0 C56 -9 40 -13 20 -12 C0 -11 -30 -9 -50 -6 L-50 6 C-30 9 0 11 20 12 C40 13 56 9 60 0Z';
    var tail = 'M-46 -7 L-112 -26 C-104 -12 -100 -4 -94 0 C-100 4 -104 12 -112 26 L-46 7Z';
    o += '<g filter="url(#' + P + 'sh)"><g transform="scale(1 1.22)">' + wing(1) + wing(-1) + '</g>';
    o += '<path d="' + tail + '" fill="url(#' + P + 'ruf)"/><path d="M-50 0 L-104 0" stroke="#5a200c" stroke-width="1.5" opacity=".5"/><path d="M-60 -6 L-100 -20 M-60 6 L-100 20" stroke="#f0a070" stroke-width="1.4" opacity=".5"/>';
    o += '<path d="' + body + '" fill="url(#' + P + 'ruf)"/>';
    var st = ''; for (var i = 0; i < 12; i++) st += 'M' + f1(30 - i * 6) + ' ' + f1(-6 + (i % 3) * 5) + ' l-5 1.5'; o += '<path d="' + st + '" stroke="#3a1206" stroke-width="1.6" opacity=".6"/>';
    o += '<ellipse cx="50" cy="0" rx="14" ry="10" fill="url(#' + P + 'head)"/><path d="M62 -2 C68 -2 70 2 66 4 L62 3Z" fill="#e8b400"/><path d="M66 1 C69 2 69 4 66 4Z" fill="#2a2a2a"/><circle cx="56" cy="-4" r="2" fill="#f2c200"/><circle cx="56" cy="-4" r=".9" fill="#111"/></g>';
    return o; }

  /* ---- a clump of daffodils for the bottom corners (comes up for a moment). Anchor = ground at 0,0 ---- */
  function clump(P, open_) { var rnd = seeded(open_ ? 57 : 57), o = defs(P), g = '';
    [[-70, 18, -160, -10], [-30, 10, -170, -6], [10, 16, -190, 4], [50, 12, -150, 12], [80, 16, -130, 18], [-100, 14, -120, -20]].forEach(function (l) {
      g += leaf(P, [[l[0], 10], [l[0] + l[3] * .3, l[2] * .4], [l[0] + l[3] * .8, l[2] * .8], [l[0] + l[3] * 1.4, l[2]]], l[1]); });
    var fl = [[-60, -220, -55], [0, -250, 20], [56, -205, 50], [-110, -175, -62], [96, -160, 60]];
    fl.forEach(function (f, i) { var bx = f[0] * .4, pts = [[bx, 10], [bx + (f[0] - bx) * .3, f[1] * .5], [f[0] - 4, f[1] + 30], [f[0], f[1] + 8]]; g += stem(P, pts, 6); });
    fl.forEach(function (f, i) { if (open_) { g += spathe(P, f[0] - 2, f[1] + 12, 170 + f[2] * .5) + daffodil(P, f[0] + 6, f[1] + 2, 1.05, f[2], f[2] * .2, rnd); } else g += bud(P, f[0], f[1] + 14, .9, 160 + f[2] * .5); });
    o += '<g filter="url(#' + P + 'sh)">' + g + '</g>';
    return o; }
  /* one loose petal (for the breeze) */
  function petal(P) { return defs(P) + '<path d="M0 -18 C8 -14 10 4 0 18 C-10 4 -8 -14 0 -18Z" fill="url(#' + P + 'pet)"/><path d="M0 -14 Q2 0 0 14" stroke="#d9a400" stroke-width=".6" fill="none" opacity=".5"/>'; }
  function flower(P) { return defs(P) + '<g filter="url(#' + P + 'sh)">' + daffodil(P, 0, 0, 1, 10, 0, seeded(4)) + '</g>'; }

  var PIECES = {
    spray: [[-40, -40, 330, 330], spray], spoon: [[-44, -10, 88, 350], lovespoon],
    kite0: [[-130, -225, 210, 450], function (P) { return kite(P, 0); }], kite1: [[-130, -225, 210, 450], function (P) { return kite(P, 1); }], kite2: [[-130, -225, 210, 450], function (P) { return kite(P, 2); }],
    clumpOpen: [[-170, -310, 330, 330], function (P) { return clump(P, true); }], clumpBud: [[-170, -310, 330, 330], function (P) { return clump(P, false); }],
    petal: [[-14, -22, 28, 44], petal], flower: [[-50, -50, 100, 100], flower]
  };
  window.DaffArt = { BOX: {}, piece: function (name, w, h) { var p = PIECES[name], P = name + (uid++) + '_'; return svgWrap(p[0], p[1](P), w, h); } };
  Object.keys(PIECES).forEach(function (k) { DaffArt.BOX[k] = PIECES[k][0]; });
})();

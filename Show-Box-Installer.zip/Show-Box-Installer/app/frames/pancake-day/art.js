/* Pancake Day artwork for the Show Box frame: painted, lit from the top left, drawn with gradients, texture and highlights (not clip-art).
   Each piece returns a complete SVG string. PancakeArt.piece(name, w, h) -> svg sized w x h px.
   Pieces are in design units (the screen is 1080 high); each has its own box PancakeArt.BOX[name] = [x, y, w, h] and an anchor (hook or base). */
(function () {
  function f1(n) { return (+n).toFixed(1); }
  function seeded(s) { return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
  var uid = 0;

  /* an irregular ellipse outline (pancakes are never perfect circles): returns points */
  function blob(cx, cy, rx, ry, rnd, amt, n) { var ph = [], pts = [], i; n = n || 72; for (i = 0; i < 5; i++) ph.push([2 + i + Math.floor(rnd() * 2), rnd() * 6.28, (amt || .02) * (1 - i * .15) * (.6 + rnd() * .8)]);
    for (i = 0; i < n; i++) { var a = i / n * Math.PI * 2, r = 1; ph.forEach(function (p) { r += Math.sin(a * p[0] + p[1]) * p[2]; }); pts.push([cx + Math.cos(a) * rx * r, cy + Math.sin(a) * ry * r, a]); }
    return pts; }
  function closed(p) { var n = p.length, s = 'M' + f1(p[0][0]) + ' ' + f1(p[0][1]);
    for (var i = 0; i < n; i++) { var p0 = p[(i - 1 + n) % n], p1 = p[i], p2 = p[(i + 1) % n], p3 = p[(i + 2) % n];
      s += ' C' + f1(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + f1(p1[1] + (p2[1] - p0[1]) / 6) + ' ' + f1(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + f1(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + f1(p2[0]) + ' ' + f1(p2[1]); }
    return s + 'Z'; }
  function open(p) { var n = p.length, s = 'M' + f1(p[0][0]) + ' ' + f1(p[0][1]);
    for (var i = 0; i < n - 1; i++) { var p0 = p[Math.max(0, i - 1)], p1 = p[i], p2 = p[i + 1], p3 = p[Math.min(n - 1, i + 2)];
      s += ' C' + f1(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + f1(p1[1] + (p2[1] - p0[1]) / 6) + ' ' + f1(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + f1(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + f1(p2[0]) + ' ' + f1(p2[1]); }
    return s; }
  function svgWrap(box, body, w, h) { return '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="' + box.join(' ') + '">' + body + '</svg>'; }

  /* ---------- shared gradients and textures (ids prefixed per drawing) ---------- */
  function defs(P) { return '<defs>' +
    /* lacy browning on a pancake face: dark where the noise is high */
    '<filter id="' + P + 'spots" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".045 .11" numOctaves="4" seed="' + (3 + uid % 7) + '"/>' +
      '<feColorMatrix type="matrix" values="0 0 0 0 .42  0 0 0 0 .2  0 0 0 0 .05  4.2 0 0 0 -1.95"/></filter>' +
    '<filter id="' + P + 'lace" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".055" numOctaves="4" seed="' + (11 + uid % 5) + '"/>' +
      '<feColorMatrix type="matrix" values="0 0 0 0 .5  0 0 0 0 .26  0 0 0 0 .07  5 0 0 0 -2.55"/></filter>' +
    /* fine pores on the fluffy sides */
    '<filter id="' + P + 'pores" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".35 .7" numOctaves="2" seed="5"/>' +
      '<feColorMatrix type="matrix" values="0 0 0 0 .55  0 0 0 0 .36  0 0 0 0 .15  3 0 0 0 -1.45"/></filter>' +
    '<filter id="' + P + 'blur3"><feGaussianBlur stdDeviation="3"/></filter><filter id="' + P + 'blur8" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8"/></filter>' +
    '<filter id="' + P + 'blur1"><feGaussianBlur stdDeviation="1.2"/></filter>' +
    '<radialGradient id="' + P + 'top" cx=".45" cy=".42" r=".62"><stop offset="0" stop-color="#b8692a"/><stop offset=".45" stop-color="#c97e33"/><stop offset=".78" stop-color="#dda253"/><stop offset=".93" stop-color="#e9bf74"/><stop offset="1" stop-color="#c98d45"/></radialGradient>' +
    '<radialGradient id="' + P + 'under" cx=".5" cy=".5" r=".6"><stop offset="0" stop-color="#d9a256"/><stop offset=".7" stop-color="#e6bd78"/><stop offset="1" stop-color="#f0d39a"/></radialGradient>' +
    '<linearGradient id="' + P + 'side" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a9622a"/><stop offset=".2" stop-color="#d9a45c"/><stop offset=".42" stop-color="#f3dca4"/><stop offset=".62" stop-color="#efd394"/><stop offset=".85" stop-color="#c8873e"/><stop offset="1" stop-color="#8f4f1f"/></linearGradient>' +
    '<linearGradient id="' + P + 'round" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3a1a06" stop-opacity=".55"/><stop offset=".18" stop-color="#3a1a06" stop-opacity="0"/><stop offset=".38" stop-color="#fff6dc" stop-opacity=".22"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/><stop offset=".85" stop-color="#3a1a06" stop-opacity=".18"/><stop offset="1" stop-color="#3a1a06" stop-opacity=".6"/></linearGradient>' +
    '<linearGradient id="' + P + 'syr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d07a16" stop-opacity=".9"/><stop offset=".5" stop-color="#9a4a08" stop-opacity=".88"/><stop offset="1" stop-color="#5e2704" stop-opacity=".92"/></linearGradient>' +
    '<linearGradient id="' + P + 'syrV" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6b2d05" stop-opacity=".95"/><stop offset=".3" stop-color="#c46c12" stop-opacity=".85"/><stop offset=".45" stop-color="#f4b552" stop-opacity=".9"/><stop offset=".6" stop-color="#b65f0e" stop-opacity=".85"/><stop offset="1" stop-color="#5a2603" stop-opacity=".95"/></linearGradient>' +
    '<radialGradient id="' + P + 'blue" cx=".36" cy=".32" r=".75"><stop offset="0" stop-color="#7d86b8"/><stop offset=".35" stop-color="#3b3f78"/><stop offset=".75" stop-color="#1e1d45"/><stop offset="1" stop-color="#0f0e26"/></radialGradient>' +
    '<radialGradient id="' + P + 'bloom" cx=".5" cy=".5" r=".55"><stop offset=".55" stop-color="#b9c4e6" stop-opacity="0"/><stop offset="1" stop-color="#b9c4e6" stop-opacity=".55"/></radialGradient>' +
    '<radialGradient id="' + P + 'straw" cx=".38" cy=".3" r=".8"><stop offset="0" stop-color="#ff6a5a"/><stop offset=".35" stop-color="#e2232a"/><stop offset=".8" stop-color="#9c0b16"/><stop offset="1" stop-color="#5e040b"/></radialGradient>' +
    '<radialGradient id="' + P + 'strawIn" cx=".5" cy=".45" r=".6"><stop offset="0" stop-color="#fff2ee"/><stop offset=".35" stop-color="#ffc2b8"/><stop offset=".7" stop-color="#f05a52"/><stop offset="1" stop-color="#c3121c"/></radialGradient>' +
    '<linearGradient id="' + P + 'leaf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8fc25a"/><stop offset=".5" stop-color="#4f8a2c"/><stop offset="1" stop-color="#2a5418"/></linearGradient>' +
    '<linearGradient id="' + P + 'butT" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffbe0"/><stop offset=".6" stop-color="#fdf0a8"/><stop offset="1" stop-color="#f3dc7a"/></linearGradient>' +
    '<linearGradient id="' + P + 'butF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8e38e"/><stop offset="1" stop-color="#e2bd52"/></linearGradient>' +
    '<linearGradient id="' + P + 'butS" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#e6c35e"/><stop offset="1" stop-color="#c79d38"/></linearGradient>' +
    '<radialGradient id="' + P + 'plate" cx=".42" cy=".35" r=".75"><stop offset="0" stop-color="#ffffff"/><stop offset=".6" stop-color="#f2f1ee"/><stop offset=".9" stop-color="#d8d6d2"/><stop offset="1" stop-color="#b9b6b2"/></radialGradient>' +
    '<linearGradient id="' + P + 'rim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".5" stop-color="#e9e7e3"/><stop offset="1" stop-color="#a9a6a1"/></linearGradient>' +
    '<radialGradient id="' + P + 'well" cx=".5" cy=".35" r=".7"><stop offset="0" stop-color="#fbfaf8"/><stop offset=".75" stop-color="#ecebe7"/><stop offset="1" stop-color="#cfccc6"/></radialGradient>' +
    '<radialGradient id="' + P + 'lemR" cx=".4" cy=".35" r=".75"><stop offset="0" stop-color="#fff9a8"/><stop offset=".4" stop-color="#ffe23a"/><stop offset=".85" stop-color="#e3b900"/><stop offset="1" stop-color="#a98500"/></radialGradient>' +
    '<radialGradient id="' + P + 'lemF" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#fffbe6"/><stop offset=".4" stop-color="#fff2a0"/><stop offset="1" stop-color="#f6dc55"/></radialGradient>' +
    '<linearGradient id="' + P + 'cu" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd3a8"/><stop offset=".18" stop-color="#e48a4c"/><stop offset=".45" stop-color="#b8582a"/><stop offset=".62" stop-color="#e99a62"/><stop offset=".85" stop-color="#8e3c18"/><stop offset="1" stop-color="#5d2309"/></linearGradient>' +
    '<radialGradient id="' + P + 'cuB" cx=".38" cy=".33" r=".8"><stop offset="0" stop-color="#ffcf9e"/><stop offset=".25" stop-color="#e28a50"/><stop offset=".6" stop-color="#b75628"/><stop offset=".9" stop-color="#7f3214"/><stop offset="1" stop-color="#5a2108"/></radialGradient>' +
    '<linearGradient id="' + P + 'steel" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#5d636b"/><stop offset=".3" stop-color="#e9edf1"/><stop offset=".5" stop-color="#9aa1a9"/><stop offset=".75" stop-color="#f6f8fa"/><stop offset="1" stop-color="#666c74"/></linearGradient>' +
    '<linearGradient id="' + P + 'steelD" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f6f8"/><stop offset=".4" stop-color="#a7adb4"/><stop offset=".7" stop-color="#dde1e5"/><stop offset="1" stop-color="#5b6168"/></linearGradient>' +
    '<linearGradient id="' + P + 'brass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2c4"/><stop offset=".3" stop-color="#d6a84a"/><stop offset=".6" stop-color="#8a6420"/><stop offset=".85" stop-color="#c79a3c"/><stop offset="1" stop-color="#5a3e10"/></linearGradient>' +
    '<radialGradient id="' + P + 'brassR" cx=".38" cy=".33" r=".75"><stop offset="0" stop-color="#fff2c4"/><stop offset=".35" stop-color="#d6a84a"/><stop offset=".8" stop-color="#7d5a1c"/><stop offset="1" stop-color="#4a330c"/></radialGradient>' +
    '<linearGradient id="' + P + 'wood" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6e4220"/><stop offset=".3" stop-color="#c58b52"/><stop offset=".55" stop-color="#e2b07a"/><stop offset=".8" stop-color="#a86d3a"/><stop offset="1" stop-color="#5a3315"/></linearGradient>' +
    '<filter id="' + P + 'grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9 .03" numOctaves="3" seed="8"/><feColorMatrix type="matrix" values="0 0 0 0 .25  0 0 0 0 .12  0 0 0 0 .04  2.2 0 0 0 -.95"/></filter>' +
    '<filter id="' + P + 'brush" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".02 1.2" numOctaves="2" seed="4"/><feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  1.4 0 0 0 -.62"/></filter>' +
    '<linearGradient id="' + P + 'iron" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5a5c62"/><stop offset=".35" stop-color="#2a2b30"/><stop offset=".7" stop-color="#16171a"/><stop offset="1" stop-color="#3a3b40"/></linearGradient>' +
    '<radialGradient id="' + P + 'ironIn" cx=".42" cy=".38" r=".7"><stop offset="0" stop-color="#3a3c42"/><stop offset=".7" stop-color="#1c1d21"/><stop offset="1" stop-color="#0c0c0e"/></radialGradient>' +
    '<linearGradient id="' + P + 'glass" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity=".55"/><stop offset=".12" stop-color="#ffffff" stop-opacity=".12"/><stop offset=".5" stop-color="#ffffff" stop-opacity=".04"/><stop offset=".82" stop-color="#ffffff" stop-opacity=".18"/><stop offset=".92" stop-color="#ffffff" stop-opacity=".6"/><stop offset="1" stop-color="#ffffff" stop-opacity=".2"/></linearGradient>' +
    '<pattern id="' + P + 'ging" width="28" height="28" patternUnits="userSpaceOnUse" patternTransform="rotate(4)"><rect width="28" height="28" fill="#f7f8fb"/><rect width="14" height="28" fill="#2f5fb0" opacity=".55"/><rect width="28" height="14" fill="#2f5fb0" opacity=".55"/>' +
      '<path d="M0 0 L28 28 M-14 14 L14 42 M14 -14 L42 14" stroke="#000" stroke-opacity=".06" stroke-width="1"/></pattern>' +
    '</defs>'; }

  /* ---------- a pancake's lit top face (for the stack and for flipping) ---------- */
  function faceTop(P, cx, cy, rx, ry, rnd, under, plain) { var pts = blob(cx, cy, rx, ry, rnd, .022), d = closed(pts), id = P + 'c' + (uid++), o = '';
    o += '<clipPath id="' + id + '"><path d="' + d + '"/></clipPath><path d="' + d + '" fill="url(#' + P + (under ? 'under' : 'top') + ')"/>';
    o += '<g clip-path="url(#' + id + ')"><rect x="' + f1(cx - rx * 1.1) + '" y="' + f1(cy - ry * 1.3) + '" width="' + f1(rx * 2.2) + '" height="' + f1(ry * 2.6) + '" filter="url(#' + P + (under ? 'lace' : 'spots') + ')" opacity="' + (under ? .75 : .55) + '"/>';
    /* the paler, slightly raised outer ring */
    o += '<path d="' + d + '" fill="none" stroke="#f3d79c" stroke-opacity=".55" stroke-width="' + f1(ry * .22) + '" filter="url(#' + P + 'blur3)"/>';
    /* tiny bubble holes */
    for (var i = 0; i < (under || plain ? 0 : 26); i++) { var a = rnd() * 6.28, r = Math.sqrt(rnd()) * .8, x = cx + Math.cos(a) * rx * r, y = cy + Math.sin(a) * ry * r, s = .9 + rnd() * 1.6;
      o += '<ellipse cx="' + f1(x) + '" cy="' + f1(y) + '" rx="' + f1(s) + '" ry="' + f1(s * .55) + '" fill="#6b3511" opacity=".55"/><ellipse cx="' + f1(x) + '" cy="' + f1(y + s * .35) + '" rx="' + f1(s * .8) + '" ry="' + f1(s * .25) + '" fill="#f6dba0" opacity=".5"/>'; }
    o += '<ellipse cx="' + f1(cx - rx * .3) + '" cy="' + f1(cy - ry * .35) + '" rx="' + f1(rx * .45) + '" ry="' + f1(ry * .3) + '" fill="#fff4d8" opacity=".14" filter="url(#' + P + 'blur8)"/></g>';
    return { svg: o, pts: pts }; }
  /* the side of one pancake: the band between its front edge at the top and at the bottom */
  function sideBand(P, pts, t) { var front = pts.filter(function (p) { return Math.sin(p[2]) >= -0.08; }).sort(function (a, b) { return b[0] - a[0]; });
    var top = front, bot = front.slice().reverse().map(function (p) { return [p[0], p[1] + t]; });
    var d = open(top) + ' L' + f1(bot[0][0]) + ' ' + f1(bot[0][1]) + open(bot).replace(/^M[^C]+/, '') + 'Z', id = P + 'b' + (uid++);
    var x0 = Math.min.apply(null, pts.map(function (p) { return p[0]; })), x1 = Math.max.apply(null, pts.map(function (p) { return p[0]; })), y0 = Math.min.apply(null, top.map(function (p) { return p[1]; })), y1 = Math.max.apply(null, top.map(function (p) { return p[1]; })) + t;
    var arc = function (dy) { return open(top.map(function (p) { return [p[0], p[1] + dy]; })); };
    /* fluffy pale crumb in the middle, golden crust at the top edge, darker crust underneath, all following the curve */
    var o = '<clipPath id="' + id + '"><path d="' + d + '"/></clipPath><path d="' + d + '" fill="#f0d394"/><g clip-path="url(#' + id + ')">' +
      '<path d="' + arc(t * .5) + '" stroke="#f8e6b4" stroke-width="' + f1(t * .35) + '" fill="none" filter="url(#' + P + 'blur3)"/>' +
      '<path d="' + arc(t * .04) + '" stroke="#c88a3e" stroke-width="' + f1(t * .32) + '" fill="none" filter="url(#' + P + 'blur1)"/>' +
      '<path d="' + arc(t * .96) + '" stroke="#9a5420" stroke-width="' + f1(t * .42) + '" fill="none" filter="url(#' + P + 'blur1)"/>' +
      '<rect x="' + f1(x0) + '" y="' + f1(y0) + '" width="' + f1(x1 - x0) + '" height="' + f1(y1 - y0) + '" filter="url(#' + P + 'pores)" opacity=".35"/>' +
      '<rect x="' + f1(x0) + '" y="' + f1(y0) + '" width="' + f1(x1 - x0) + '" height="' + f1(y1 - y0) + '" fill="url(#' + P + 'round)"/></g>';
    return o; }

  /* ---------- small things ---------- */
  function blueberry(P, x, y, r, rnd) { var o = '<ellipse cx="' + f1(x + r * .15) + '" cy="' + f1(y + r * .8) + '" rx="' + f1(r * .95) + '" ry="' + f1(r * .3) + '" fill="#1a0c04" opacity=".35" filter="url(#' + P + 'blur1)"/>';
    o += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" fill="url(#' + P + 'blue)"/><circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" fill="url(#' + P + 'bloom)"/>';
    var a0 = rnd() * 6.28, cx = x + r * .12, cy = y - r * .3, st = ''; for (var i = 0; i < 5; i++) { var a = a0 + i * 1.2566; st += (i ? 'L' : 'M') + f1(cx + Math.cos(a) * r * .3) + ' ' + f1(cy + Math.sin(a) * r * .2) + 'L' + f1(cx + Math.cos(a + .63) * r * .1) + ' ' + f1(cy + Math.sin(a + .63) * r * .07); }
    o += '<path d="' + st + 'Z" fill="#241a35" stroke="#6d6290" stroke-width=".5"/><ellipse cx="' + f1(x - r * .35) + '" cy="' + f1(y - r * .38) + '" rx="' + f1(r * .22) + '" ry="' + f1(r * .14) + '" fill="#fff" opacity=".45"/>';
    return o; }
  function strawHalf(P, x, y, s, rot, rnd) { var o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot) + ') scale(' + f1(s) + ')">';
    var out = 'M0 -22 C14 -24 22 -12 20 2 C18 16 6 26 0 30 C-6 26 -18 16 -20 2 C-22 -12 -14 -24 0 -22Z';
    o += '<ellipse cx="3" cy="31" rx="17" ry="4" fill="#1a0c04" opacity=".3" filter="url(#' + P + 'blur1)"/><path d="' + out + '" fill="url(#' + P + 'straw)"/>';
    o += '<path d="M0 -18 C11 -19 17 -10 16 1 C14 13 5 21 0 25 C-5 21 -14 13 -16 1 C-17 -10 -11 -19 0 -18Z" fill="url(#' + P + 'strawIn)"/>';
    o += '<path d="M0 -14 C4 -6 4 8 0 18 C-4 8 -4 -6 0 -14Z" fill="#fff6f0" opacity=".85"/>';
    var r = ''; for (var i = 0; i < 14; i++) { var a = i / 14 * 6.28, rr = 12 + rnd() * 3; r += 'M' + f1(Math.cos(a) * 4) + ' ' + f1(2 + Math.sin(a) * 6) + ' L' + f1(Math.cos(a) * rr) + ' ' + f1(2 + Math.sin(a) * rr * 1.1); }
    o += '<path d="' + r + '" stroke="#fff0ea" stroke-width=".7" opacity=".55"/>';
    for (i = 0; i < 16; i++) { var a2 = i / 16 * 6.28; o += '<ellipse cx="' + f1(Math.cos(a2) * 15.5) + '" cy="' + f1(3 + Math.sin(a2) * 19) + '" rx=".9" ry="1.3" fill="#f4e08a"/>'; }
    o += '<path d="M-9 -22 C-6 -30 -2 -27 0 -22 C2 -28 7 -30 9 -22" fill="url(#' + P + 'leaf)" stroke="#2a5418" stroke-width=".6"/><ellipse cx="-8" cy="-10" rx="3" ry="5" fill="#fff" opacity=".35"/></g>';
    return o; }
  function lemonWedge(P, x, y, s, rot) { var o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot) + ') scale(' + f1(s) + ')">';
    o += '<ellipse cx="2" cy="12" rx="40" ry="7" fill="#1a0c04" opacity=".3" filter="url(#' + P + 'blur1)"/>';
    /* rind arc, pith, then translucent segments radiating from the core */
    o += '<path d="M-40 4 C-36 -26 36 -26 40 4 C26 10 -26 10 -40 4Z" fill="url(#' + P + 'lemR)"/>';
    o += '<path d="M-36 2 C-32 -20 32 -20 36 2Z" fill="#fff8dc"/><path d="M-32 1 C-28 -16 28 -16 32 1Z" fill="url(#' + P + 'lemF)"/>';
    var sg = ''; for (var i = 1; i < 7; i++) { var a = Math.PI + i / 7 * Math.PI; sg += 'M0 1 L' + f1(Math.cos(a) * 32) + ' ' + f1(1 + Math.sin(a) * 17); } o += '<path d="' + sg + '" stroke="#fffbea" stroke-width="1.6"/>';
    for (i = 0; i < 18; i++) { var a3 = Math.PI + (i + .5) / 18 * Math.PI; o += '<ellipse cx="' + f1(Math.cos(a3) * 20) + '" cy="' + f1(Math.sin(a3) * 10) + '" rx="2.4" ry="1" fill="#fff" opacity=".45" transform="rotate(' + f1(a3 * 57.3 + 90) + ' ' + f1(Math.cos(a3) * 20) + ' ' + f1(Math.sin(a3) * 10) + ')"/>'; }
    o += '<path d="M-40 4 C-26 10 26 10 40 4 C30 13 -30 13 -40 4Z" fill="#c99e00"/><path d="M-30 -16 C-18 -24 10 -25 22 -19" stroke="#fffbd0" stroke-width="2.4" fill="none" opacity=".7" stroke-linecap="round"/></g>';
    return o; }
  function sugar(x0, y0, w, h, n, rnd) { var o = ''; for (var i = 0; i < n; i++) { var x = x0 + rnd() * w, y = y0 + rnd() * h, r = .5 + rnd() * .9; o += '<rect x="' + f1(x) + '" y="' + f1(y) + '" width="' + f1(r * 1.6) + '" height="' + f1(r * 1.6) + '" fill="#fff" opacity="' + f1(.55 + rnd() * .45) + '" transform="rotate(' + f1(rnd() * 90) + ' ' + f1(x) + ' ' + f1(y) + ')"/>'; } return o; }

  /* ---------- plate ---------- */
  function plate(P, cx, cy, rx, ry) { var o = '<ellipse cx="' + f1(cx + 6) + '" cy="' + f1(cy + ry * .45) + '" rx="' + f1(rx * 1.04) + '" ry="' + f1(ry * .9) + '" fill="#0d0603" opacity=".5" filter="url(#' + P + 'blur8)"/>';
    o += '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy + ry * .12) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="url(#' + P + 'rim)"/>';
    o += '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="url(#' + P + 'plate)"/>';
    o += '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy) + '" rx="' + f1(rx * .93) + '" ry="' + f1(ry * .92) + '" fill="none" stroke="#2f5fb0" stroke-width="2.2" opacity=".75"/>';
    o += '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy) + '" rx="' + f1(rx * .9) + '" ry="' + f1(ry * .88) + '" fill="none" stroke="#2f5fb0" stroke-width=".8" opacity=".55"/>';
    o += '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy + ry * .04) + '" rx="' + f1(rx * .68) + '" ry="' + f1(ry * .62) + '" fill="url(#' + P + 'well)"/>';
    o += '<path d="M' + f1(cx - rx * .68) + ' ' + f1(cy + ry * .04) + ' A' + f1(rx * .68) + ' ' + f1(ry * .62) + ' 0 0 1 ' + f1(cx + rx * .68) + ' ' + f1(cy + ry * .04) + '" fill="none" stroke="#9e9a94" stroke-width="2" opacity=".45" filter="url(#' + P + 'blur1)"/>';
    o += '<path d="M' + f1(cx - rx * .82) + ' ' + f1(cy - ry * .45) + ' Q' + f1(cx - rx * .4) + ' ' + f1(cy - ry * .98) + ' ' + f1(cx + rx * .1) + ' ' + f1(cy - ry * .95) + '" stroke="#fff" stroke-width="3" fill="none" opacity=".8" stroke-linecap="round"/>';
    return o; }

  /* ---------- the stack (left bottom corner): seven thick pancakes, syrup, butter, berries ---------- */
  var STACK = { cx: 0, base: 0, rx: 126, ry: 36, t: 19, n: 6 };
  function stackBody(P, rnd, n) { var o = '', cx = STACK.cx, y = STACK.base, tops = [];
    for (var i = 0; i < n; i++) { var rx = STACK.rx * (.96 + rnd() * .06), ox = (rnd() - .5) * 7, gap = STACK.t * (.92 + rnd() * .14); y -= gap;
      var f = faceTop(P, cx + ox, y, rx, STACK.ry * rx / STACK.rx, rnd, false, i < n - 1);
      if (i) o += '<path d="' + open(f.pts.filter(function (p) { return Math.sin(p[2]) >= 0; }).sort(function (a, b) { return b[0] - a[0]; }).map(function (p) { return [p[0], p[1] + gap + 2]; })) + '" stroke="#1e0c03" stroke-width="5" fill="none" opacity=".55" filter="url(#' + P + 'blur3)"/>';
      o += f.svg + sideBand(P, f.pts, gap + 2); tops.push([cx + ox, y, rx]); }
    return { svg: o, top: tops[tops.length - 1], tops: tops }; }
  /* a syrup drip running down the side of the stack: tapering, swelling where it catches on each pancake's lip */
  function drip(P, x, y0, L, w, lips, rnd) { var pts = [], ws = [], n = 14, i;
    for (i = 0; i <= n; i++) { var u = i / n, yy = y0 + L * u, sw = 1; lips.forEach(function (ly) { var d = (yy - ly) / 7; sw += Math.exp(-d * d) * .35; });
      pts.push([x + Math.sin(u * 3 + x) * 1.2, yy]); ws.push(w * (1.25 - u * .45) * sw); }
    var L2 = [], R2 = []; pts.forEach(function (p, i) { L2.push([p[0] - ws[i] / 2, p[1]]); R2.push([p[0] + ws[i] / 2, p[1]]); });
    var e = pts[n], bw = ws[n] * .75, d = open(L2) + ' C' + f1(e[0] - bw) + ' ' + f1(e[1] + bw * 1.8) + ' ' + f1(e[0] + bw) + ' ' + f1(e[1] + bw * 1.8) + ' ' + f1(R2[n][0]) + ' ' + f1(R2[n][1]) + open(R2.reverse()).replace(/^M[^C]+/, ' ') + 'Z';
    d = d.replace(/Z$/, '') + 'Z';
    return '<path d="' + d + '" fill="url(#' + P + 'syrV)"/><path d="' + open(pts.slice(1, n - 1).map(function (p) { return [p[0] - w * .22, p[1]]; })) + '" stroke="#fff1c4" stroke-width="' + f1(w * .2) + '" fill="none" opacity=".6" stroke-linecap="round"/>' +
      '<ellipse cx="' + f1(e[0] - bw * .3) + '" cy="' + f1(e[1] + bw * .6) + '" rx="' + f1(bw * .28) + '" ry="' + f1(bw * .42) + '" fill="#fff6d6" opacity=".75"/>'; }
  function syrupTop(P, x, y, rx, ry, rnd, drips) { var pts = blob(x - rx * .05, y + ry * .05, rx * .72, ry * .7, rnd, .07, 48), o = '';
    o += '<path d="' + closed(pts) + '" fill="url(#' + P + 'syr)"/>';
    /* drips over the front edge and down the side */
    STACK.drips = []; (drips || []).forEach(function (d) { var dx = x + rx * d[0], top = y + ry * Math.sqrt(Math.max(0, 1 - d[0] * d[0])) * .7; STACK.drips.push([dx, top, d[1], d[2]]); o += drip(P, dx, top, d[1], d[2], STACK.lips.map(function (l) { return l + ry * Math.sqrt(Math.max(0, 1 - d[0] * d[0])); }), rnd); });
    /* gloss: a long reflected window highlight and a few sparkles */
    o += '<path d="' + open([[x - rx * .5, y - ry * .2], [x - rx * .2, y - ry * .45], [x + rx * .2, y - ry * .42]]) + '" stroke="#fff7dc" stroke-width="4" fill="none" opacity=".7" stroke-linecap="round"/>';
    o += '<path d="' + open([[x - rx * .45, y + ry * .25], [x - rx * .1, y + ry * .4], [x + rx * .35, y + ry * .3]]) + '" stroke="#ffd58a" stroke-width="2" fill="none" opacity=".55" stroke-linecap="round"/>';
    o += '<circle cx="' + f1(x + rx * .3) + '" cy="' + f1(y - ry * .1) + '" r="2.2" fill="#fff" opacity=".9"/><circle cx="' + f1(x - rx * .55) + '" cy="' + f1(y + ry * .05) + '" r="1.5" fill="#fff" opacity=".8"/>';
    return o; }
  function butter(P, x, y, s) { var w = 30 * s, d = 12 * s, h = 16 * s, o = '';
    o += '<ellipse cx="' + f1(x + 4 * s) + '" cy="' + f1(y + 2 * s) + '" rx="' + f1(w * .95) + '" ry="' + f1(d * 1.1) + '" fill="#ffe680" opacity=".75"/>' +
      '<ellipse cx="' + f1(x + 2 * s) + '" cy="' + f1(y) + '" rx="' + f1(w * .7) + '" ry="' + f1(d * .8) + '" fill="#fff6b8" opacity=".6"/>';
    /* a slightly slumped cube: top, front, side with soft corners */
    var tl = [x - w * .5, y - h - d * .5], tr = [x + w * .35, y - h - d * .7], br = [x + w * .5, y - h + d * .3], bl = [x - w * .35, y - h + d * .5];
    o += '<path d="M' + f1(bl[0]) + ' ' + f1(bl[1]) + ' L' + f1(br[0]) + ' ' + f1(br[1]) + ' L' + f1(br[0] + 1 * s) + ' ' + f1(br[1] + h) + ' Q' + f1(x) + ' ' + f1(y + d * .9) + ' ' + f1(bl[0] - 1 * s) + ' ' + f1(bl[1] + h) + 'Z" fill="url(#' + P + 'butF)"/>';
    o += '<path d="M' + f1(tl[0]) + ' ' + f1(tl[1]) + ' L' + f1(bl[0]) + ' ' + f1(bl[1]) + ' L' + f1(bl[0] - 1 * s) + ' ' + f1(bl[1] + h) + ' Q' + f1(tl[0] - 3 * s) + ' ' + f1(tl[1] + h + 3 * s) + ' ' + f1(tl[0] - 1 * s) + ' ' + f1(tl[1] + h * .8) + 'Z" fill="url(#' + P + 'butS)"/>';
    o += '<path d="M' + f1(tl[0]) + ' ' + f1(tl[1]) + ' Q' + f1(x) + ' ' + f1(tl[1] - 2 * s) + ' ' + f1(tr[0]) + ' ' + f1(tr[1]) + ' L' + f1(br[0]) + ' ' + f1(br[1]) + ' Q' + f1(x) + ' ' + f1(br[1] + 2 * s) + ' ' + f1(bl[0]) + ' ' + f1(bl[1]) + 'Z" fill="url(#' + P + 'butT)"/>';
    o += '<path d="M' + f1(tl[0] + 3 * s) + ' ' + f1(tl[1] + 1 * s) + ' L' + f1(tr[0] - 4 * s) + ' ' + f1(tr[1] + 1 * s) + '" stroke="#fff" stroke-width="' + f1(1.6 * s) + '" opacity=".8" stroke-linecap="round"/>';
    o += '<path d="M' + f1(bl[0] + 2 * s) + ' ' + f1(bl[1] + h * .9) + ' Q' + f1(x) + ' ' + f1(y + d * .6) + ' ' + f1(br[0] - 2 * s) + ' ' + f1(br[1] + h * .9) + '" stroke="#fffbe0" stroke-width="' + f1(1.6 * s) + '" fill="none" opacity=".7"/>';
    return o; }

  /* the whole left corner: plate, stack, syrup, butter and berries. Anchor: plate centre at 0,0 */
  function stackCorner(P) { var rnd = seeded(41), o = defs(P);
    o += plate(P, 0, 0, 200, 52);
    STACK.cx = -6; STACK.base = 8; var s = stackBody(P, rnd, STACK.n), top = s.top; o += s.svg; STACK.lips = s.tops.map(function (t) { return t[1]; }); STACK.top = top;
    o += syrupTop(P, top[0], top[1], top[2], STACK.ry, rnd, [[-.66, 52, 9], [-.24, 96, 11], [.3, 34, 8], [.62, 74, 10]]);
    o += butter(P, top[0] + 6, top[1] - 4, 1.35);
    o += blueberry(P, top[0] - 62, top[1] + 4, 9.5, rnd) + blueberry(P, top[0] + 52, top[1] - 6, 9, rnd) + blueberry(P, top[0] + 70, top[1] + 10, 9.5, rnd);
    o += strawHalf(P, top[0] - 34, top[1] - 12, .85, -18, rnd);
    /* on the plate */
    o += blueberry(P, -170, 10, 10, rnd) + blueberry(P, -152, 24, 9.5, rnd) + blueberry(P, 152, 20, 10, rnd) + blueberry(P, 170, 4, 9, rnd) + blueberry(P, 136, 34, 9.5, rnd);
    o += strawHalf(P, -140, 28, 1.05, 24, rnd) + strawHalf(P, 158, -14, .95, -30, rnd);
    return o; }
  /* the right corner: thin British pancakes folded in quarters, lemon and sugar. Anchor: plate centre at 0,0 */
  function crepe(P, x, y, R, rot, rnd) { var id = P + 'cr' + (uid++), o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') scale(1 .42) rotate(' + f1(rot) + ')">';
    /* a quarter-folded thin pancake: a fan with a round outer edge, the fold edges slightly puffed, lacy brown pattern */
    var p = 'M0 0 L' + f1(R) + ' -6 '; for (var i = 0; i <= 20; i++) { var a = -0.06 + i / 20 * 1.68, r = R * (1 + Math.sin(i * 1.7 + rnd() * 2) * .018); p += 'L' + f1(Math.cos(a) * r) + ' ' + f1(Math.sin(a) * r) + ' '; } p += 'Z';
    o += '<path d="' + p + '" fill="#2a1205" opacity=".35" transform="translate(4 10)" filter="url(#' + P + 'blur3)"/>';
    o += '<clipPath id="' + id + '"><path d="' + p + '"/></clipPath><path d="' + p + '" fill="url(#' + P + 'under)"/><g clip-path="url(#' + id + ')"><rect x="-10" y="-20" width="' + f1(R + 30) + '" height="' + f1(R + 30) + '" filter="url(#' + P + 'lace)" opacity=".85"/>' +
      '<path d="M0 0 L' + f1(R) + ' -6" stroke="#fff3d0" stroke-width="10" opacity=".35" filter="url(#' + P + 'blur3)"/><path d="M0 0 L' + f1(Math.cos(1.62) * R) + ' ' + f1(Math.sin(1.62) * R) + '" stroke="#5a2a0a" stroke-width="9" opacity=".25" filter="url(#' + P + 'blur3)"/></g>';
    o += '<path d="' + p + '" fill="none" stroke="#b77a38" stroke-width="1.6" opacity=".7"/>';
    /* the fold edge on top, a soft rolled lip */
    o += '<path d="M2 -1 L' + f1(R - 2) + ' -7" stroke="#f4dba6" stroke-width="3.2" stroke-linecap="round" opacity=".9"/></g>';
    return o; }
  /* a thin pancake rolled up, lying on the plate: lit cylinder with lacy browning, the spiral showing at the near end. Local: along +x, length L, radius r */
  function roll(P, x, y, L, r, rot, rnd) { var id = P + 'rl' + (uid++), o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot) + ')">';
    var body = 'M0 ' + (-r) + ' L' + L + ' ' + f1(-r * .96) + ' C' + f1(L + r * .5) + ' ' + f1(-r * .9) + ' ' + f1(L + r * .5) + ' ' + f1(r * .9) + ' ' + L + ' ' + f1(r * .96) + ' L0 ' + r + 'Z';
    o += '<ellipse cx="' + f1(L / 2 + 6) + '" cy="' + f1(r * .95) + '" rx="' + f1(L / 2 + 16) + '" ry="' + f1(r * .38) + '" fill="#1a0c04" opacity=".45" filter="url(#' + P + 'blur3)"/>';
    o += '<linearGradient id="' + id + 'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f7e2ad"/><stop offset=".22" stop-color="#f1cf86"/><stop offset=".55" stop-color="#d9a256"/><stop offset=".85" stop-color="#a4652a"/><stop offset="1" stop-color="#6e3a12"/></linearGradient>';
    o += '<clipPath id="' + id + '"><path d="' + body + '"/></clipPath><path d="' + body + '" fill="url(#' + id + 'g)"/><g clip-path="url(#' + id + ')">' +
      '<rect x="-10" y="' + (-r - 4) + '" width="' + (L + r + 20) + '" height="' + (2 * r + 8) + '" filter="url(#' + P + 'lace)" opacity=".62"/>' +
      '<rect x="-10" y="' + f1(-r * .62) + '" width="' + (L + r + 20) + '" height="' + f1(r * .3) + '" fill="#fff8e0" opacity=".35" filter="url(#' + P + 'blur3)"/>' +
      '<rect x="-10" y="' + f1(r * .55) + '" width="' + (L + r + 20) + '" height="' + f1(r * .5) + '" fill="#2a1205" opacity=".3" filter="url(#' + P + 'blur3)"/>' +
      /* the outer edge of the pancake, lying along the roll */
      '<path d="M8 ' + f1(r * .25) + ' C' + f1(L * .3) + ' ' + f1(r * .35) + ' ' + f1(L * .7) + ' ' + f1(r * .2) + ' ' + f1(L + 4) + ' ' + f1(r * .3) + '" stroke="#8a4c1c" stroke-width="1.6" fill="none" opacity=".7"/>' +
      '<path d="M8 ' + f1(r * .25 - 2) + ' C' + f1(L * .3) + ' ' + f1(r * .35 - 2) + ' ' + f1(L * .7) + ' ' + f1(r * .2 - 2) + ' ' + f1(L + 4) + ' ' + f1(r * .3 - 2) + '" stroke="#fbe8bd" stroke-width="1.2" fill="none" opacity=".6"/></g>';
    /* soft creases along the roll (a thin pancake rolls loosely) */
    o += '<path d="M' + f1(L * .3) + ' ' + f1(-r * .9) + ' C' + f1(L * .34) + ' ' + f1(-r * .3) + ' ' + f1(L * .3) + ' ' + f1(r * .3) + ' ' + f1(L * .33) + ' ' + f1(r * .9) + '" stroke="#7a4518" stroke-width="2.4" fill="none" opacity=".22" filter="url(#' + P + 'blur1)"/>' +
      '<path d="M' + f1(L * .72) + ' ' + f1(-r * .9) + ' C' + f1(L * .7) + ' ' + f1(-r * .2) + ' ' + f1(L * .75) + ' ' + f1(r * .4) + ' ' + f1(L * .71) + ' ' + f1(r * .9) + '" stroke="#7a4518" stroke-width="2.4" fill="none" opacity=".18" filter="url(#' + P + 'blur1)"/>';
    /* the near end: a dark hollow inside, the pancake's edge curling round it in two loose layers */
    o += '<ellipse cx="0" cy="0" rx="' + f1(r * .5) + '" ry="' + r + '" fill="#e9c27c"/><ellipse cx="' + f1(r * .04) + '" cy="' + f1(r * .02) + '" rx="' + f1(r * .36) + '" ry="' + f1(r * .78) + '" fill="#4a2408"/>';
    o += '<path d="M' + f1(r * .02) + ' ' + f1(-r * .78) + ' C' + f1(r * .3) + ' ' + f1(-r * .7) + ' ' + f1(r * .34) + ' ' + f1(r * .5) + ' ' + f1(r * .06) + ' ' + f1(r * .62) + ' C' + f1(-r * .16) + ' ' + f1(r * .7) + ' ' + f1(-r * .3) + ' ' + f1(r * .1) + ' ' + f1(-r * .2) + ' ' + f1(-r * .2) + '" stroke="#f0cf8e" stroke-width="' + f1(r * .14) + '" fill="none" stroke-linecap="round"/>';
    o += '<path d="M' + f1(r * .02) + ' ' + f1(-r * .78) + ' C' + f1(r * .3) + ' ' + f1(-r * .7) + ' ' + f1(r * .34) + ' ' + f1(r * .5) + ' ' + f1(r * .06) + ' ' + f1(r * .62) + '" stroke="#a8682c" stroke-width="1" fill="none" opacity=".7" transform="translate(' + f1(r * .07) + ' 0)"/>';
    o += '<ellipse cx="0" cy="0" rx="' + f1(r * .5) + '" ry="' + r + '" fill="none" stroke="#c48a45" stroke-width="1.4"/><path d="M' + f1(-r * .44) + ' ' + f1(-r * .4) + ' C' + f1(-r * .4) + ' ' + f1(-r * .8) + ' ' + f1(-r * .1) + ' ' + f1(-r * 1) + ' ' + f1(r * .1) + ' ' + f1(-r * .98) + '" stroke="#fff4d6" stroke-width="1.6" fill="none" opacity=".7"/></g>';
    return o; }
  function crepeCorner(P) { var rnd = seeded(77), o = defs(P);
    o += plate(P, 0, 0, 200, 52);
    o += roll(P, -128, -22, 150, 26, 8, rnd) + roll(P, -116, 10, 156, 27, 6, rnd);
    /* caster sugar over the rolls, some on the plate */
    o += sugar(-128, -40, 180, 76, 300, rnd) + sugar(-60, 44, 120, 14, 30, rnd);
    o += lemonWedge(P, 120, -18, 1.05, -14) + lemonWedge(P, 142, 18, .95, 10);
    o += '<g opacity=".6">' + sugar(100, -40, 70, 30, 25, rnd) + '</g>';
    return o; }

  /* ---------- the kitchen rail in a top corner with a gingham tea towel over it ---------- */
  function rail(P, len) { var o = defs(P), y = 40;
    /* wall brackets */
    [len * .2, len * .82].forEach(function (x) { o += '<ellipse cx="' + f1(x + 3) + '" cy="' + f1(y - 18) + '" rx="13" ry="13" fill="#000" opacity=".45" filter="url(#' + P + 'blur3)"/>' +
      '<circle cx="' + f1(x) + '" cy="' + f1(y - 22) + '" r="12" fill="url(#' + P + 'brassR)"/><rect x="' + f1(x - 3.5) + '" y="' + f1(y - 22) + '" width="7" height="22" fill="url(#' + P + 'brass)" transform="rotate(0)"/>'; });
    o += '<rect x="-20" y="' + f1(y - 6 + 7) + '" width="' + f1(len + 20) + '" height="12" rx="6" fill="#000" opacity=".4" filter="url(#' + P + 'blur3)"/>';
    o += '<rect x="-20" y="' + f1(y - 6) + '" width="' + f1(len + 20) + '" height="12" rx="6" fill="url(#' + P + 'brass)"/>';
    o += '<circle cx="' + f1(len + 4) + '" cy="' + f1(y) + '" r="10" fill="url(#' + P + 'brassR)"/><circle cx="' + f1(len + 14) + '" cy="' + f1(y) + '" r="6" fill="url(#' + P + 'brassR)"/>';
    return o; }
  function towel(P) { var o = defs(P), rnd = seeded(9);
    /* hangs over the rail at 0,0: back half shorter, front half long, soft vertical folds, a red stripe near the hem */
    var w = 104, L = 180, top = 'M-' + w / 2 + ' 0 C-' + w / 2 + ' -10 ' + w / 2 + ' -10 ' + w / 2 + ' 0', folds = [];
    var hem = []; for (var i = 0; i <= 10; i++) hem.push([-w / 2 - 4 + i / 10 * (w + 8), L + Math.sin(i * 1.3) * 6 + (i % 2 ? 4 : -2)]);
    var shape = 'M' + (-w / 2) + ' -2 C' + (-w / 2) + ' -12 ' + (w / 2) + ' -12 ' + (w / 2) + ' -2 C' + (w / 2 + 2) + ' 60 ' + (w / 2 + 6) + ' 120 ' + f1(hem[10][0]) + ' ' + f1(hem[10][1]);
    for (i = 9; i >= 0; i--) shape += ' L' + f1(hem[i][0]) + ' ' + f1(hem[i][1]); shape += ' C' + (-w / 2 - 6) + ' 120 ' + (-w / 2 - 2) + ' 60 ' + (-w / 2) + ' -2Z';
    var id = P + 'tw' + (uid++);
    o += '<path d="' + shape + '" fill="#000" opacity=".45" transform="translate(6 8)" filter="url(#' + P + 'blur8)"/>';
    o += '<clipPath id="' + id + '"><path d="' + shape + '"/></clipPath><path d="' + shape + '" fill="url(#' + P + 'ging)"/><g clip-path="url(#' + id + ')">';
    o += '<rect x="-80" y="' + (L - 38) + '" width="160" height="7" fill="#c8323a" opacity=".85"/><rect x="-80" y="' + (L - 28) + '" width="160" height="2.5" fill="#c8323a" opacity=".8"/>';
    /* folds: dark hollows and light ridges, running down from the rail */
    [[-36, .3], [-14, .22], [10, .28], [32, .25]].forEach(function (f, j) { o += '<path d="M' + f[0] + ' 4 C' + (f[0] - 4) + ' 70 ' + (f[0] + 6) + ' 130 ' + (f[0] - 2) + ' ' + (L + 10) + '" stroke="#0a1430" stroke-width="12" opacity="' + f[1] + '" fill="none" filter="url(#' + P + 'blur8)"/>' +
      '<path d="M' + (f[0] + 11) + ' 4 C' + (f[0] + 8) + ' 70 ' + (f[0] + 17) + ' 130 ' + (f[0] + 10) + ' ' + (L + 10) + '" stroke="#fff" stroke-width="7" opacity=".22" fill="none" filter="url(#' + P + 'blur3)"/>'; });
    o += '<rect x="-80" y="-14" width="160" height="26" fill="#0a1430" opacity=".35" filter="url(#' + P + 'blur3)"/></g>';
    o += '<path d="M' + (-w / 2) + ' -2 C' + (-w / 2) + ' -12 ' + (w / 2) + ' -12 ' + (w / 2) + ' -2" stroke="#fff" stroke-width="3" fill="none" opacity=".5"/>';
    /* frayed threads along the hem */
    var th = ''; hem.forEach(function (p, j) { if (j < 10) for (var t = 0; t < 6; t++) { var u = t / 6, x = p[0] + (hem[j + 1][0] - p[0]) * u, y = p[1] + (hem[j + 1][1] - p[1]) * u; th += 'M' + f1(x) + ' ' + f1(y - 1) + ' l' + f1((rnd() - .5) * 2) + ' ' + f1(3 + rnd() * 4); } });
    o += '<path d="' + th + '" stroke="#e8ecf5" stroke-width=".9" opacity=".8"/>';
    return o; }

  /* ---------- utensils that hang from S-hooks (anchor = hook point at 0,0, hanging down) ---------- */
  function hook(P) { return '<path d="M0 -10 C8 -10 8 0 0 0 C-7 0 -7 9 0 10" stroke="url(#' + P + 'steel)" stroke-width="3" fill="none" stroke-linecap="round"/>'; }
  function copperPan(P) { var o = defs(P) + hook(P), r = 74, cy = 10 + 120 + r;
    /* handle up to the hook (riveted copper/brass), then the round base seen face on: hand-spun rings, warm reflections */
    o += '<path d="M-9 14 C-9 6 9 6 9 14 L11 128 L-11 128Z" fill="#000" opacity=".35" transform="translate(5 6)" filter="url(#' + P + 'blur3)"/>';
    o += '<path d="M-8 10 C-8 2 8 2 8 10 L10 130 L-10 130Z" fill="url(#' + P + 'brass)"/><circle cx="0" cy="14" r="5" fill="#1c0f05"/><circle cx="0" cy="14" r="5" fill="none" stroke="#fff2c4" stroke-width="1" opacity=".6"/>';
    o += '<circle cx="5" cy="' + (cy + 10) + '" r="' + r + '" fill="#000" opacity=".45" filter="url(#' + P + 'blur8)"/>';
    o += '<circle cx="0" cy="' + cy + '" r="' + r + '" fill="url(#' + P + 'cuB)"/>';
    for (var i = 1; i < 14; i++) o += '<circle cx="0" cy="' + cy + '" r="' + f1(r * i / 14) + '" fill="none" stroke="' + (i % 2 ? '#fff' : '#3a1405') + '" stroke-width=".7" opacity="' + (i % 2 ? .12 : .16) + '"/>';
    o += '<circle cx="0" cy="' + cy + '" r="' + (r - 3) + '" fill="none" stroke="#5a2108" stroke-width="3" opacity=".6"/><circle cx="0" cy="' + cy + '" r="' + (r - 1) + '" fill="none" stroke="#ffc690" stroke-width="2" opacity=".55"/>';
    o += '<path d="M-48 ' + (cy - 38) + ' A60 60 0 0 1 20 ' + (cy - 58) + '" stroke="#fff" stroke-width="7" fill="none" opacity=".5" stroke-linecap="round" filter="url(#' + P + 'blur1)"/>';
    o += '<path d="M44 ' + (cy + 40) + ' A60 60 0 0 1 -10 ' + (cy + 60) + '" stroke="#ffb27a" stroke-width="4" fill="none" opacity=".35" stroke-linecap="round"/>';
    /* the rivets where the handle meets the pan */
    o += '<path d="M-12 120 L12 120 L10 ' + (cy - r + 14) + ' L-10 ' + (cy - r + 14) + 'Z" fill="url(#' + P + 'cu)"/><circle cx="-5" cy="' + (cy - r + 4) + '" r="3.4" fill="url(#' + P + 'brassR)"/><circle cx="5" cy="' + (cy - r + 4) + '" r="3.4" fill="url(#' + P + 'brassR)"/>';
    return o; }
  function whisk(P) { var o = defs(P) + hook(P), hl = 96, bl = 150;
    o += '<path d="M-6 14 L6 14 L7 ' + (10 + hl) + ' L-7 ' + (10 + hl) + 'Z" fill="#000" opacity=".35" transform="translate(4 6)" filter="url(#' + P + 'blur3)"/>';
    o += '<circle cx="0" cy="13" r="5" fill="none" stroke="url(#' + P + 'steel)" stroke-width="2.5"/>';
    o += '<path d="M-6 18 L6 18 L7 ' + (10 + hl) + ' L-7 ' + (10 + hl) + 'Z" fill="url(#' + P + 'steel)"/><path d="M-7 ' + (10 + hl) + ' L7 ' + (10 + hl) + '" stroke="#5d636b" stroke-width="2"/>';
    /* the balloon of wires: loops in planes turned round the handle's axis, all meeting at the tip; the back half of each loop darker */
    var y0 = 10 + hl, W = 46;
    [0, 1].forEach(function (pass) { for (var j = 0; j < 8; j++) { var th = (j + .5) / 8 * Math.PI, w = W * Math.cos(th), z = Math.sin(th);
      var half = function (sx) { return 'M' + f1(sx * 3) + ' ' + y0 + ' C' + f1(w * sx * .9) + ' ' + f1(y0 + bl * .28) + ' ' + f1(w * sx * 1.12) + ' ' + f1(y0 + bl * .9) + ' 0 ' + f1(y0 + bl); };
      [1, -1].forEach(function (sx) { var front = (sx > 0) === (j % 2 === 0); if ((pass === 1) !== front) return; var p = half(sx);
        o += '<path d="' + p + '" stroke="' + (front ? '#80878f' : '#4b5058') + '" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="' + p + '" stroke="#fff" stroke-width="1" fill="none" opacity="' + (front ? .75 : .22) + '" transform="translate(-.6 0)"/>'; }); } });
    o += '<path d="M-8 ' + (y0 - 2) + ' L8 ' + (y0 - 2) + ' L5 ' + (y0 + 12) + ' L-5 ' + (y0 + 12) + 'Z" fill="url(#' + P + 'steel)"/>';
    return o; }
  function slice(P) { var o = defs(P) + hook(P), id = P + 'sl';
    /* a wooden pancake turner: long handle with a hole, wide slotted blade */
    var sh = 'M-7 6 C-7 -2 7 -2 7 6 L8 160 C20 168 36 176 38 190 L40 262 C40 272 -40 272 -40 262 L-38 190 C-36 176 -20 168 -8 160Z';
    o += '<path d="' + sh + '" fill="#000" opacity=".35" transform="translate(6 7)" filter="url(#' + P + 'blur3)"/>';
    o += '<clipPath id="' + id + '"><path d="' + sh + '"/></clipPath><path d="' + sh + '" fill="url(#' + P + 'wood)"/><g clip-path="url(#' + id + ')"><rect x="-45" y="0" width="90" height="280" filter="url(#' + P + 'grain)" opacity=".9"/></g>';
    o += '<circle cx="0" cy="14" r="4.5" fill="#1a0c04"/>';
    [-20, -7, 7, 20].forEach(function (x) { o += '<rect x="' + (x - 3) + '" y="200" width="6" height="52" rx="3" fill="#2b1608"/><rect x="' + (x - 3) + '" y="200" width="2" height="52" rx="1" fill="#e2b07a" opacity=".5"/>'; });
    o += '<path d="M-4 10 L-3 155" stroke="#fff3dc" stroke-width="2" opacity=".35"/>';
    return o; }
  function ladle(P) { var o = defs(P) + hook(P);
    o += '<path d="M-5 14 C-5 4 5 4 5 14 L4 178 L-4 178Z" fill="#000" opacity=".35" transform="translate(5 6)" filter="url(#' + P + 'blur3)"/>';
    o += '<path d="M-3 6 C-12 6 -12 22 -3 22" stroke="url(#' + P + 'steel)" stroke-width="3.5" fill="none"/>';
    o += '<path d="M-5 12 C-5 4 5 4 5 12 L4 182 L-4 182Z" fill="url(#' + P + 'steel)"/>';
    o += '<ellipse cx="5" cy="226" rx="46" ry="44" fill="#000" opacity=".4" filter="url(#' + P + 'blur8)"/><ellipse cx="0" cy="218" rx="44" ry="42" fill="url(#' + P + 'steelD)"/>' +
      '<ellipse cx="0" cy="218" rx="44" ry="42" fill="none" stroke="#4b5058" stroke-width="1.5"/><path d="M-30 196 A36 36 0 0 1 4 182" stroke="#fff" stroke-width="5" fill="none" opacity=".75" stroke-linecap="round"/>' +
      '<ellipse cx="14" cy="236" rx="14" ry="9" fill="#ffffff" opacity=".22"/>';
    return o; }

  /* a brown egg (local, centre 0,0, upright) */
  function egg(P, x, y, s, rot, rnd) { var o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot) + ') scale(' + f1(s) + ')">';
    o += '<path d="M0 -30 C16 -30 24 -6 23 8 C22 24 12 31 0 31 C-12 31 -22 24 -23 8 C-24 -6 -16 -30 0 -30Z" fill="url(#' + P + 'egg)"/>';
    for (var i = 0; i < 14; i++) o += '<circle cx="' + f1((rnd() - .5) * 34) + '" cy="' + f1((rnd() - .5) * 46) + '" r="' + f1(.5 + rnd() * .9) + '" fill="#6e3a1c" opacity=".45"/>';
    o += '<ellipse cx="-8" cy="-12" rx="5" ry="9" fill="#fff" opacity=".35" transform="rotate(-18 -8 -12)"/></g>'; return o; }
  /* a hanging wire basket of brown eggs */
  function basket(P) { var o = defs(P).replace('</defs>', '<radialGradient id="' + P + 'egg" cx=".36" cy=".3" r=".8"><stop offset="0" stop-color="#f4d2ad"/><stop offset=".45" stop-color="#d49a68"/><stop offset=".85" stop-color="#a5643a"/><stop offset="1" stop-color="#6e3a1c"/></radialGradient></defs>') + hook(P), rnd = seeded(14), cy = 150, R = 66;
    /* handle up to the hook */
    o += '<path d="M-62 ' + (cy - 20) + ' C-60 40 -20 10 0 10 C20 10 60 40 62 ' + (cy - 20) + '" stroke="#2c2f34" stroke-width="3.6" fill="none"/><path d="M-61 ' + (cy - 20) + ' C-59 42 -20 11 0 11 C20 11 59 42 61 ' + (cy - 20) + '" stroke="#c9cdd2" stroke-width="1.2" fill="none" opacity=".7"/>';
    o += '<ellipse cx="6" cy="' + (cy + 60) + '" rx="66" ry="16" fill="#000" opacity=".35" filter="url(#' + P + 'blur8)"/>';
    /* back of the basket's rim, then the eggs, then the front wires */
    o += '<ellipse cx="0" cy="' + (cy - 20) + '" rx="' + R + '" ry="14" fill="none" stroke="#2c2f34" stroke-width="3"/>';
    o += egg(P, -30, cy - 26, 1, -12, rnd) + egg(P, 12, cy - 30, 1.02, 8, rnd) + egg(P, 40, cy - 18, .95, 18, rnd) + egg(P, -10, cy - 6, 1.05, -4, rnd) + egg(P, 28, cy + 2, 1, 6, rnd) + egg(P, -40, cy + 4, .95, -16, rnd);
    var wires = ''; for (var i = 0; i <= 10; i++) { var t = i / 10, x = Math.cos(Math.PI - t * Math.PI) * R; wires += 'M' + f1(x) + ' ' + (cy - 20) + ' C' + f1(x * 1.02) + ' ' + f1(cy + 20) + ' ' + f1(x * .55) + ' ' + f1(cy + 58) + ' 0 ' + (cy + 62); }
    o += '<path d="' + wires + '" stroke="#24272c" stroke-width="3" fill="none"/><path d="' + wires + '" stroke="#d6dade" stroke-width="1" fill="none" opacity=".75" transform="translate(-.8 -.5)"/>';
    [[0, R, 14], [26, R * .92, 12], [50, R * .62, 9]].forEach(function (r) { var d = 'M' + f1(-r[1]) + ' ' + (cy - 20 + r[0]) + ' A' + f1(r[1]) + ' ' + r[2] + ' 0 0 0 ' + f1(r[1]) + ' ' + (cy - 20 + r[0]);
      o += '<path d="' + d + '" stroke="#24272c" stroke-width="3.4" fill="none"/><path d="' + d + '" stroke="#e1e4e8" stroke-width="1.1" fill="none" opacity=".8" transform="translate(0 -1)"/>'; });
    return o; }
  /* lemons in a string bag */
  function lemon(P, x, y, s, rot) { return '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(rot) + ') scale(' + f1(s) + ')"><path d="M-32 0 C-32 -23 32 -23 32 0 L36 -.5 C38 .5 38 2 36 2.5 L32 2 C32 25 -32 25 -32 2 L-36 2.5 C-38 2 -38 .5 -36 -.5Z" fill="url(#' + P + 'lemR)"/>' +
      '<path d="M-28 10 C-14 22 14 22 28 10 C20 24 -20 24 -28 10Z" fill="#8a6a00" opacity=".35"/><ellipse cx="-10" cy="-10" rx="16" ry="6" fill="#fff" opacity=".4"/></g>'; }
  function lemonBag(P) { var o = defs(P) + hook(P), id = P + 'nb';
    var bag = 'M-4 10 C-40 50 -68 90 -66 150 C-64 210 -30 236 0 236 C30 236 64 210 66 150 C68 90 40 50 4 10Z';
    o += '<path d="' + bag + '" fill="#000" opacity=".35" transform="translate(6 8)" filter="url(#' + P + 'blur8)"/>';
    o += lemon(P, 4, 78, .82, -24) + lemon(P, -24, 122, .9, 12) + lemon(P, 26, 128, .9, -10) + lemon(P, -20, 182, .95, -6) + lemon(P, 24, 190, .92, 14);
    /* knotted netting: diamond mesh following the bag's bulge */
    var m = ''; for (var i = -4; i <= 4; i++) { var pts = [], pts2 = []; for (var j = 0; j <= 16; j++) { var t = j / 16, y = 10 + t * 222, half = 66 * Math.sin(Math.min(1, t) * Math.PI) * (t < .5 ? 1 : 1) + 4;
        var w = Math.max(4, half); pts.push([clampN((i / 4 + t * 1.1 - .55) * w, w), y]); pts2.push([clampN((i / 4 - t * 1.1 + .55) * w, w), y]); }
      m += open(pts) + open(pts2); }
    o += '<clipPath id="' + id + '"><path d="' + bag + '"/></clipPath><g clip-path="url(#' + id + ')"><path d="' + m + '" stroke="#c9620f" stroke-width="2" fill="none"/><path d="' + m + '" stroke="#ffd28a" stroke-width=".7" fill="none" opacity=".8" transform="translate(-.6 -.6)"/></g>';
    o += '<path d="M-4 10 L0 228 M4 10 L0 228" stroke="#c4650f" stroke-width="1.6" opacity=".5"/><path d="M-8 4 C-8 14 8 14 8 4" stroke="#c4650f" stroke-width="4" fill="none"/><path d="M-6 232 L-10 248 M0 232 L0 252 M6 232 L10 248" stroke="#d9771a" stroke-width="2.2" stroke-linecap="round"/>';
    return o; }
  function clampN(v, w) { return Math.max(-w, Math.min(w, v)); }

  /* ---------- moving pieces ---------- */
  /* a single pancake seen from above at an angle; face 'top' (browned) or 'under' (lacy). Anchor centre */
  function flatcake(P, under, seed) { var rnd = seeded(seed || 5), o = defs(P), f = faceTop(P, 0, 0, 92, 92, rnd, under);
    o += f.svg; return o; }
  /* the edge of a flipping pancake, a thin band (scaled with the flip) */
  function cakeEdge(P) { return defs(P) + '<rect x="-92" y="-8" width="184" height="16" rx="8" fill="url(#' + P + 'side)"/><rect x="-92" y="-8" width="184" height="16" rx="8" fill="url(#' + P + 'round)"/>'; }
  /* a cast-iron frying pan, held from off the screen edge (handle points left, to x<0); seen from above at an angle. Anchor = pan centre */
  function skillet(P) { var o = defs(P), rx = 120, ry = 54;
    /* a long cast handle that tapers out to the screen edge, a hanging hole near its end */
    o += '<path d="M-112 -10 C-200 -16 -380 -22 -470 -24 C-486 -24 -490 12 -472 12 C-380 10 -200 8 -112 16Z" fill="url(#' + P + 'iron)"/>';
    o += '<path d="M-120 -8 C-220 -14 -380 -19 -468 -21" stroke="#9a9ea6" stroke-width="2.4" fill="none" opacity=".55"/><path d="M-120 14 C-220 9 -380 8 -468 9" stroke="#000" stroke-width="3" fill="none" opacity=".5"/>';
    o += '<ellipse cx="-445" cy="-6" rx="11" ry="6" fill="#050506"/><ellipse cx="-445" cy="-4" rx="9" ry="3.5" fill="#6e7178" opacity=".5"/>';
    o += '<ellipse cx="0" cy="20" rx="' + rx + '" ry="' + (ry + 4) + '" fill="#050506"/><ellipse cx="0" cy="12" rx="' + rx + '" ry="' + (ry + 2) + '" fill="url(#' + P + 'iron)"/>';
    o += '<ellipse cx="0" cy="6" rx="' + (rx - 9) + '" ry="' + (ry - 5) + '" fill="url(#' + P + 'ironIn)"/>';
    o += '<ellipse cx="0" cy="6" rx="' + (rx - 9) + '" ry="' + (ry - 5) + '" fill="none" stroke="#000" stroke-width="5" opacity=".55" filter="url(#' + P + 'blur3)"/>';
    o += '<path d="M-100 -22 A104 44 0 0 1 30 -50" stroke="#e6e9ee" stroke-width="3" fill="none" opacity=".6" stroke-linecap="round"/><path d="M60 52 A110 48 0 0 1 -60 56" stroke="#8d9198" stroke-width="2" fill="none" opacity=".5"/>';
    o += '<ellipse cx="-30" cy="-6" rx="46" ry="14" fill="#9aa0aa" opacity=".16" filter="url(#' + P + 'blur8)"/>';
    o += '<path d="M' + (rx - 6) + ' 2 C' + (rx + 16) + ' -2 ' + (rx + 20) + ' 16 ' + (rx - 2) + ' 18" fill="url(#' + P + 'iron)"/>';
    return o; }
  /* a white china jug with the plate's blue band, tipping to pour (rotated by the frame). Anchor = spout tip at 0,0; upright, body below-left */
  function jug(P) { var o = defs(P), id = P + 'jg';
    var body = 'M-104 -6 C-112 30 -110 80 -96 112 C-90 124 -30 124 -24 112 C-10 80 -8 30 -16 -6 C-10 -8 -2 -6 0 0 C-8 4 -14 6 -18 8 C-40 0 -84 -2 -104 -6Z';
    o += '<path d="' + body + '" fill="#000" opacity=".4" transform="translate(7 10)" filter="url(#' + P + 'blur8)"/>';
    o += '<path d="M-100 16 C-140 10 -146 70 -102 82" stroke="#cfccc6" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M-100 16 C-136 12 -140 66 -102 78" stroke="#fff" stroke-width="3.5" fill="none" opacity=".8" stroke-linecap="round"/>';
    o += '<clipPath id="' + id + '"><path d="' + body + '"/></clipPath><path d="' + body + '" fill="url(#' + P + 'plate)"/><g clip-path="url(#' + id + ')">' +
      '<rect x="-120" y="-20" width="34" height="150" fill="#8e8a84" opacity=".3" filter="url(#' + P + 'blur8)"/><rect x="-46" y="-20" width="40" height="150" fill="#6f6b66" opacity=".35" filter="url(#' + P + 'blur8)"/>' +
      '<path d="M-120 92 C-80 100 -40 100 0 92" stroke="#2f5fb0" stroke-width="3" fill="none" opacity=".8"/><path d="M-120 99 C-80 107 -40 107 0 99" stroke="#2f5fb0" stroke-width="1.2" fill="none" opacity=".6"/>' +
      '<path d="M-86 6 L-84 104" stroke="#fff" stroke-width="7" opacity=".9" stroke-linecap="round" filter="url(#' + P + 'blur1)"/></g>';
    o += '<path d="M-104 -6 C-84 -2 -40 0 -18 8 C-14 6 -8 4 0 0" stroke="#a9a6a1" stroke-width="2" fill="none"/>';
    /* syrup on the lip of the spout */
    o += '<path d="M-14 0 C-8 -2 -3 -2 0 0 C-2 4 -8 6 -14 4Z" fill="url(#' + P + 'syrV)"/>';
    return o; }
  /* a falling stream of syrup (unit long, 0..1 down) */
  function stream(P, L) { return defs(P) + '<path d="M-7 0 C-6 ' + L * .3 + ' -4 ' + L * .7 + ' -4 ' + L + ' L4 ' + L + ' C4 ' + L * .7 + ' 6 ' + L * .3 + ' 7 0Z" fill="url(#' + P + 'syrV)"/><path d="M-2 4 L-1.5 ' + (L - 4) + '" stroke="#fff3c8" stroke-width="1.6" opacity=".75"/>'; }
  /* a stainless sugar dredger with a domed, pierced lid and a little handle (rotated by the frame). Anchor = the top of the lid at 0,0; body below */
  function shaker(P) { var o = defs(P), id = P + 'sk';
    o += '<rect x="-32" y="26" width="64" height="104" rx="6" fill="#000" opacity=".4" transform="translate(7 10)" filter="url(#' + P + 'blur8)"/>';
    o += '<path d="M30 46 C58 46 58 104 30 104" stroke="url(#' + P + 'steel)" stroke-width="7" fill="none"/>';
    o += '<rect x="-32" y="26" width="64" height="104" rx="5" fill="url(#' + P + 'steel)"/><rect x="-32" y="26" width="64" height="104" rx="5" filter="url(#' + P + 'brush)" opacity=".35"/>';
    o += '<rect x="-34" y="122" width="68" height="9" rx="4" fill="url(#' + P + 'steel)"/><rect x="-34" y="24" width="68" height="9" rx="4" fill="url(#' + P + 'steel)"/>';
    o += '<path d="M-33 26 C-33 -8 33 -8 33 26Z" fill="url(#' + P + 'steelD)"/><path d="M-24 14 C-20 -2 4 -6 14 -2" stroke="#fff" stroke-width="3" fill="none" opacity=".75" stroke-linecap="round"/>';
    for (var i = 0; i < 18; i++) { var a = -2.6 + (i % 6) * .42, r = 10 + Math.floor(i / 6) * 8; o += '<circle cx="' + f1(Math.cos(a) * r) + '" cy="' + f1(22 + Math.sin(a) * r * .75) + '" r="1.5" fill="#24272c"/>'; }
    o += '<path d="M-18 34 L-18 120" stroke="#fff" stroke-width="5" opacity=".55" stroke-linecap="round"/>';
    return o; }
  /* one soft wisp of steam */
  function steam(P) { return defs(P) + '<path d="M0 60 C-14 40 12 22 -2 0 C-12 -16 8 -30 0 -50" stroke="#fff" stroke-width="16" fill="none" opacity=".5" stroke-linecap="round" filter="url(#' + P + 'blur8)"/>'; }
  function drop(P) { return defs(P) + '<path d="M0 -12 C5 -2 9 4 9 10 C9 17 -9 17 -9 10 C-9 4 -5 -2 0 -12Z" fill="url(#' + P + 'syrV)"/><ellipse cx="-3" cy="8" rx="2.4" ry="3.6" fill="#fff6d6" opacity=".8"/>'; }
  function berry(P) { return defs(P) + blueberry(P, 0, 0, 10, seeded(3)); }

  var PIECES = {
    stackL: [[-230, -150, 460, 230], stackCorner], crepesR: [[-230, -110, 460, 190], crepeCorner],
    rail: [[-30, 0, 400, 60], function (P) { return rail(P, 340); }], towel: [[-70, -20, 150, 240], towel],
    pan: [[-90, -14, 180, 304], copperPan], whisk: [[-60, -14, 120, 300], whisk], slice: [[-50, -14, 106, 300], slice], ladle: [[-60, -14, 120, 290], ladle], basket: [[-80, -14, 160, 250], basket], lemons: [[-75, -14, 150, 275], lemonBag],
    cakeTop: [[-100, -100, 200, 200], function (P) { return flatcake(P, false, 5); }], cakeUnder: [[-100, -100, 200, 200], function (P) { return flatcake(P, true, 6); }], cakeEdge: [[-100, -12, 200, 24], cakeEdge],
    skillet: [[-490, -80, 640, 160], skillet], jug: [[-160, -24, 182, 162], jug], stream: [[-12, 0, 24, 300], function (P) { return stream(P, 300); }], shaker: [[-46, -16, 112, 160], shaker],
    steam: [[-40, -70, 80, 150], steam], drop: [[-12, -16, 24, 36], drop], berry: [[-16, -14, 32, 32], berry]
  };
  window.PancakeArt = {
    BOX: {}, piece: function (name, w, h) { var p = PIECES[name], P = name + (uid++) + '_'; return svgWrap(p[0], p[1](P), w, h); },
    STACK: STACK
  };
  Object.keys(PIECES).forEach(function (k) { PancakeArt.BOX[k] = PIECES[k][0]; });
})();

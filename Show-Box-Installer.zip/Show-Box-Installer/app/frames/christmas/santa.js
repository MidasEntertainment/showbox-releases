/* Santa's sleigh team for the Christmas frame: a painted, moonlit illustration (not clip-art).
   SantaArt.svg(phase, mode, w, h) returns a complete SVG of the whole team facing right:
   phase 0..1 = point in the reindeer's flying gallop, mode 'colour' or 'silhouette' (for when the team crosses the moon).
   Art box: SantaArt.VB = [x, y, width, height]. Everything is drawn with gradients, shading, fur and highlights. */
(function () {
  var VB = [-10, -112, 975, 288];
  function f1(n) { return (+n).toFixed(1); }
  function seeded(s) { return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }

  /* a tapered limb or shape around a polyline: pts [[x,y],...], widths per point -> smooth filled path */
  function taper(pts, ws) { var L = [], Rr = [], n = pts.length;
    for (var i = 0; i < n; i++) { var a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy) || 1, nx = -dy / d, ny = dx / d, w = ws[i] / 2;
      L.push([pts[i][0] + nx * w, pts[i][1] + ny * w]); Rr.push([pts[i][0] - nx * w, pts[i][1] - ny * w]); }
    var all = L.concat(Rr.reverse());
    return smoothClosed(all, [0, n - 1, n, 2 * n - 1]); }
  /* Catmull-Rom through points, closed; corners listed stay sharper */
  function smoothClosed(p, sharp) { var n = p.length, s = 'M' + f1(p[0][0]) + ' ' + f1(p[0][1]);
    for (var i = 0; i < n; i++) { var p0 = p[(i - 1 + n) % n], p1 = p[i], p2 = p[(i + 1) % n], p3 = p[(i + 2) % n], t1 = sharp && sharp.indexOf(i) >= 0 ? 0 : 1 / 6, t2 = sharp && sharp.indexOf((i + 1) % n) >= 0 ? 0 : 1 / 6;
      s += 'C' + f1(p1[0] + (p2[0] - p0[0]) * t1) + ' ' + f1(p1[1] + (p2[1] - p0[1]) * t1) + ' ' + f1(p2[0] - (p3[0] - p1[0]) * t2) + ' ' + f1(p2[1] - (p3[1] - p1[1]) * t2) + ' ' + f1(p2[0]) + ' ' + f1(p2[1]); }
    return s + 'Z'; }
  function seg(p, len, deg) { var r = deg * Math.PI / 180; return [p[0] + Math.sin(r) * len, p[1] + Math.cos(r) * len]; }

  function defs() {
    return '<linearGradient id="rdBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a2f1b"/><stop offset=".35" stop-color="#7a5232"/><stop offset=".72" stop-color="#9a7048"/><stop offset="1" stop-color="#d9c29a"/></linearGradient>' +
      '<linearGradient id="rdBodyF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2e1d12"/><stop offset=".4" stop-color="#4c3220"/><stop offset=".75" stop-color="#5f4430"/><stop offset="1" stop-color="#8c7a60"/></linearGradient>' +
      '<linearGradient id="rdLeg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6b4528"/><stop offset=".5" stop-color="#4a2f1c"/><stop offset="1" stop-color="#2a1a10"/></linearGradient>' +
      '<linearGradient id="rdLegF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3e281a"/><stop offset="1" stop-color="#1c120b"/></linearGradient>' +
      '<linearGradient id="rdMane" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4ead6"/><stop offset=".6" stop-color="#d9c8a8"/><stop offset="1" stop-color="#a8916c"/></linearGradient>' +
      '<linearGradient id="rdManeF" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b4a68c"/><stop offset="1" stop-color="#7a6a52"/></linearGradient>' +
      '<linearGradient id="rdHead" x1="0" y1="0" x2="1" y2=".4"><stop offset="0" stop-color="#5a3a22"/><stop offset=".6" stop-color="#7d5636"/><stop offset="1" stop-color="#4a2f1c"/></linearGradient>' +
      '<linearGradient id="rdHeadF" x1="0" y1="0" x2="1" y2=".4"><stop offset="0" stop-color="#36241a"/><stop offset="1" stop-color="#2a1b12"/></linearGradient>' +
      '<linearGradient id="antl" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8a6a48"/><stop offset=".5" stop-color="#c9ad84"/><stop offset="1" stop-color="#efe2c6"/></linearGradient>' +
      '<linearGradient id="antlF" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#5a4632"/><stop offset="1" stop-color="#9c8a6c"/></linearGradient>' +
      '<linearGradient id="strap" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d23a32"/><stop offset=".5" stop-color="#a01c1c"/><stop offset="1" stop-color="#5e0c0e"/></linearGradient>' +
      '<radialGradient id="bell" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#fff6c8"/><stop offset=".3" stop-color="#f2c650"/><stop offset=".75" stop-color="#b07a1a"/><stop offset="1" stop-color="#6a4208"/></radialGradient>' +
      '<linearGradient id="gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset=".35" stop-color="#e8b84a"/><stop offset=".7" stop-color="#b5801e"/><stop offset="1" stop-color="#7a5010"/></linearGradient>' +
      '<linearGradient id="goldH" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#9a6a14"/><stop offset=".3" stop-color="#f0c860"/><stop offset=".5" stop-color="#fff2c0"/><stop offset=".7" stop-color="#e2ae42"/><stop offset="1" stop-color="#8a5e12"/></linearGradient>' +
      '<linearGradient id="lacq" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e2453f"/><stop offset=".18" stop-color="#c0141c"/><stop offset=".6" stop-color="#8a0a12"/><stop offset="1" stop-color="#3e0408"/></linearGradient>' +
      '<linearGradient id="lacqIn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a060a"/><stop offset="1" stop-color="#2a0205"/></linearGradient>' +
      '<linearGradient id="sheen" x1="0" y1="0" x2="0" y2="1"><stop offset=".6" stop-color="#fff" stop-opacity="0"/><stop offset=".7" stop-color="#fff" stop-opacity=".22"/><stop offset=".78" stop-color="#fff" stop-opacity="0"/></linearGradient>' +
      '<linearGradient id="coat" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e03a32"/><stop offset=".45" stop-color="#b8121a"/><stop offset="1" stop-color="#5e060c"/></linearGradient>' +
      '<radialGradient id="coatB" cx=".7" cy=".55" r=".6"><stop offset="0" stop-color="#e8443a"/><stop offset=".6" stop-color="#b3141b"/><stop offset="1" stop-color="#6a070d"/></radialGradient>' +
      '<linearGradient id="fur" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".6" stop-color="#f1ede6"/><stop offset="1" stop-color="#c9c2b8"/></linearGradient>' +
      '<linearGradient id="beard" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".55" stop-color="#eeeae4"/><stop offset="1" stop-color="#b8b2aa"/></linearGradient>' +
      '<radialGradient id="skin" cx=".6" cy=".4" r=".7"><stop offset="0" stop-color="#ffd9bd"/><stop offset=".6" stop-color="#f0b48e"/><stop offset="1" stop-color="#c9805e"/></radialGradient>' +
      '<radialGradient id="nose" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#ffb3a0"/><stop offset=".5" stop-color="#e46a5a"/><stop offset="1" stop-color="#b03a32"/></radialGradient>' +
      '<radialGradient id="blush" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ff7a6a" stop-opacity=".55"/><stop offset="1" stop-color="#ff7a6a" stop-opacity="0"/></radialGradient>' +
      '<linearGradient id="sack" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c49a62"/><stop offset=".5" stop-color="#9a7240"/><stop offset="1" stop-color="#5e4220"/></linearGradient>' +
      '<linearGradient id="boxG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2f8a4a"/><stop offset="1" stop-color="#14502a"/></linearGradient>' +
      '<linearGradient id="boxB" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a6ad0"/><stop offset="1" stop-color="#1a347a"/></linearGradient>' +
      '<linearGradient id="boxW" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbf6ee"/><stop offset="1" stop-color="#cfc6b8"/></linearGradient>' +
      '<linearGradient id="glove" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a4a52"/><stop offset="1" stop-color="#121216"/></linearGradient>' +
      '<linearGradient id="boot" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a3a40"/><stop offset="1" stop-color="#0c0c10"/></linearGradient>';
  }

  /* fur strokes in a region (clipped) */
  function furStrokes(R, n, x0, y0, x1, y1, col, op, len, ang) { var s = '';
    for (var i = 0; i < n; i++) { var x = x0 + R() * (x1 - x0), y = y0 + R() * (y1 - y0), a = (ang + (R() - .5) * 30) * Math.PI / 180, l = len * (.6 + R() * .8);
      s += 'M' + f1(x) + ' ' + f1(y) + 'l' + f1(Math.cos(a) * l) + ' ' + f1(Math.sin(a) * l); }
    return '<path d="' + s + '" stroke="' + col + '" stroke-width=".9" opacity="' + op + '" fill="none" stroke-linecap="round"/>'; }

  function antler(x, y, sc, flip, grad) { /* a branching reindeer antler from its base, sweeping back and up, tapered beams */
    var g = '', P = function (pts, w0) { var ws = pts.map(function (p, i) { return w0 * (1 - i / pts.length * .8); }); g += '<path d="' + taper(pts, ws) + '" fill="url(#' + grad + ')"/>'; };
    function pt(px, py) { return [x + px * sc, y + py * sc]; }
    P([pt(0, 0), pt(-6, -18), pt(-16, -36), pt(-30, -54), pt(-44, -66), pt(-56, -72)], 6.5 * sc);
    P([pt(-6, -18), pt(4, -26), pt(12, -36), pt(16, -46)], 3.6 * sc);
    P([pt(-16, -36), pt(-12, -50), pt(-8, -62), pt(-6, -74)], 3.4 * sc);
    P([pt(-30, -54), pt(-30, -68), pt(-28, -80), pt(-24, -88)], 3 * sc);
    P([pt(-44, -66), pt(-50, -78), pt(-52, -88)], 2.6 * sc);
    P([pt(-2, -6), pt(8, -8), pt(16, -6), pt(22, -2)], 3 * sc); /* brow tine forward */
    return g; }

  function reindeer(id, x, y, ph, far, R) {
    var B = far ? 'F' : '', o = '';
    var s1 = Math.sin(ph * 2 * Math.PI), c1 = Math.cos(ph * 2 * Math.PI), bob = -c1 * 3, rock = s1 * 2.2;
    o += '<g transform="translate(' + f1(x) + ' ' + f1(y + bob) + ') rotate(' + f1(rock) + ')">';
    /* legs behind the body first (the off-side pair), then the body, then the near-side pair */
    function foreLeg(dx, phase, near) { var s = Math.sin(phase * 2 * Math.PI), sh = [48 + dx, 18], up = 28 + 46 * s, lo = up - 60 - 50 * Math.max(0, -Math.sin(phase * 2 * Math.PI + .9)) - 18;
      var kn = seg(sh, 40, up), fe = seg(kn, 38, lo), ho = seg(fe, 11, lo + 25);
      return '<path d="' + taper([sh, [(sh[0] + kn[0]) / 2, (sh[1] + kn[1]) / 2], kn, fe, ho], [24, 15, 9, 7, 7]) + '" fill="url(#rdLeg' + B + ')"/>' +
        '<path d="' + taper([fe, [(fe[0] + ho[0] * 1.2) / 2.2, (fe[1] + ho[1] * 1.2) / 2.2], ho], [9, 10, 9]) + '" fill="' + (near ? '#d8c9ac' : '#8a7a62') + '" opacity=".9"/>' +
        '<path d="' + taper([ho, seg(ho, 9, lo + 40)], [11, 9]) + '" fill="#141010"/>'; }
    function hindLeg(dx, phase, near) { var s = Math.sin(phase * 2 * Math.PI), hip = [-56 + dx, 6], th = -20 - 44 * s, sh = th + 70 + 22 * Math.max(0, Math.sin(phase * 2 * Math.PI + 1.2)), pa = sh - 50;
      var st = seg(hip, 36, th), ho = seg(st, 42, sh), fe = seg(ho, 22, pa), hf = seg(fe, 10, pa - 20);
      return '<path d="' + taper([hip, st, ho, fe, hf], [34, 18, 9, 7, 7]) + '" fill="url(#rdLeg' + B + ')"/>' +
        '<path d="' + taper([fe, hf], [9, 9]) + '" fill="' + (near ? '#d8c9ac' : '#8a7a62') + '" opacity=".9"/>' +
        '<path d="' + taper([hf, seg(hf, 9, pa - 30)], [11, 9]) + '" fill="#141010"/>'; }
    var shade = '<g opacity=".55" filter="none">';
    o += '<g opacity=".82">' + foreLeg(10, ph + .12, false) + hindLeg(8, ph + .1, false) + '</g>';
    /* body */
    var body = 'M-80 -8 C-82 -30 -64 -42 -42 -40 C-18 -38 8 -44 32 -50 C58 -56 80 -40 84 -16 C88 8 78 30 60 38 C42 46 22 40 4 32 C-14 26 -36 32 -54 28 C-72 22 -80 8 -80 -8Z';
    o += '<clipPath id="cb' + id + '"><path d="' + body + '"/></clipPath>';
    o += '<path d="' + body + '" fill="url(#rdBody' + B + ')"/>';
    o += '<g clip-path="url(#cb' + id + ')">' +
      '<ellipse cx="-70" cy="-10" rx="22" ry="20" fill="' + (far ? '#9a8a70' : '#efe4cc') + '" opacity=".85"/>' + /* pale rump */
      '<path d="M-60 30 C-20 22 30 22 70 26 L70 50 L-60 50Z" fill="' + (far ? '#7a6a52' : '#e6d6b6') + '" opacity=".55"/>' + /* pale belly */
      '<ellipse cx="-50" cy="-6" rx="34" ry="26" fill="#000" opacity=".12"/>' + /* haunch shadow */
      '<path d="M-70 -30 C-30 -42 30 -44 70 -28" stroke="' + (far ? '#a08c70' : '#f2dcb4') + '" stroke-width="3" fill="none" opacity=".45"/>' + /* moonlit back */
      furStrokes(R, 70, -80, -38, 80, 34, '#2a180c', .35, 7, 160) + furStrokes(R, 30, -60, -40, 60, -20, '#f0d9b0', .25, 6, 170) + '</g>';
    /* tail tuft */
    o += '<path d="M-80 -22 C-92 -30 -98 -24 -94 -16 C-90 -10 -84 -12 -80 -14Z" fill="' + (far ? '#a49478' : '#fbf5e8') + '"/>';
    /* neck with the pale shaggy ruff underneath */
    var neck = 'M28 -48 C48 -68 72 -86 94 -100 L120 -88 C114 -64 102 -36 86 -10 C78 2 62 2 54 -8 C46 -24 38 -38 28 -48Z';
    o += '<path d="' + neck + '" fill="url(#rdBody' + B + ')"/>';
    var mane = ''; for (var m = 0; m < 22; m++) { var t = m / 21, bx = 118 - t * 34, by = -84 + t * 76, L = 14 + Math.sin(t * Math.PI) * 10 + R() * 5, a = 150 - t * 30 + (R() - .5) * 16, ar = a * Math.PI / 180;
      mane += '<path d="' + taper([[bx, by], [bx + Math.cos(ar) * L * .5 + 2, by + Math.sin(ar) * L * .5 + 3], [bx + Math.cos(ar) * L, by + Math.sin(ar) * L + 5]], [9, 6, 1]) + '"/>'; }
    o += '<g fill="url(#rdMane' + B + ')">' + mane + '</g>';
    /* harness: collar with bells, girth strap, a strap along the back */
    o += '<path d="M58 -40 C70 -30 82 -14 86 0" stroke="url(#strap)" stroke-width="9" fill="none" stroke-linecap="round"/>';
    o += '<path d="M24 -44 C28 -10 30 14 26 40" stroke="url(#strap)" stroke-width="8" fill="none"/><path d="M24 -44 C-10 -46 -40 -44 -66 -36" stroke="url(#strap)" stroke-width="5" fill="none"/>';
    [[66, -32], [75, -20], [82, -7], [27, -20], [29, 0], [28, 20]].forEach(function (b, i) { o += '<circle cx="' + b[0] + '" cy="' + b[1] + '" r="' + (i < 3 ? 5.2 : 4.4) + '" fill="url(#bell)"/><path d="M' + (b[0] - 2) + ' ' + (b[1] + 2) + 'h4" stroke="#4a2c06" stroke-width="1.2"/>'; });
    /* head: long muzzle, dark nose, eye with catchlight, ear */
    var head = 'M90 -104 C96 -118 114 -122 126 -114 C136 -106 146 -96 156 -88 C162 -84 162 -76 155 -74 C144 -71 130 -72 118 -74 C104 -76 92 -86 90 -104Z';
    o += '<path d="' + head + '" fill="url(#rdHead' + B + ')"/>';
    o += '<path d="M128 -84 C138 -82 148 -80 155 -76 C150 -72 138 -72 126 -74Z" fill="' + (far ? '#5a4a3a' : '#c9b08c') + '" opacity=".7"/>';
    o += '<ellipse cx="155" cy="-82" rx="6.5" ry="5" fill="#1a1210"/><ellipse cx="153" cy="-84" rx="2" ry="1.3" fill="#fff" opacity=".35"/>';
    o += '<ellipse cx="116" cy="-104" rx="4.2" ry="3.6" fill="#0c0806"/><circle cx="117.4" cy="-105.3" r="1.3" fill="#fff" opacity=".9"/>';
    o += '<path d="M112 -104 C116 -100 120 -100 122 -103" stroke="#2a1a10" stroke-width="1" fill="none" opacity=".6"/>';
    o += '<path d="M98 -110 C88 -122 76 -126 66 -124 C72 -116 82 -108 94 -104Z" fill="url(#rdHead' + B + ')"/><path d="M94 -110 C86 -118 78 -121 72 -121 C78 -115 86 -110 92 -107Z" fill="' + (far ? '#5a4632' : '#c8a27a') + '" opacity=".6"/>';
    /* bridle */
    o += '<path d="M104 -114 C108 -100 112 -86 120 -76 M126 -88 C136 -90 146 -88 152 -86" stroke="#2a1810" stroke-width="2.2" fill="none" opacity=".85"/><circle cx="121" cy="-77" r="2.4" fill="url(#bell)"/>';
    /* antlers: far one first (behind), near one in front */
    o += '<g opacity=".8">' + antler(106, -116, .95, false, far ? 'antlF' : 'antl') + '</g>' + antler(100, -114, 1.05, false, far ? 'antlF' : 'antl');
    /* near-side legs in front */
    o += foreLeg(0, ph, true) + hindLeg(0, ph, true);
    return o + '</g>'; }

  function sleighAndSanta(R) { var o = '';
    /* runners: gold, with struts and a big curl at the front */
    o += '<path d="M18 156 C10 156 6 150 10 144" stroke="url(#gold)" stroke-width="7" fill="none" stroke-linecap="round"/>';
    o += '<path d="M14 158 L300 158 C336 158 356 140 356 114 C356 92 340 82 326 90 C314 98 320 116 334 112" stroke="url(#gold)" stroke-width="8" fill="none" stroke-linecap="round"/>';
    o += '<path d="M14 156 L300 156" stroke="#fff6c8" stroke-width="1.5" opacity=".6"/>';
    [70, 160, 250].forEach(function (x) { o += '<path d="M' + x + ' 128 C' + (x - 6) + ' 140 ' + (x - 4) + ' 150 ' + x + ' 158" stroke="url(#goldH)" stroke-width="6" fill="none"/>'; });
    /* sack of presents behind Santa */
    o += '<path d="M70 94 C56 74 58 44 76 28 C90 16 104 14 114 18 C138 12 160 22 166 46 C170 66 164 86 152 96Z" fill="url(#sack)"/>' +
      furStrokes(R, 60, 76, 14, 184, 90, '#4a3216', .35, 6, 60) + furStrokes(R, 40, 76, 14, 184, 90, '#e8c88e', .22, 5, 120) +
      '<path d="M96 30 C110 40 140 44 170 36" stroke="#4a3216" stroke-width="1.6" fill="none" opacity=".5"/>' +
      '<path d="M100 18 C96 6 98 -6 106 -12 C110 -4 112 6 110 16Z" fill="url(#sack)"/><path d="M98 16 C104 12 112 12 118 16" stroke="#c9302a" stroke-width="4" fill="none"/>';
    o += '<g transform="translate(-14 14) rotate(-14 136 -2)"><rect x="118" y="-22" width="36" height="30" rx="2" fill="url(#boxG)"/><rect x="132" y="-22" width="7" height="30" fill="url(#goldH)"/><rect x="118" y="-10" width="36" height="6" fill="url(#goldH)"/>' +
      '<path d="M135 -22 C126 -34 118 -32 122 -24 C126 -20 132 -21 135 -22 C140 -34 150 -34 148 -26 C146 -21 140 -21 135 -22Z" fill="url(#gold)"/></g>';
    o += '<g transform="translate(-34 22) rotate(12 172 14)"><rect x="156" y="-4" width="30" height="26" rx="2" fill="url(#boxW)"/>' + (function () { var s = ''; for (var i = 0; i < 5; i++) s += '<path d="M' + (156 + i * 7) + ' -4 l-8 26" stroke="#c4161c" stroke-width="3.2" opacity=".9"/>'; return '<clipPath id="bxs"><rect x="156" y="-4" width="30" height="26" rx="2"/></clipPath><g clip-path="url(#bxs)">' + s + '</g>'; })() +
      '<rect x="168" y="-4" width="6" height="26" fill="#1f5c32"/></g>';
    o += '<g transform="rotate(-4 92 30)"><rect x="70" y="16" width="34" height="26" rx="2" fill="url(#boxB)"/><rect x="84" y="16" width="6" height="26" fill="#f4f0e8"/><rect x="70" y="26" width="34" height="5" fill="#f4f0e8"/></g>';
    /* Santa: hat, face, beard, coat, arm with the reins */
    o += santa(R);
    /* sleigh body: deep red lacquer, gold scroll trim, a high curled back and a swan-neck front */
    var bodyP = 'M40 128 C22 108 16 72 26 36 C32 14 46 2 62 4 C76 6 80 20 70 26 C62 30 54 24 58 18 C46 40 46 74 62 96 C100 102 210 102 260 92 C276 88 290 72 298 50 C304 32 318 20 334 24 C348 28 350 46 336 50 C326 52 320 44 326 38 C314 54 308 84 294 108 C280 128 256 134 226 134 L86 134 C64 134 48 134 40 128Z';
    o += '<path d="' + bodyP + '" fill="url(#lacq)"/>';
    o += '<clipPath id="sbody"><path d="' + bodyP + '"/></clipPath><g clip-path="url(#sbody)"><rect x="0" y="0" width="360" height="140" fill="url(#sheen)"/>' +
      '<path d="M40 112 C120 118 220 118 300 104" stroke="#000" stroke-width="22" opacity=".18" fill="none"/></g>';
    o += '<path d="' + bodyP + '" fill="none" stroke="url(#goldH)" stroke-width="3.2"/>';
    /* gold scrollwork panel on the side */
    o += '<g fill="none" stroke="url(#gold)" stroke-linecap="round">' +
      '<path d="M66 98 C110 104 210 104 262 94" stroke-width="3"/>' +
      '<path d="M78 118 C120 124 210 124 262 112" stroke-width="1.6" opacity=".8"/>' +
      '<path d="M166 110 C150 102 132 104 124 112 C132 116 142 114 146 108 M170 110 C186 102 204 104 212 112 C204 116 194 114 190 108" stroke-width="2.2"/>' +
      '<path d="M168 104 C164 108 164 114 168 118 C172 114 172 108 168 104Z" stroke-width="1.6"/></g><circle cx="168" cy="111" r="3.2" fill="url(#bell)"/>';
    o += '<circle cx="66" cy="16" r="5" fill="url(#bell)"/><circle cx="332" cy="38" r="5" fill="url(#bell)"/>';
    return o; }

  function santa(R) { var o = '';
    /* coat body: seated, big round belly forward */
    var coat = 'M150 98 C142 64 150 30 174 12 C192 0 216 0 230 12 C244 26 252 50 250 74 C248 88 242 98 234 102Z';
    o += '<path d="' + coat + '" fill="url(#coatB)"/>';
    o += '<clipPath id="ccoat"><path d="' + coat + '"/></clipPath><g clip-path="url(#ccoat)">' +
      '<path d="M156 30 C170 50 172 80 166 104" stroke="#4a0408" stroke-width="10" opacity=".25" fill="none"/>' +
      '<path d="M200 6 C222 10 240 30 246 56" stroke="#ff8a72" stroke-width="5" opacity=".28" fill="none"/>' +
      '<rect x="140" y="62" width="120" height="13" fill="#141416"/><rect x="226" y="60" width="16" height="17" rx="2" fill="none" stroke="url(#gold)" stroke-width="3.2"/>' +
      '<path d="M236 74 C240 84 240 96 236 104 L254 104 L254 74Z" fill="url(#fur)"/></g>';
    /* the far arm, just a sleeve behind */
    o += '<path d="' + taper([[206, 22], [232, 36], [262, 46]], [22, 19, 16]) + '" fill="#7a0a10"/>';
    /* head in profile: brow, open eye under a bushy white brow, a real nose, rosy cheek; beard and moustache flowing back in the wind */
    o += '<path d="M208 -30 C214 -40 230 -42 240 -36 C246 -32 248 -26 250 -22 C256 -18 260 -12 258 -8 C256 -4 252 -4 250 -6 C250 0 246 6 238 8 C226 10 212 6 206 -6 C202 -14 203 -24 208 -30Z" fill="url(#skin)"/>';
    o += '<ellipse cx="238" cy="-8" rx="9" ry="6" fill="url(#blush)"/>';
    o += '<path d="M246 -22 C252 -18 258 -12 258 -8 C256 -4 252 -4 249 -7" fill="#e88f74" opacity=".55"/><path d="M247 -10 C249 -8 252 -7 254 -8" stroke="#a0503a" stroke-width="1" fill="none" opacity=".7"/>';
    o += '<path d="M234 -20 C236 -22 240 -22 241 -19 C240 -17 236 -17 234 -20Z" fill="#2a1a14"/><circle cx="239" cy="-20" r=".9" fill="#fff"/>';
    o += '<path d="M231 -24 C236 -30 244 -30 248 -25 C244 -24 240 -25 236 -23 C234 -22 232 -22 231 -24Z" fill="url(#fur)"/>';
    o += '<path d="M226 -14 C230 -12 233 -10 234 -6" stroke="#c98a6a" stroke-width="1" fill="none" opacity=".6"/>';
    o += '<ellipse cx="212" cy="-14" rx="5.5" ry="7.5" fill="#eaa888"/><path d="M210 -18 C213 -16 214 -12 212 -9" stroke="#b87458" stroke-width="1.1" fill="none"/>';
    var beard = 'M208 -8 C214 4 230 10 244 8 C252 6 256 2 257 -2 C263 12 260 32 250 46 C244 56 234 64 220 66 C212 60 208 54 204 46 C200 40 194 36 190 30 C196 28 198 24 198 18 C198 8 202 -2 208 -8Z';
    o += '<path d="' + beard + '" fill="url(#beard)"/>';
    var bs = ''; for (var i = 0; i < 18; i++) { var t = i / 17, sx = 252 - t * 48, sy = 4 + t * 4; bs += 'M' + f1(sx) + ' ' + f1(sy) + ' C' + f1(sx - 2) + ' ' + f1(sy + 18) + ' ' + f1(sx - 6 - t * 4) + ' ' + f1(sy + 34) + ' ' + f1(sx - 12 - t * 8) + ' ' + f1(sy + 48 - t * 14 + R() * 6); }
    o += '<path d="' + bs + '" stroke="#9e978e" stroke-width="1" fill="none" opacity=".5"/>';
    o += '<path d="M236 -6 C242 -10 252 -8 256 -3 C260 2 258 8 252 8 C248 4 242 2 236 2 C230 0 230 -4 236 -6Z" fill="url(#fur)"/><path d="M238 -4 C228 -2 220 4 214 12 C224 10 232 4 238 0Z" fill="#f1ede6"/>';
    /* hat: one soft red cone from a fur brim, flopping back with the bobble streaming behind */
    o += '<path d="M204 -28 C204 -46 220 -56 236 -52 C246 -50 252 -44 254 -34 L244 -38 C232 -46 214 -44 204 -28Z" fill="url(#coat)"/>';
    o += '<path d="M206 -36 C196 -56 176 -62 156 -58 C142 -55 132 -48 124 -40 C122 -36 126 -32 130 -34 C144 -42 160 -44 174 -40 C188 -36 198 -28 204 -24Z" fill="url(#coat)"/>';
    o += '<path d="M150 -52 C162 -54 178 -52 190 -44" stroke="#ff8a72" stroke-width="3" fill="none" opacity=".3"/>';
    o += '<path d="M200 -24 C212 -40 238 -44 256 -32 C258 -28 256 -22 252 -24 C236 -34 216 -32 204 -18 C200 -16 196 -20 200 -24Z" fill="url(#fur)"/>' + furStrokes(R, 30, 200, -40, 256, -20, '#c9c2b8', .6, 3, 90);
    o += '<circle cx="124" cy="-38" r="11" fill="url(#fur)"/>' + furStrokes(R, 18, 114, -48, 134, -28, '#bdb6ac', .6, 3, 45);
    /* near arm: red sleeve, white fur cuff, black glove gripping the reins */
    o += '<path d="' + taper([[196, 20], [222, 34], [252, 44]], [26, 22, 19]) + '" fill="url(#coat)"/>';
    o += '<path d="' + taper([[200, 18], [224, 30], [248, 38]], [6, 5, 4]) + '" fill="#ff8a72" opacity=".22"/>';
    o += '<path d="' + taper([[250, 38], [256, 45], [260, 52]], [22, 24, 20]) + '" fill="url(#fur)"/>';
    o += '<path d="M260 36 C270 32 282 36 284 44 C286 52 278 58 268 56 C260 54 256 46 260 36Z" fill="url(#glove)"/><path d="M266 38 C272 37 278 40 279 44" stroke="#8a8a94" stroke-width="1.2" fill="none" opacity=".6"/>';
    /* boots propped on the dash */
    o += '<path d="M262 80 C276 76 292 78 298 86 C300 92 292 96 282 94 C272 94 264 92 262 86Z" fill="url(#boot)"/>';
    return o; }

  function svg(ph, mode, w, h) {
    var R = seeded(41), sil = mode === 'silhouette', o = '';
    var pairs = 3, gap = 178, x0 = 440, ry = 78;
    /* reins from the glove to every reindeer's harness */
    var rein = ''; for (var i = 0; i < pairs; i++) { var rx = x0 + i * gap; rein += 'M280 46 C' + (280 + (rx - 280) * .4) + ' ' + (62 + i * 3) + ' ' + (280 + (rx - 280) * .8) + ' ' + (ry - 10) + ' ' + (rx + 52) + ' ' + (ry - 22); }
    var farT = '', nearT = '';
    for (i = pairs - 1; i >= 0; i--) { var p = ph + i * .13; farT += '<g transform="translate(' + (x0 + i * gap + 34) + ' ' + (ry - 20) + ') scale(.72)">' + reindeer('f' + i, 0, 0, (p + .37) % 1, true, R) + '</g>'; }
    for (i = pairs - 1; i >= 0; i--) { p = ph + i * .13; nearT += '<g transform="translate(' + (x0 + i * gap) + ' ' + ry + ') scale(.78)">' + reindeer('n' + i, 0, 0, p % 1, false, R) + '</g>'; }
    /* traces from the sleigh to the team */
    var traces = '<path d="M336 44 C380 52 410 60 ' + (x0 - 40) + ' ' + (ry - 4) + ' L' + (x0 + 2 * gap + 20) + ' ' + (ry - 6) + '" stroke="#5e0c0e" stroke-width="3.2" fill="none"/>';
    o += farT + '<path d="' + rein + '" stroke="#2a1410" stroke-width="2.2" fill="none"/>' + traces + sleighAndSanta(R) + nearT;
    var filt = sil ? '<filter id="sil" x="-5%" y="-5%" width="110%" height="110%"><feFlood flood-color="#0b0f1c"/><feComposite in2="SourceAlpha" operator="in" result="s"/>' +
      '<feMorphology in="SourceAlpha" operator="dilate" radius="1.4" result="d"/><feGaussianBlur in="d" stdDeviation="2.2" result="b"/><feFlood flood-color="#fff1c8" flood-opacity=".7"/><feComposite in2="b" operator="in" result="g"/>' +
      '<feMerge><feMergeNode in="g"/><feMergeNode in="s"/></feMerge></filter>' :
      '<filter id="rimc" x="-5%" y="-5%" width="110%" height="110%"><feMorphology in="SourceAlpha" operator="dilate" radius="1.2" result="d"/><feGaussianBlur in="d" stdDeviation="2.5" result="b"/><feFlood flood-color="#ffe6b0" flood-opacity=".55"/><feComposite in2="b" operator="in" result="g"/>' +
      '<feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge></filter>';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="' + VB.join(' ') + '"><defs>' + defs() + filt + '</defs><g filter="url(#' + (sil ? 'sil' : 'rimc') + ')">' + o + '</g></svg>'; }

  window.SantaArt = { svg: svg, VB: VB };
})();

/* A red squirrel for the Burns Night frame, painted fur by fur (not clip-art).
   SquirrelArt.svg(pose, w, h), poses: sit (side on, nut at its mouth), nib (nibbling), look (head turned to the audience), blink,
   flick (tail flicked), crouch and leap (the two drawings of a hop). Faces right. VB is the drawing's box. */
(function () {
  var VB = [0, 0, 220, 220];
  function f1(n) { return (+n).toFixed(1); }
  function rng(s) { return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
  var PAL = [[0, [52, 18, 6]], [.25, [110, 40, 14]], [.5, [176, 76, 30]], [.72, [218, 120, 60]], [.88, [240, 168, 104]], [1, [252, 214, 164]]];
  function col(v) { v = Math.max(0, Math.min(1, v)); for (var i = 1; i < PAL.length; i++) if (v <= PAL[i][0]) { var a = PAL[i - 1], b = PAL[i], t = (v - a[0]) / (b[0] - a[0]);
    return 'rgb(' + [0, 1, 2].map(function (j) { return Math.round(a[1][j] + (b[1][j] - a[1][j]) * t); }).join(',') + ')'; } return 'rgb(252,214,164)'; }
  function lock(x, y, a, L, w, bend, c, op) { var r = a * Math.PI / 180, dx = Math.cos(r), dy = Math.sin(r), nx = -dy, ny = dx, P = function (t, s) { var b = Math.sin(t * Math.PI) * bend * L * .2; return [x + dx * L * t + nx * (b + s), y + dy * L * t + ny * (b + s)]; };
    var a0 = P(0, w / 2), a1 = P(.5, w * .32), a2 = P(1, 0), b1 = P(.5, -w * .32), b0 = P(0, -w / 2);
    return '<path d="M' + f1(a0[0]) + ' ' + f1(a0[1]) + 'Q' + f1(a1[0]) + ' ' + f1(a1[1]) + ' ' + f1(a2[0]) + ' ' + f1(a2[1]) + 'Q' + f1(b1[0]) + ' ' + f1(b1[1]) + ' ' + f1(b0[0]) + ' ' + f1(b0[1]) + 'Z" fill="' + c + '"' + (op && op < 1 ? ' opacity="' + op + '"' : '') + '/>'; }
  function strand(x, y, a, L, bend, c, sw, op) { var r = a * Math.PI / 180, dx = Math.cos(r), dy = Math.sin(r), nx = -dy, ny = dx, b = bend * L * .25;
    return '<path d="M' + f1(x) + ' ' + f1(y) + 'Q' + f1(x + dx * L * .5 + nx * b) + ' ' + f1(y + dy * L * .5 + ny * b) + ' ' + f1(x + dx * L) + ' ' + f1(y + dy * L) + '" stroke="' + c + '" stroke-width="' + f1(sw) + '" fill="none" stroke-linecap="round" opacity="' + op + '"/>'; }
  /* fur over a shape: short locks laid along a direction field inside an ellipse (cx,cy,rx,ry,rot), shaded by height */
  function fur(R, cx, cy, rx, ry, rot, n, dir, L, base, cream) { var o = '', c = Math.cos(rot * Math.PI / 180), s = Math.sin(rot * Math.PI / 180);
    for (var i = 0; i < n; i++) { var a = R() * Math.PI * 2, rr = Math.sqrt(R()) * .96, u = Math.cos(a) * rr, v = Math.sin(a) * rr, x = cx + (u * rx * c - v * ry * s), y = cy + (u * rx * s + v * ry * c);
      var lit = base + .22 * (-v) + (R() - .5) * .16, cr = cream && cream(x, y);
      o += lock(x, y, dir(x, y) + (R() - .5) * 26, L * (.7 + R() * .6), 1.6 + R() * 1.6, (R() - .5) * 2, cr ? cr : col(lit)); }
    return o; }
  function tail(R, sp, len, flick) { var o = '', i, j;
    /* spine of the tail as a smooth curve through points; locks fan out either side, longest in the middle, pale at the tips */
    var pts = []; for (i = 0; i <= 40; i++) { var t = i / 40, k = t * (sp.length - 1), a = Math.floor(k), b = Math.min(sp.length - 1, a + 1), f = k - a; pts.push([sp[a][0] + (sp[b][0] - sp[a][0]) * f, sp[a][1] + (sp[b][1] - sp[a][1]) * f]); }
    for (j = 0; j < 3; j++) for (i = 0; i < pts.length; i++) { var p = pts[i], q = pts[Math.min(pts.length - 1, i + 1)], p0 = pts[Math.max(0, i - 1)], ang = Math.atan2(q[1] - p0[1], q[0] - p0[0]) * 180 / Math.PI, tt = i / (pts.length - 1), w = len * (.55 + Math.sin(tt * Math.PI) * .6 + tt * .2);
      for (var side = -1; side <= 1; side += 2) for (var m = 0; m < 3; m++) { var aa = ang + side * (60 + R() * 40) + 20 * (tt - .5) * side, LL = w * (.6 + R() * .5);
        o += lock(p[0] + (R() - .5) * 3, p[1] + (R() - .5) * 3, aa + (flick ? side * 6 : 0), LL, 2.4 + R() * 2.4, (R() - .5) * 2.2, col((j === 0 ? .3 : j === 1 ? .52 : .7) + (R() - .5) * .14 + (side < 0 ? .06 : -.04)), j === 2 ? .85 : 1); } }
    for (i = 0; i < 90; i++) { var p1 = pts[Math.floor(R() * pts.length)]; o += strand(p1[0], p1[1], R() * 360, len * (.7 + R() * .6), (R() - .5) * 2, col(.86 + R() * .14), .5 + R() * .4, .55); }
    return o; }

  function eye(x, y, r, closed) { return closed ? '<path d="M' + f1(x - r) + ' ' + f1(y) + ' Q' + f1(x) + ' ' + f1(y + r * .7) + ' ' + f1(x + r) + ' ' + f1(y) + '" stroke="#1a0a04" stroke-width="1.6" fill="none" stroke-linecap="round"/>' :
    '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r + 1.2) + '" fill="#f2e2cc" opacity=".7"/><circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" fill="url(#sqE)"/><circle cx="' + f1(x - r * .35) + '" cy="' + f1(y - r * .4) + '" r="' + f1(r * .32) + '" fill="#fff"/><circle cx="' + f1(x + r * .4) + '" cy="' + f1(y + r * .35) + '" r="' + f1(r * .14) + '" fill="#fff" opacity=".6"/>'; }
  function ear(x, y, a, s, R) { /* ear with the red squirrel's long tufts */ var o = '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(a) + ') scale(' + s + ')"><path d="M-6 4 C-8 -6 -4 -16 0 -22 C5 -15 8 -6 6 4Z" fill="' + col(.5) + '"/><path d="M-3 2 C-4 -6 -2 -12 0 -16 C3 -11 4 -5 3 2Z" fill="' + col(.3) + '"/>';
    for (var i = 0; i < 16; i++) o += strand((R() - .5) * 4, -18 - R() * 4, -90 + (R() - .5) * 40, 10 + R() * 9, (R() - .5) * 2, col(.4 + R() * .4), .8 + R() * .5, .9); return o + '</g>'; }
  function nut(x, y, r) { return '<g transform="translate(' + f1(x) + ' ' + f1(y) + ')"><ellipse cx="0" cy="1" rx="' + f1(r) + '" ry="' + f1(r * 1.1) + '" fill="url(#sqNut)"/><path d="M' + f1(-r * .9) + ' ' + f1(-r * .3) + ' Q0 ' + f1(-r * 1.6) + ' ' + f1(r * .9) + ' ' + f1(-r * .3) + ' Q0 ' + f1(-r * .7) + ' ' + f1(-r * .9) + ' ' + f1(-r * .3) + 'Z" fill="#c9b07a"/><ellipse cx="' + f1(-r * .3) + '" cy="' + f1(r * .1) + '" rx="' + f1(r * .25) + '" ry="' + f1(r * .45) + '" fill="#fff" opacity=".35"/></g>'; }

  var DEFS = '<defs><radialGradient id="sqE" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#5a3420"/><stop offset=".5" stop-color="#1a0c06"/><stop offset="1" stop-color="#050202"/></radialGradient>' +
    '<radialGradient id="sqNut" cx=".35" cy=".35" r=".8"><stop offset="0" stop-color="#c88a4a"/><stop offset=".6" stop-color="#8a5226"/><stop offset="1" stop-color="#4a2a10"/></radialGradient>' +
    '<radialGradient id="sqB" cx=".55" cy=".35" r=".75"><stop offset="0" stop-color="' + col(.66) + '"/><stop offset=".7" stop-color="' + col(.42) + '"/><stop offset="1" stop-color="' + col(.26) + '"/></radialGradient>' +
    '<linearGradient id="sqC" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbf4e6"/><stop offset="1" stop-color="#d8c6a8"/></linearGradient>' +
    '<filter id="sqSh" x="-10%" y="-10%" width="120%" height="125%"><feDropShadow dx="1" dy="4" stdDeviation="3" flood-color="#0a0510" flood-opacity=".5"/></filter></defs>';

  /* sitting up, side on */
  function sit(pose) { var R = rng(17), o = '', flick = pose.flick, nib = pose.nib ? 1 : 0;
    o += tail(rng(3), flick ? [[78, 186], [56, 168], [40, 134], [40, 98], [52, 64], [72, 44], [94, 46]] : [[78, 186], [58, 172], [42, 140], [44, 104], [56, 72], [76, 54], [96, 56]], 17, flick);
    /* body and haunch */
    o += '<path d="M70 196 C58 168 64 126 90 104 C108 88 132 92 140 112 C148 134 146 170 132 196Z" fill="url(#sqB)"/>';
    o += '<ellipse cx="88" cy="172" rx="32" ry="28" fill="' + col(.5) + '"/>';
    o += fur(R, 98, 150, 40, 50, -10, 260, function (x, y) { return 110 - (x - 100) * .3; }, 9, .55);
    o += fur(R, 86, 172, 30, 26, 0, 110, function (x, y) { return 100 + (y - 172) * 1.4; }, 8, .5);
    /* the cream chest and belly */
    o += '<path d="M128 104 C142 118 144 158 132 192 C122 186 116 150 120 116Z" fill="url(#sqC)"/>';
    for (var i = 0; i < 70; i++) { var t = R(), x = 122 + t * 6 + (R() - .5) * 14 + Math.sin(t * Math.PI) * 8, y = 108 + t * 82; o += strand(x, y, 96 + (R() - .5) * 30, 5 + R() * 6, (R() - .5) * 2, R() < .5 ? '#fffaf0' : '#cdb898', .6 + R() * .4, .85); }
    /* hind foot */
    o += '<path d="M78 196 C96 192 124 194 134 200 C122 205 92 205 78 201Z" fill="' + col(.36) + '"/>';
    for (i = 0; i < 14; i++) o += lock(84 + R() * 46, 194 + R() * 4, 10 + (R() - .5) * 30, 6 + R() * 4, 2, 0, col(.4 + R() * .2));
    /* head: side on, or turned to look at the audience */
    var hy = nib ? 3 : 0;
    o += '<g transform="translate(' + (nib ? -4 : -6) + ' ' + (hy + 10) + ')">';
    if (pose.look || pose.blink) {
      o += ear(108, 50, -24, 1.05, rng(41)) + ear(140, 50, 22, 1.05, rng(42));
      o += '<path d="M100 76 C98 56 110 44 124 44 C138 44 150 56 148 76 C146 92 136 102 124 102 C112 102 102 92 100 76Z" fill="url(#sqB)"/>';
      o += fur(rng(43), 124, 70, 22, 26, 0, 120, function (x, y) { return 90 + (x - 124) * 2.2; }, 6, .6);
      o += '<path d="M110 86 C114 96 120 100 124 100 C128 100 134 96 138 86 C132 90 116 90 110 86Z" fill="url(#sqC)"/>';
      o += eye(113, 70, 4.8, pose.blink) + eye(135, 70, 4.8, pose.blink);
      o += '<path d="M120 86 C122 84 126 84 128 86 C127 89 125 90 124 90 C123 90 121 89 120 86Z" fill="#3a1e14"/><path d="M124 90 V94 M124 94 Q120 97 117 95 M124 94 Q128 97 131 95" stroke="#3a1e14" stroke-width="1" fill="none"/>';
      for (i = 0; i < 6; i++) o += strand(i < 3 ? 116 : 132, 90 + (i % 3) * 2, i < 3 ? 180 + (i - 1) * 10 : (i - 4) * 10, 14, 0, '#f0e6d8', .5, .7);
    } else {
      o += ear(118, 50, 8, 1.05, rng(41));
      o += '<path d="M104 78 C100 58 114 44 130 46 C146 48 158 62 164 74 C168 82 162 88 152 90 C138 94 110 94 104 78Z" fill="url(#sqB)"/>';
      o += fur(rng(43), 130, 70, 26, 20, 8, 120, function (x, y) { return 170 + (y - 70) * .6; }, 6, .62);
      o += '<path d="M126 88 C138 92 152 92 160 86 C156 94 142 98 130 96Z" fill="url(#sqC)"/>';
      o += eye(138, 64, 5.2, false);
      o += '<path d="M161 72 C165 72 167 76 165 78 C163 79 160 77 161 72Z" fill="#3a1e14"/>';
      for (i = 0; i < 5; i++) o += strand(158, 78, -20 + i * 12, 16, 0, '#f0e6d8', .5, .7);
    }
    o += '</g>';
    /* forepaws holding a hazelnut up to its mouth */
    var ny = pose.look || pose.blink ? 114 : 106 + hy, nx = pose.look || pose.blink ? 118 : 146;
    o += nut(nx, ny, 7.5);
    var PR = rng(77); [[-12, .44], [-2, .52]].forEach(function (q) { var x0 = nx + q[0] - 6, y0 = ny + 26, x1 = nx + q[0] * .4, y1 = ny + 4;
      o += '<path d="M' + f1(x0) + ' ' + f1(y0) + ' C' + f1(x0 + 2) + ' ' + f1(y0 - 12) + ' ' + f1(x1 - 4) + ' ' + f1(y1 + 8) + ' ' + f1(x1) + ' ' + f1(y1) + '" stroke="' + col(q[1]) + '" stroke-width="8.5" fill="none" stroke-linecap="round"/>';
      for (var j = 0; j < 10; j++) { var t = PR(); o += lock(x0 + (x1 - x0) * t + (PR() - .5) * 4, y0 + (y1 - y0) * t, 120 + (PR() - .5) * 40, 4 + PR() * 3, 1.6, 0, col(q[1] + (PR() - .5) * .2)); }
      o += '<ellipse cx="' + f1(x1 + 1) + '" cy="' + f1(y1 - 1) + '" rx="3.6" ry="3" fill="' + col(.3) + '"/>'; });
    return o; }

  /* a hop: gathered up on landing, or stretched out mid-leap */
  function hop(leap) { var R = rng(leap ? 29 : 23), o = '', i;
    var sp = leap ? [[70, 132], [52, 124], [36, 112], [24, 98], [20, 82], [28, 66]] : [[64, 146], [44, 128], [36, 102], [44, 76], [62, 62], [82, 64]];
    o += tail(rng(5), sp, 16, false);
    /* far legs */
    o += leap ? '<path d="M70 150 C56 162 42 172 28 176" stroke="' + col(.24) + '" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M146 146 C158 152 170 156 184 156" stroke="' + col(.24) + '" stroke-width="6" fill="none" stroke-linecap="round"/>' :
      '<path d="M84 168 C100 176 116 180 128 180" stroke="' + col(.24) + '" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M134 160 C138 170 140 176 142 182" stroke="' + col(.24) + '" stroke-width="6" fill="none" stroke-linecap="round"/>';
    /* body */
    o += leap ? '<path d="M60 140 C64 120 96 112 128 116 C150 118 162 128 158 140 C154 152 132 158 104 158 C80 158 58 156 60 140Z" fill="url(#sqB)"/>' :
      '<path d="M66 160 C60 132 82 116 108 118 C130 120 146 132 146 150 C146 166 128 176 104 176 C84 176 70 172 66 160Z" fill="url(#sqB)"/>';
    o += leap ? fur(R, 108, 136, 48, 18, 2, 240, function () { return 182; }, 9, .55) : fur(R, 106, 148, 38, 26, 0, 220, function (x, y) { return 170 + (y - 148) * 1.2; }, 8, .55);
    o += leap ? '<path d="M96 156 C116 160 140 156 152 146 C146 156 124 162 100 160Z" fill="url(#sqC)"/>' : '<path d="M118 172 C132 170 142 162 146 152 C146 166 134 176 116 176Z" fill="url(#sqC)"/>';
    /* near legs: hind and fore */
    o += leap ? '<path d="M84 146 C70 156 58 164 44 168" stroke="' + col(.4) + '" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M46 168 L30 172" stroke="' + col(.34) + '" stroke-width="7" stroke-linecap="round"/><path d="M144 144 C158 148 172 150 188 148" stroke="' + col(.42) + '" stroke-width="8" fill="none" stroke-linecap="round"/><ellipse cx="190" cy="148" rx="4" ry="3" fill="' + col(.3) + '"/>' :
      '<ellipse cx="88" cy="162" rx="22" ry="17" fill="' + col(.48) + '"/><path d="M90 176 C104 182 120 184 134 184" stroke="' + col(.36) + '" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M136 158 C140 168 144 176 148 184" stroke="' + col(.42) + '" stroke-width="7" fill="none" stroke-linecap="round"/>';
    if (!leap) o += fur(R, 88, 160, 20, 15, 0, 60, function (x, y) { return 100 + (y - 160); }, 6, .5);
    /* head */
    var hx = leap ? 170 : 156, hy = leap ? 118 : 132;
    o += ear(hx - 16, hy - 16, 4, 1, rng(41));
    o += '<path d="M' + f1(hx - 22) + ' ' + f1(hy + 4) + ' C' + f1(hx - 24) + ' ' + f1(hy - 14) + ' ' + f1(hx - 10) + ' ' + f1(hy - 22) + ' ' + f1(hx + 2) + ' ' + f1(hy - 20) + ' C' + f1(hx + 14) + ' ' + f1(hy - 18) + ' ' + f1(hx + 24) + ' ' + f1(hy - 6) + ' ' + f1(hx + 28) + ' ' + f1(hy + 2) + ' C' + f1(hx + 30) + ' ' + f1(hy + 8) + ' ' + f1(hx + 22) + ' ' + f1(hy + 12) + ' ' + f1(hx + 12) + ' ' + f1(hy + 13) + ' C' + f1(hx - 2) + ' ' + f1(hy + 15) + ' ' + f1(hx - 20) + ' ' + f1(hy + 14) + ' ' + f1(hx - 22) + ' ' + f1(hy + 4) + 'Z" fill="url(#sqB)"/>';
    o += fur(rng(44), hx + 2, hy - 2, 22, 14, 6, 90, function (x, y) { return 175 + (y - hy) * .6; }, 5.5, .62);
    o += '<path d="M' + f1(hx - 4) + ' ' + f1(hy + 10) + ' C' + f1(hx + 8) + ' ' + f1(hy + 14) + ' ' + f1(hx + 20) + ' ' + f1(hy + 12) + ' ' + f1(hx + 26) + ' ' + f1(hy + 6) + ' C' + f1(hx + 22) + ' ' + f1(hy + 14) + ' ' + f1(hx + 6) + ' ' + f1(hy + 18) + ' ' + f1(hx - 4) + ' ' + f1(hy + 10) + 'Z" fill="url(#sqC)"/>';
    o += eye(hx + 6, hy - 6, 4.8, false) + '<path d="M' + f1(hx + 26) + ' ' + f1(hy - 1) + ' c3 0 4 3 2 5 c-2 1 -3 -1 -2 -5Z" fill="#3a1e14"/>';
    return o; }

  function svg(pose, w, h) { var body = pose.hop ? hop(pose.hop === 'leap') : sit(pose);
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="' + VB.join(' ') + '">' + DEFS + '<g filter="url(#sqSh)">' + body + '</g></svg>'; }
  var POSES = [{ hop: 'crouch' }, { hop: 'leap' }, {}, { nib: 1 }, { look: 1 }, { blink: 1 }, { flick: 1 }];
  window.SquirrelArt = { svg: svg, VB: VB, POSES: POSES };
})();

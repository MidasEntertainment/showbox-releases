/* A shaggy Highland cow for the Burns Night frame, painted with thousands of locks and strands of hair, shaded for volume (not clip-art).
   CowArt.svg(pose, w, h): pose = { walk: 0..1 } for the 16 drawings of its stride, { stand: 1 } standing in profile,
   or { front: 1, jaw: -1|1, fringe: 1, blink: 1 } standing with its head turned to the audience.
   CowArt.POSES: 16 walking, then standing: profile, front, chew left, chew right, fringe tossed, blink.
   CowArt.STRIDE: how far (in drawing units) it moves over one walk cycle, so its feet never slide. Faces right. */
(function () {
  var VB = [-10, -20, 540, 330], FOOT = 293, A = 30, STANCE = .62;
  function f1(n) { return (+n).toFixed(1); }
  function rng(s) { return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
  /* the coat's colours, from the deep shadow under the belly to the sun-bleached ginger on its back */
  var PAL = [[0, [40, 15, 6]], [.18, [82, 33, 13]], [.38, [138, 62, 26]], [.58, [189, 103, 48]], [.76, [222, 148, 84]], [.9, [240, 188, 126]], [1, [250, 218, 168]]];
  function col(v) { v = Math.max(0, Math.min(1, v)); for (var i = 1; i < PAL.length; i++) if (v <= PAL[i][0]) { var a = PAL[i - 1], b = PAL[i], t = (v - a[0]) / (b[0] - a[0]);
    return 'rgb(' + [0, 1, 2].map(function (j) { return Math.round(a[1][j] + (b[1][j] - a[1][j]) * t); }).join(',') + ')'; } return 'rgb(250,218,168)'; }
  function curve(pts, x) { if (x <= pts[0][0]) return pts[0][1]; for (var i = 1; i < pts.length; i++) if (x <= pts[i][0]) { var a = pts[i - 1], b = pts[i], t = (x - a[0]) / (b[0] - a[0]); t = t * t * (3 - 2 * t); return a[1] + (b[1] - a[1]) * t; } return pts[pts.length - 1][1]; }
  var BACK = [[52, 112], [70, 86], [110, 74], [170, 76], [230, 76], [290, 64], [325, 60], [352, 70], [368, 96]], BELLY = [[52, 150], [64, 196], [100, 214], [200, 222], [290, 218], [345, 202], [368, 170]];
  var backY = function (x) { return curve(BACK, x); }, bellyY = function (x) { return curve(BELLY, x); };
  /* light falls from above: a barrel of a body, bright along the back, deep under the belly */
  function lum(x, y) { var nx = (x - 210) / 165, ny = (y - 145) / 82; return .6 - .42 * ny - .12 * nx * nx + (ny < -.6 ? .08 : 0); }

  /* one lock of hair: a tapered, gently S-curved shape from its root (x,y), hanging at angle a (degrees, 90 = straight down), length L, root width w */
  function lock(x, y, a, L, w, bend, c, hi) { var r = a * Math.PI / 180, dx = Math.cos(r), dy = Math.sin(r), nx = -dy, ny = dx, P = function (t, s) { var b = Math.sin(t * Math.PI * 1.3) * bend * L * .16; return [x + dx * L * t + nx * (b + s), y + dy * L * t + ny * (b + s)]; };
    var pts = [[0, 1], [.25, .85], [.5, .6], [.75, .32], [.92, .12], [1, 0]], L1 = [], L2 = [];
    pts.forEach(function (p) { L1.push(P(p[0], w * p[1] / 2)); L2.unshift(P(p[0], -w * p[1] / 2)); });
    var all = L1.concat(L2.slice(1)), d = 'M' + f1(all[0][0]) + ' ' + f1(all[0][1]);
    for (var i = 1; i < all.length; i++) { var m = [(all[i - 1][0] + all[i][0]) / 2, (all[i - 1][1] + all[i][1]) / 2]; d += 'Q' + f1(all[i - 1][0]) + ' ' + f1(all[i - 1][1]) + ' ' + f1(m[0]) + ' ' + f1(m[1]); }
    var o = '<path d="' + d + 'Z" fill="' + c + '"/>';
    if (hi) { var h0 = P(.1, -w * .12), h1 = P(.45, -w * .1), h2 = P(.78, 0); o += '<path d="M' + f1(h0[0]) + ' ' + f1(h0[1]) + 'Q' + f1(h1[0]) + ' ' + f1(h1[1]) + ' ' + f1(h2[0]) + ' ' + f1(h2[1]) + '" stroke="' + hi + '" stroke-width="' + f1(Math.max(.5, w * .12)) + '" fill="none" stroke-linecap="round" opacity=".55"/>'; }
    return o; }
  /* a single fine hair */
  function strand(x, y, a, L, bend, c, sw, op) { var r = a * Math.PI / 180, dx = Math.cos(r), dy = Math.sin(r), nx = -dy, ny = dx, b = bend * L * .2;
    return '<path d="M' + f1(x) + ' ' + f1(y) + 'C' + f1(x + dx * L * .33 + nx * b) + ' ' + f1(y + dy * L * .33 + ny * b) + ' ' + f1(x + dx * L * .66 - nx * b * .8) + ' ' + f1(y + dy * L * .66 - ny * b * .8) + ' ' + f1(x + dx * L) + ' ' + f1(y + dy * L) + '" stroke="' + c + '" stroke-width="' + f1(sw) + '" fill="none" stroke-linecap="round"' + (op < 1 ? ' opacity="' + op + '"' : '') + '/>'; }

  /* the coat is identical in every drawing, so it is built once */
  var COAT = null, HEM = null;
  function buildCoat() { var R = rng(31), o = '', rows = 15, per = 44, i, r, x, y;
    /* underlay so no gaps show between the locks */
    var d = 'M' + BACK.map(function (p) { return p[0] + ' ' + p[1]; }).join(' L') + ' L' + BELLY.slice().reverse().map(function (p) { return p[0] + ' ' + p[1]; }).join(' L') + 'Z';
    o += '<path d="' + d + '" fill="' + col(.2) + '" stroke="' + col(.2) + '" stroke-width="10" stroke-linejoin="round"/>';
    /* rows of locks from the belly up, so each row hangs over the one below */
    for (r = 0; r < rows; r++) { var t = 1 - r / (rows - 1);
      for (i = 0; i < per; i++) { x = 54 + 314 * (i + R()) / per; var yT = backY(x), yB = bellyY(x); y = yT + (yB - yT) * t * .94 + (R() - .5) * 7;
        var L = 18 + 20 * t + R() * 10, a = 95 + (x < 110 ? (110 - x) * .25 : 0) + (x > 330 ? -(x - 330) * .2 : 0) + (R() - .5) * 16, v = lum(x, y + L * .5) + (R() - .5) * .16;
        o += lock(x, y, a, L, 3.6 + R() * 3.4, (R() - .5) * 2.4, col(v), R() < .45 ? col(v + .2) : null); } }
    /* the sun-bleached top of the coat, parted along the spine */
    for (i = 0; i < 70; i++) { x = 58 + 306 * R(); y = backY(x) - 3 + R() * 4; o += lock(x, y, 100 + (R() - .5) * 26, 22 + R() * 16, 4 + R() * 3, (R() - .5) * 2, col(.74 + R() * .2), col(.97)); }
    /* fine hairs over everything: highlights and shadow lines that make it read as hair, not scales */
    for (i = 0; i < 900; i++) { x = 56 + 310 * R(); var yT2 = backY(x), yB2 = bellyY(x) + 20; y = yT2 + (yB2 - yT2) * Math.pow(R(), .9); var v2 = lum(x, y), up = R() < .55;
      o += strand(x, y, 94 + (R() - .5) * 22, 12 + R() * 22, (R() - .5) * 2.5, col(v2 + (up ? .14 + R() * .12 : -.16)), .5 + R() * .7, up ? .75 : .6); }
    /* a few flyaway hairs catching the light along the back */
    for (i = 0; i < 46; i++) { x = 60 + 300 * R(); y = backY(x) + 1; o += strand(x, y, 200 + R() * 120, 8 + R() * 12, (R() - .5) * 3, col(.86 + R() * .12), .55 + R() * .4, .8); }
    COAT = o;
    /* the hem: long ragged locks along the belly, drawn over the tops of the near legs */
    var H2 = rng(8); o = '';
    for (i = 0; i < 52; i++) { x = 60 + 304 * (i + H2()) / 52; y = bellyY(x) - 16 + H2() * 8; var v3 = lum(x, y + 14) + (H2() - .5) * .14;
      o += lock(x, y, 93 + (H2() - .5) * 18, 22 + H2() * 16, 4 + H2() * 3, (H2() - .5) * 2.4, col(v3), H2() < .4 ? col(v3 + .18) : null); }
    for (i = 0; i < 160; i++) { x = 60 + 304 * H2(); y = bellyY(x) - 12 + H2() * 10; o += strand(x, y, 92 + (H2() - .5) * 24, 12 + H2() * 24, (H2() - .5) * 2.5, col(lum(x, y) + (H2() < .5 ? .14 : -.14)), .5 + H2() * .6, .7); }
    HEM = o; }

  /* one leg: hip at (hx,hy); foot offset fx along the ground (+ = forward) and lift 0..1. Short, sturdy and shaggy, with a cloven hoof */
  function leg(hx, hy, fx, lift, far, seed) { var R = rng(seed), footX = hx + fx, footY = FOOT - 9 - lift * 13, kx = (hx + footX) / 2 + lift * 7, ky = hy + (footY - hy) * .52 - lift * 4;
    var dk = far ? -.13 : 0, cA = col(.3 + dk), cB = col(.2 + dk), o = '';
    o += '<path d="M' + f1(hx - 17) + ' ' + f1(hy - 6) + ' C' + f1(hx - 16) + ' ' + f1(hy + 16) + ' ' + f1(kx - 11) + ' ' + f1(ky - 8) + ' ' + f1(kx - 9) + ' ' + f1(ky + 2) + ' C' + f1(kx - 8) + ' ' + f1(ky + 14) + ' ' + f1(footX - 7) + ' ' + f1(footY - 14) + ' ' + f1(footX - 7) + ' ' + f1(footY) +
      ' L' + f1(footX + 8) + ' ' + f1(footY) + ' C' + f1(footX + 8) + ' ' + f1(footY - 14) + ' ' + f1(kx + 10) + ' ' + f1(ky + 12) + ' ' + f1(kx + 10) + ' ' + f1(ky + 2) + ' C' + f1(kx + 12) + ' ' + f1(ky - 8) + ' ' + f1(hx + 17) + ' ' + f1(hy + 16) + ' ' + f1(hx + 17) + ' ' + f1(hy - 6) + 'Z" fill="' + cA + '"/>';
    /* shading down the back of the leg and a soft light down the front */
    o += '<path d="M' + f1(kx + 6) + ' ' + f1(ky - 16) + ' Q' + f1(kx + 8) + ' ' + f1(ky + 8) + ' ' + f1(footX + 5) + ' ' + f1(footY - 6) + '" stroke="' + cB + '" stroke-width="5" fill="none" opacity=".7" stroke-linecap="round"/>';
    o += '<path d="M' + f1(kx - 6) + ' ' + f1(ky - 10) + ' Q' + f1(kx - 6) + ' ' + f1(ky + 8) + ' ' + f1(footX - 4) + ' ' + f1(footY - 8) + '" stroke="' + col(.46 + dk) + '" stroke-width="2.2" fill="none" opacity=".6" stroke-linecap="round"/>';
    /* hair down the leg, longest at the top, a tuft over the fetlock */
    for (var i = 0; i < 26; i++) { var t = Math.pow(R(), .8) * .8, x = hx + (footX - hx) * t + (R() - .5) * (22 - t * 12), y = hy + (footY - hy) * t - 4; o += lock(x, y, 93 + (R() - .5) * 22, 12 + (1 - t) * 12 + R() * 6, 3.5 + R() * 2.5, (R() - .5) * 2, col(.22 + (1 - t) * .14 + dk + (R() - .5) * .12), R() < .4 ? col(.48 + dk) : null); }
    for (i = 0; i < 9; i++) o += lock(footX + (R() - .5) * 14, footY - 15 + R() * 5, 92 + (R() - .5) * 26, 9 + R() * 5, 3 + R() * 2, 0, col(.17 + dk + R() * .08), null);
    /* the hoof, split in two, with a little shine */
    o += '<path d="M' + f1(footX - 8) + ' ' + f1(footY - 2) + ' L' + f1(footX + 9) + ' ' + f1(footY - 2) + ' C' + f1(footX + 11) + ' ' + f1(footY + 3) + ' ' + f1(footX + 12) + ' ' + f1(footY + 7) + ' ' + f1(footX + 11) + ' ' + f1(footY + 9) + ' L' + f1(footX - 8) + ' ' + f1(footY + 9) + ' C' + f1(footX - 9) + ' ' + f1(footY + 5) + ' ' + f1(footX - 9) + ' ' + f1(footY + 2) + ' ' + f1(footX - 8) + ' ' + f1(footY - 2) + 'Z" fill="url(#cwHoof)"/>' +
      '<path d="M' + f1(footX + 2) + ' ' + f1(footY) + ' V' + f1(footY + 9) + '" stroke="#0c0806" stroke-width="1.3"/><path d="M' + f1(footX - 5) + ' ' + f1(footY + 1) + ' Q' + f1(footX - 6) + ' ' + f1(footY + 5) + ' ' + f1(footX - 5) + ' ' + f1(footY + 7) + '" stroke="#6a5a52" stroke-width="1" fill="none" opacity=".7"/>';
    return o; }

  function horn(d, extra, id) { return '<path d="' + d + '" fill="url(#' + id + ')"/>' + (extra || ''); }

  /* the head in profile, looking where it walks */
  function headSide(pose) { var R = rng(53), o = '', i, x, y, top, jaw = pose.jaw ? 3 : 0;
    /* far horn, just showing behind the near one */
    o += horn('M396 90 C382 82 368 74 360 60 C354 50 352 38 356 26 C346 36 342 52 348 64 C356 80 372 90 386 98Z', '', 'cwHornF');
    /* neck, head and jowl */
    o += '<path d="M330 62 C356 60 388 70 404 88 C424 110 446 140 460 164 C472 184 470 204 458 213 C444 222 420 218 402 208 C380 196 356 186 340 168 C330 140 326 96 330 62Z" fill="url(#cwHd)"/>';
    /* mane down the top of the neck */
    for (i = 0; i < 40; i++) { x = 322 + R() * 70; y = 58 + (x - 322) * .4 + R() * 10; o += lock(x, y, 100 + (R() - .5) * 24, 28 + R() * 18, 4.5 + R() * 3, (R() - .5) * 2.4, col(.62 + R() * .26), R() < .5 ? col(.95) : null); }
    /* cheek and throat hair */
    for (i = 0; i < 60; i++) { x = 336 + R() * 94; top = 96 + (x - 336) * .7; y = top + R() * (196 - top); o += lock(x, y, 94 + (R() - .5) * 22, 16 + R() * 18, 3.5 + R() * 3, (R() - .5) * 2.4, col(lum(x, y) * .7 + .12 + (R() - .5) * .14), R() < .4 ? col(.6) : null); }
    for (i = 0; i < 120; i++) { x = 334 + R() * 100; top = 80 + (x - 334) * .7; y = top + R() * (200 - top); o += strand(x, y, 92 + (R() - .5) * 24, 10 + R() * 18, (R() - .5) * 2.4, col(.36 + R() * .36), .5 + R() * .6, .65); }
    /* the broad, damp muzzle */
    o += '<path d="M436 168 C448 163 462 165 470 174 C475 184 475 198 469 208 C459 215 442 215 432 207 C426 197 428 179 436 168Z" fill="url(#cwN)"/>' +
      '<path d="M442 170 C450 167 458 168 464 174" stroke="#c8aaa2" stroke-width="1.8" fill="none" opacity=".35" stroke-linecap="round"/>' +
      '<path d="M461 184 C466 182 470 186 468 191 C465 194 460 192 459 188Z" fill="#160c0b"/>' +
      '<path d="M461 207 C452 212 440 213 430 209" stroke="#24181a" stroke-width="1.6" fill="none"/>';
    o += '<path d="M458 ' + f1(211 + jaw) + ' C446 ' + f1(221 + jaw) + ' 424 ' + f1(223 + jaw) + ' 408 ' + f1(212 + jaw * .5) + ' C422 214 440 214 458 ' + f1(211 + jaw) + 'Z" fill="#4a3432"/>';
    for (i = 0; i < 16; i++) o += lock(408 + R() * 40, 210 + jaw + R() * 4, 94 + (R() - .5) * 20, 9 + R() * 8, 3 + R() * 2, 0, col(.25 + R() * .15), null);
    /* hair along the face, down to the top of the nose */
    for (i = 0; i < 46; i++) { var ft = R(); x = 398 + ft * 50 + (R() - .5) * 10; y = 92 + ft * 76 + (R() - .5) * 10; o += lock(x, y, 70 + (R() - .5) * 24, 16 + R() * 14, 3.5 + R() * 3, (R() - .5) * 2.4, col(.4 + R() * .34), R() < .4 ? col(.85) : null); }
    /* hair over the bridge of the nose, falling forward onto the top of the muzzle */
    for (i = 0; i < 40; i++) { var bt = .35 + R() * .65; x = 404 + bt * 56 + (R() - .5) * 8; y = 90 + bt * 78 + (R() - .5) * 8; o += lock(x - 6, y - 4, 62 + (R() - .5) * 20, 14 + R() * 14, 3 + R() * 2.6, (R() - .5) * 2, col(.38 + R() * .3), R() < .35 ? col(.8) : null); }
    for (i = 0; i < 50; i++) { bt = .3 + R() * .7; x = 404 + bt * 56; y = 90 + bt * 78; o += strand(x - 8 + R() * 6, y - 6 + R() * 6, 60 + (R() - .5) * 26, 10 + R() * 14, (R() - .5) * 2.4, col(.42 + R() * .4), .5 + R() * .5, .75); }
    /* the ear, out sideways under the horn, fringed with long hair */
    o += '<path d="M386 106 C372 98 350 102 338 114 C352 122 372 122 388 118Z" fill="' + col(.26) + '"/><path d="M380 109 C368 106 356 108 348 114 C360 117 372 117 382 115Z" fill="' + col(.12) + '"/>';
    for (i = 0; i < 16; i++) o += lock(384 - R() * 44, 104 + R() * 14, 125 + (R() - .5) * 40, 12 + R() * 9, 3 + R() * 2, (R() - .5) * 2, col(.55 + R() * .3), null);
    /* the eye, half hidden under the fringe */
    if (!pose.blink) o += '<ellipse cx="414" cy="133" rx="5.5" ry="4.6" fill="#120a08"/><circle cx="412.3" cy="131.6" r="1.4" fill="#fff" opacity=".85"/>';
    /* a shaggy top-knot over the poll, between the horns */
    for (i = 0; i < 34; i++) { x = 350 + R() * 56; y = 64 + (x - 350) * .42 + R() * 6; o += lock(x, y, 78 + (R() - .5) * 30, 18 + R() * 14, 4 + R() * 3, (R() - .5) * 2.4, col(.6 + R() * .3), R() < .5 ? col(.96) : null); }
    /* near horn: out of the side of the poll, sweeping up and forward to a dark tip */
    o += horn('M380 96 C396 86 414 78 424 62 C432 50 434 38 432 26 C440 36 444 52 438 66 C430 84 412 96 396 104Z',
      '<path d="M392 92 C408 84 420 74 428 58" stroke="#fff" stroke-width="1.8" fill="none" opacity=".5" stroke-linecap="round"/><path d="M386 97 C390 92 392 90 394 88 M392 101 C396 96 398 93 400 91" stroke="#a8916c" stroke-width="1.5" fill="none" opacity=".8"/>', 'cwHorn');
    /* the fringe: long wavy locks falling forward from the poll over the eyes */
    var F = '', fr = rng(71);
    for (i = 0; i < 96; i++) { var u = fr(), x0 = 366 + u * 52, y0 = 80 + fr() * 16 + u * 8, dark = i < 32; F += lock(x0, y0, 56 + u * 22 + (fr() - .5) * 14, 46 + fr() * 40 + (u > .5 ? 10 : 0), 4.5 + fr() * 4, (fr() - .5) * 2.6, col(dark ? .42 + fr() * .16 : .66 + fr() * .26), dark ? null : col(.98)); }
    for (i = 0; i < 110; i++) { var u2 = fr(); F += strand(366 + u2 * 52, 84 + fr() * 14, 60 + u2 * 22 + (fr() - .5) * 16, 30 + fr() * 40, (fr() - .5) * 3, col(.72 + fr() * .26), .5 + fr() * .5, .8); }
    o += '<g transform="rotate(' + (pose.fringe ? -14 : 0) + ' 390 90)">' + F + '</g>';
    return o; }

  /* the head turned to face the audience: wide horns, ears out sideways, a thick fringe over the eyes and a broad wet nose */
  function headFront(pose) { var CX = 400, R = rng(91), o = '', i, s, t, x, y, jx = (pose.jaw || 0) * 4;
    /* horns, out sideways and sweeping up */
    [-1, 1].forEach(function (s) { var X = function (v) { return f1(CX + s * v); };
      o += horn('M' + X(20) + ' 80 C' + X(48) + ' 70 ' + X(76) + ' 72 ' + X(90) + ' 56 C' + X(100) + ' 44 ' + X(100) + ' 28 ' + X(94) + ' 14 C' + X(110) + ' 26 ' + X(114) + ' 50 ' + X(104) + ' 68 C' + X(90) + ' 88 ' + X(56) + ' 94 ' + X(22) + ' 98Z',
        '<path d="M' + X(30) + ' 80 C' + X(58) + ' 74 ' + X(80) + ' 70 ' + X(94) + ' 50" stroke="#fff" stroke-width="1.8" fill="none" opacity=".45" stroke-linecap="round"/><path d="M' + X(30) + ' 79 C' + X(31) + ' 86 ' + X(32) + ' 92 ' + X(32) + ' 96 M' + X(38) + ' 77 C' + X(39) + ' 84 ' + X(40) + ' 90 ' + X(40) + ' 94" stroke="#a8916c" stroke-width="1.5" fill="none" opacity=".8"/>', 'cwHornS'); });
    /* ears, under the horns, fringed with hair */
    [-1, 1].forEach(function (s) { var X = function (v) { return f1(CX + s * v); };
      o += '<path d="M' + X(30) + ' 100 C' + X(50) + ' 94 ' + X(72) + ' 98 ' + X(84) + ' 110 C' + X(70) + ' 120 ' + X(50) + ' 120 ' + X(32) + ' 116Z" fill="' + col(.28) + '"/><path d="M' + X(40) + ' 104 C' + X(54) + ' 101 ' + X(68) + ' 104 ' + X(76) + ' 110 C' + X(64) + ' 115 ' + X(52) + ' 115 ' + X(42) + ' 113Z" fill="' + col(.12) + '"/>';
      for (var j = 0; j < 14; j++) o += lock(CX + s * (40 + R() * 44), 100 + R() * 16, 90 + s * (30 + R() * 30), 10 + R() * 9, 3 + R() * 2, (R() - .5) * 2, col(.55 + R() * .3), null); });
    /* the broad head */
    o += '<path d="M' + (CX - 38) + ' 80 C' + (CX - 50) + ' 120 ' + (CX - 44) + ' 170 ' + (CX - 37) + ' 204 C' + (CX - 31) + ' 232 ' + (CX + 31) + ' 232 ' + (CX + 37) + ' 204 C' + (CX + 44) + ' 170 ' + (CX + 50) + ' 120 ' + (CX + 38) + ' 80 C' + (CX + 20) + ' 62 ' + (CX - 20) + ' 62 ' + (CX - 38) + ' 80Z" fill="url(#cwHdF)"/>';
    /* hair down the sides of the face and the cheeks */
    for (i = 0; i < 70; i++) { s = R() < .5 ? -1 : 1; t = R(); x = CX + s * (30 + 14 * Math.sin(t * Math.PI) - t * 6 + R() * 8); y = 86 + t * 100; o += lock(x, y, 90 + s * (6 + R() * 12), 16 + R() * 16, 3.5 + R() * 3, (R() - .5) * 2.4, col(.36 + (1 - t) * .3 + (R() - .5) * .14), R() < .4 ? col(.8) : null); }
    for (i = 0; i < 90; i++) { s = R() < .5 ? -1 : 1; t = R(); x = CX + s * (8 + R() * 36); y = 90 + t * 110; o += strand(x, y, 90 + s * R() * 14, 10 + R() * 16, (R() - .5) * 2.4, col(.34 + R() * .4), .5 + R() * .5, .6); }
    /* eyes, just peeping from under the fringe */
    [-1, 1].forEach(function (s) { var ex = CX + s * 23; o += pose.blink ? '<path d="M' + f1(ex - 6) + ' 142 Q' + f1(ex) + ' 146 ' + f1(ex + 6) + ' 142" stroke="#2a1206" stroke-width="2" fill="none" stroke-linecap="round"/>' :
      '<ellipse cx="' + f1(ex) + '" cy="142" rx="6.2" ry="5.4" fill="#0f0806"/><circle cx="' + f1(ex - s * 1.6) + '" cy="140" r="1.7" fill="#fff" opacity=".9"/><circle cx="' + f1(ex + s * 2) + '" cy="144.5" r=".8" fill="#fff" opacity=".4"/>'; });
    /* the wide, damp nose: chews from side to side */
    o += '<g transform="translate(' + f1(jx * .35) + ' 0)"><path d="M' + (CX - 30) + ' 196 C' + (CX - 32) + ' 180 ' + (CX + 32) + ' 180 ' + (CX + 30) + ' 196 C' + (CX + 32) + ' 214 ' + (CX + 20) + ' 226 ' + CX + ' 226 C' + (CX - 20) + ' 226 ' + (CX - 32) + ' 214 ' + (CX - 30) + ' 196Z" fill="url(#cwNF)"/>' +
      '<path d="M' + (CX - 18) + ' 186 C' + (CX - 8) + ' 182 ' + (CX + 8) + ' 182 ' + (CX + 18) + ' 186" stroke="#d6bab2" stroke-width="2.4" fill="none" opacity=".45" stroke-linecap="round"/>';
    [-1, 1].forEach(function (s) { var nx = CX + s * 14; o += '<path d="M' + f1(nx - s * 6) + ' 198 C' + f1(nx - s * 6) + ' 192 ' + f1(nx + s * 4) + ' 191 ' + f1(nx + s * 6) + ' 197 C' + f1(nx + s * 7) + ' 203 ' + f1(nx) + ' 206 ' + f1(nx - s * 4) + ' 203Z" fill="#150b0a"/>'; });
    o += '<path d="M' + (CX - 14) + ' 216 Q' + CX + ' 220 ' + (CX + 14) + ' 216" stroke="#24181a" stroke-width="1.6" fill="none"/></g>';
    o += '<path d="M' + f1(CX - 20 + jx) + ' 224 C' + f1(CX - 12 + jx) + ' 234 ' + f1(CX + 12 + jx) + ' 234 ' + f1(CX + 20 + jx) + ' 224 C' + f1(CX + 8 + jx) + ' 228 ' + f1(CX - 8 + jx) + ' 228 ' + f1(CX - 20 + jx) + ' 224Z" fill="#4a3432"/>';
    for (i = 0; i < 14; i++) o += lock(CX + jx + (R() - .5) * 40, 226 + R() * 4, 90 + (R() - .5) * 30, 8 + R() * 8, 3 + R() * 2, 0, col(.22 + R() * .15), null);
    /* the fringe: a thick mop from the poll down over the eyes, fanning out; tossed up when it shakes its head */
    var F = '', fr = rng(61), u;
    for (i = 0; i < 90; i++) { u = fr() * 2 - 1; var dark = i < 30, x0 = CX + u * 38, y0 = 66 + Math.abs(u) * 14 + fr() * 12, nearEye = Math.abs(Math.abs(u) - .6) < .25;
      F += lock(x0, y0, 90 + u * 30 + (fr() - .5) * 16, (nearEye ? 60 : 66) + fr() * (nearEye ? 10 : 26), 4.5 + fr() * 4, (fr() - .5) * 2.6, col(dark ? .44 + fr() * .16 : .68 + fr() * .26), dark ? null : col(.98)); }
    for (i = 0; i < 90; i++) { u = fr() * 2 - 1; F += strand(CX + u * 36, 68 + Math.abs(u) * 14 + fr() * 10, 90 + u * 30 + (fr() - .5) * 18, 34 + fr() * 40, (fr() - .5) * 3, col(.72 + fr() * .26), .5 + fr() * .5, .8); }
    o += pose.fringe ? '<g transform="translate(0 ' + f1(70 - 10 - 70 * .78) + ') scale(1 .78)">' + F + '</g>' : F;
    return o; }

  function svg(pose, w, h) {
    if (!COAT) buildCoat();
    var o = '', walk = pose.walk != null, ph = walk ? pose.walk : 0, bob = walk ? Math.cos(ph * Math.PI * 4) * 1.6 : 0;
    /* the four feet: each planted for most of the stride (sliding back as the body moves on), then lifted and swung forward */
    var foot = function (off) { if (!walk) return [off === .25 || off === .75 ? 4 : -4, 0]; var t = (ph + off) % 1;
      if (t < STANCE) return [A - 2 * A * t / STANCE, 0]; var s = (t - STANCE) / (1 - STANCE), e = s * s * (3 - 2 * s); return [-A + 2 * A * e, Math.sin(s * Math.PI)]; };
    var lh = foot(0), lf = foot(.25), rh = foot(.5), rf = foot(.75);
    o += '<defs><linearGradient id="cwHorn" x1="0" y1="1" x2=".6" y2="0"><stop offset="0" stop-color="#bfa982"/><stop offset=".35" stop-color="#f4ead6"/><stop offset=".75" stop-color="#d9c6a2"/><stop offset=".92" stop-color="#7a6248"/><stop offset="1" stop-color="#2e2014"/></linearGradient>' +
      '<linearGradient id="cwHornF" x1="0" y1="1" x2=".6" y2="0"><stop offset="0" stop-color="#8e7c5e"/><stop offset=".4" stop-color="#c8b898"/><stop offset=".9" stop-color="#5a4834"/><stop offset="1" stop-color="#2a1c10"/></linearGradient>' +
      '<linearGradient id="cwHornS" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#cbb48c"/><stop offset=".4" stop-color="#f4ead6"/><stop offset=".8" stop-color="#d4c09a"/><stop offset=".95" stop-color="#5e4a34"/><stop offset="1" stop-color="#2a1c10"/></linearGradient>' +
      '<radialGradient id="cwN" cx=".8" cy=".45" r=".9"><stop offset="0" stop-color="#76605a"/><stop offset=".5" stop-color="#4e3a37"/><stop offset="1" stop-color="#2a1c1a"/></radialGradient>' +
      '<radialGradient id="cwNF" cx=".5" cy=".3" r=".8"><stop offset="0" stop-color="#937670"/><stop offset=".55" stop-color="#5a4440"/><stop offset="1" stop-color="#2c1e1c"/></radialGradient>' +
      '<linearGradient id="cwHd" x1="0" y1="0" x2=".3" y2="1"><stop offset="0" stop-color="' + col(.55) + '"/><stop offset="1" stop-color="' + col(.22) + '"/></linearGradient>' +
      '<linearGradient id="cwHdF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + col(.5) + '"/><stop offset="1" stop-color="' + col(.26) + '"/></linearGradient>' +
      '<linearGradient id="cwHoof" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2e2a"/><stop offset="1" stop-color="#0e0a08"/></linearGradient>' +
      '<radialGradient id="cwGr"><stop offset="0" stop-color="#000" stop-opacity=".45"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>' +
      '<filter id="cwSh" x="-5%" y="-5%" width="110%" height="115%"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="#0a0510" flood-opacity=".45"/></filter></defs>';
    /* a soft shadow on the ground */
    o += '<ellipse cx="225" cy="' + (FOOT + 1) + '" rx="190" ry="11" fill="url(#cwGr)"/>';
    o += '<g filter="url(#cwSh)"><g transform="translate(0 ' + f1(bob) + ')">';
    o += leg(96, 196, rh[0], rh[1], true, 11) + leg(318, 192, rf[0], rf[1], true, 12);
    /* tail, swinging as it walks, with a long tuft */
    var tw = walk ? Math.sin(ph * Math.PI * 2) * 6 : 2, TR = rng(5);
    o += '<path d="M60 96 C48 130 ' + f1(46 + tw) + ' 170 ' + f1(50 + tw) + ' 206" stroke="' + col(.3) + '" stroke-width="7" fill="none" stroke-linecap="round"/>';
    for (var i = 0; i < 18; i++) o += lock(50 + tw + (TR() - .5) * 8, 192 + TR() * 12, 92 + (TR() - .5) * 22, 24 + TR() * 16, 4, (TR() - .5) * 2.4, col(.4 + TR() * .4), TR() < .5 ? col(.9) : null);
    o += COAT;
    o += leg(108, 202, lh[0], lh[1], false, 13) + leg(304, 198, lf[0], lf[1], false, 14);
    o += HEM;
    var hd = walk ? Math.cos(ph * Math.PI * 4 + .8) * 1.8 : 0;
    o += '<g transform="translate(0 ' + f1(hd) + ')">' + (pose.front ? headFront(pose) : headSide(pose)) + '</g>';
    o += '</g></g>';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="' + VB.join(' ') + '">' + o + '</svg>'; }

  var POSES = []; for (var i = 0; i < 16; i++) POSES.push({ walk: i / 16 });
  POSES.push({ stand: 1 }, { front: 1 }, { front: 1, jaw: -1 }, { front: 1, jaw: 1 }, { front: 1, fringe: 1 }, { front: 1, blink: 1 });
  window.CowArt = { svg: svg, VB: VB, POSES: POSES, WALK: 16, FOOT: FOOT, STRIDE: 2 * A / STANCE };
})();

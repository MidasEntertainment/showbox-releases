/* Show Box licence: one signed key per park, checked on the Mac with no internet.
   - The key says which park it's for, which games and seasonal frames it covers, and when it ends:
       SBX1.<payload>.<signature>   payload = { v, id, product, park, client, games: 'all'|[ids], frames: 'all'|[ids], issued, expires, warnFrom?, graceUntil?, contact? }
     "Request this" goes to the client's administrator and tech manager, listed by client in the stats sheet (Clients tab), not in the key,
     so they can be changed or handed over without new keys (Karl 2026-11-03).
     It is signed with Karl's private key (kept in licence-tools/, never shipped); the Show Box only has the public half, so a key
     can't be made or changed here.
   - Stages:  ok  ->  soon (from warnFrom, default 30 days before the end: countdown on the dashboard and desk bar, never on the LED)
              ->  grace (only if the key has graceUntil: shows still load, red notice)  ->  ended (no new show can be loaded)
     A show that was loaded before the licence ended is never cut off: it carries on until the operator loads another show or quits.
   - A wound-back clock gains nothing: the licence counts from the latest time this Mac has ever been seen at.
   - No key at all: a build with requireKey off (Karl's test builds) runs everything; with requireKey on, nothing loads until a key is entered.
   Built so the same file works on Windows (plain Node, files in the app's data folder). */
const crypto = require('crypto'), fs = require('fs'), path = require('path');

const PUBLIC_KEY = 'MCowBQYDK2VwAyEAxcKBTDTHoQ+9erba1HobLeD/aGeefWKhDfyoXGgIshA=';
const DAY = 864e5, WARN_DAYS = 30, CLOCK_SLACK = 36 * 3600e3;
const b64d = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');

/* EntsOffice website keys (EO-XXXX-XXXX-XXXX-XXXX, added 2026-11-06 for Karl): one key per game, bought on entsoffice.com.
   A key is checked once online against the website's activate_licence function (which starts its 12 months the first time),
   then kept on the Mac and works offline until its end date. When online, keys are re-checked once a day so a cancelled
   or renewed licence shows up. Each website product unlocks one show; the seasonal frames unlock only while at least one active key is Silver or Gold, never Bronze (Karl 2026-11-06). */
const EO = { url: process.env.SHOWBOX_EO_URL || 'https://addqacpgtnnyepnvrwhp.supabase.co/rest/v1/rpc/activate_licence', anon: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFkZHFhY3BndG5ueWVwbnZyd2hwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM2MjMzMzIsImV4cCI6MjEwOTE5OTMzMn0.UlHryWqJBC2op3Pcqi3n2WaJ-6xFherlBNOjaTc-4cM' /* the website's public anon key: it can only call what the website lets anyone call */ };
const EO_SHOWS = [[/band.?bingo|singo/i, 'singo'], [/muiz|music quiz/i, 'muiz'], [/think you know me/i, 'think-you-know-me'], [/word.?up/i, 'word-up'], [/kidz|karaoke/i, 'kidz-karaoke']];
const eoNorm = t => String(t || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/^EO(.{4})(.{4})(.{4})(.{4})$/, 'EO-$1-$2-$3-$4');
const isEO = t => /^EO(-[A-HJ-NP-Z2-9]{4}){4}$/.test(eoNorm(t));
async function eoActivate(key, fetchFn) {
  const f = fetchFn || fetch; let r;
  try { r = await f(EO.url, { method: 'POST', headers: { apikey: EO.anon, Authorization: 'Bearer ' + EO.anon, 'Content-Type': 'application/json' }, body: JSON.stringify({ k: key }), signal: AbortSignal.timeout(15000) }); }
  catch (e) { return { ok: false, offline: true, error: 'This Mac can\'t reach EntsOffice to check the key. Connect it to the internet once, then try again. After that it works offline.' }; }
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) return { ok: false, error: (j && (j.message || j.hint)) || 'EntsOffice didn\'t accept this key (' + r.status + ').' };
  const row = Array.isArray(j) ? j[0] : j; if (!row) return { ok: false, error: 'That licence key isn\'t right. Check it and try again.' };
  const show = (EO_SHOWS.find(([re]) => re.test(row.product || '')) || [])[1] || null;
  return { ok: true, rec: { key, product: row.product, show, tier: row.tier, parks: row.parks, starts: row.starts_on, ends: row.ends_on, status: row.status, checked: Date.now() } };
}

function readKey(text, pub) {
  const k = String(text || '').replace(/\s+/g, '');
  const m = /^SBX1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(k);
  if (!m) return { ok: false, error: 'That doesn\'t look like a Show Box licence key. Copy the whole key, from SBX1 to the end.' };
  let good = false; try { good = crypto.verify(null, Buffer.from(m[1]), crypto.createPublicKey({ key: b64d(pub || PUBLIC_KEY), format: 'der', type: 'spki' }), b64d(m[2])); } catch (e) {}
  if (!good) return { ok: false, error: 'This key isn\'t valid. It may have been mistyped or changed. Copy it again from the email.' };
  let p; try { p = JSON.parse(b64d(m[1]).toString('utf8')); } catch (e) { return { ok: false, error: 'This key can\'t be read.' }; }
  if (p.v !== 1 || p.product !== 'showbox' || !Date.parse(p.expires)) return { ok: false, error: 'This key is for something else, or for a newer Show Box.' };
  return { ok: true, key: k, p };
}

function createLicence(o) {
  const DIR = path.join(o.dataDir, 'licence'), KEY = path.join(DIR, 'key.txt'), SEEN = path.join(DIR, 'seen.json'), ASKS = path.join(DIR, 'asks.json');
  try { fs.mkdirSync(DIR, { recursive: true }); } catch (e) {}
  const log = o.log || (() => {}), clock = o.now || (() => Date.now()), pub = o.publicKey || PUBLIC_KEY;
  let requireKey = !!o.requireKey;
  const save = (f, s) => { try { fs.writeFileSync(f + '.tmp', s); fs.renameSync(f + '.tmp', f); } catch (e) { log('licence save failed', String(e)); } };

  const EOF_ = path.join(DIR, 'eo-keys.json'); let eo = []; try { eo = JSON.parse(fs.readFileSync(EOF_, 'utf8')) || []; } catch (e) {}
  const saveEO = () => save(EOF_, JSON.stringify(eo, null, 1)), fetchFn = o.fetch;
  /* an EO key's last day counts to the end of that day */
  const eoEnd = r => Date.parse(r.ends + 'T23:59:59') || 0;
  const eoLive = t => eo.filter(r => r.status !== 'cancelled' && r.show && eoEnd(r) > t);
  let cur = null;   /* the installed key, read */
  try { const r = readKey(fs.readFileSync(KEY, 'utf8'), pub); if (r.ok) cur = r; else log('licence: stored key not valid:', r.error); } catch (e) {}
  /* the latest time this Mac has been seen at (so winding the clock back doesn't win time) */
  let seen = 0; try { seen = +JSON.parse(fs.readFileSync(SEEN, 'utf8')).t || 0; } catch (e) {}
  let seenSaved = seen, clockNoted = false;
  function now() {
    const t = clock();
    if (t > seen) seen = t;
    if (seen - seenSaved > 60000) { seenSaved = seen; save(SEEN, JSON.stringify({ t: seen })); }
    return Math.max(seen, cur ? Date.parse(cur.p.issued) || 0 : 0);
  }
  const tick = setInterval(now, 30000); tick.unref && tick.unref(); now();

  /* test keys (made with --test-minutes) count from when they're entered, so Karl can try the whole cycle whenever he likes */
  const STARTED = path.join(DIR, 'started.json'); let started = {}; try { started = JSON.parse(fs.readFileSync(STARTED, 'utf8')) || {}; } catch (e) {}
  function dates(p, t) {
    if (p.trial) { if (!started[p.id] && t != null) { started[p.id] = t; save(STARTED, JSON.stringify(started)); }
      const st = started[p.id] || t || Date.now(), M = 60000, end = Math.min(Date.parse(p.expires), st + (+p.trial.run || 10) * M);
      return { end, warn: end - (+p.trial.warn || 0) * M, grace: end + (+p.trial.grace || 0) * M }; }
    const end = Date.parse(p.expires);
    return { end, warn: Date.parse(p.warnFrom) || end - WARN_DAYS * DAY, grace: Date.parse(p.graceUntil) || end };
  }
  let asks = []; try { asks = JSON.parse(fs.readFileSync(ASKS, 'utf8')) || []; } catch (e) {}
  let granted = null;   /* the show loaded while the licence allowed it: it keeps running after the licence ends */

  function status() {
    const t = now(), back = seen - clock() > CLOCK_SLACK;
    if (back && !clockNoted) { clockNoted = true; log('licence: this Mac\'s clock is behind the latest time seen', new Date(clock()).toISOString(), '<', new Date(seen).toISOString()); }
    if (!back) clockNoted = false;
    const eoKeys = eo.map(r => ({ key: r.key, product: r.product, show: r.show, ends: r.ends, status: r.status })), live = eoLive(t);
    if (!cur && eo.length) {
      const ends = eo.filter(r => r.status !== 'cancelled' && r.show).map(eoEnd), end = ends.length ? Math.max.apply(null, ends) : t, warn = end - WARN_DAYS * DAY;
      const state = !live.length ? 'ended' : t < warn ? 'ok' : 'soon', left = Math.max(0, end - t);
      return { state, requireKey, clockBack: back, asks, eo: true, eoKeys, id: eo.map(r => r.key).join(', '), park: o.park ? o.park() : '', client: '', contact: 'EntsOffice',
        games: live.map(r => r.show), frames: live.some(r => /^(silver|gold)$/i.test(String(r.tier || '').trim())) ? 'all' : [], expires: new Date(end).toISOString(), warnFrom: new Date(warn).toISOString(), graceUntil: null, test: false, msLeft: left, daysLeft: Math.ceil(left / DAY) };
    }
    if (!cur) return { state: requireKey ? 'none' : 'open', requireKey, clockBack: back, asks, eoKeys };
    const p = cur.p, { end, warn, grace } = dates(p, t);
    const state = t < warn ? 'ok' : t < end ? 'soon' : t < grace ? 'grace' : 'ended';
    const left = Math.max(0, (state === 'grace' ? grace : end) - t);
    const games = p.games === 'all' || !live.length ? p.games : Array.from(new Set((p.games || []).concat(live.map(r => r.show))));
    return { state, requireKey, clockBack: back, asks, id: p.id, park: p.park, client: p.client || '', contact: p.contact || '', games, frames: p.frames,
      eoKeys, issued: p.issued, expires: new Date(end).toISOString(), warnFrom: new Date(warn).toISOString(), graceUntil: grace > end ? new Date(grace).toISOString() : null, test: !!p.trial, msLeft: left, daysLeft: Math.ceil(left / DAY) };
  }
  const covers = (list, id) => list === 'all' || (Array.isArray(list) && list.includes(id));
  /* can this game be loaded now? */
  function canLoad(show) {
    const s = status();
    if (s.state === 'open') return { ok: true };
    if (s.state === 'none') return { ok: false, why: 'nokey', text: 'Enter the Show Box licence key on the dashboard to load shows.' };
    if (s.state === 'ended') return { ok: false, why: 'ended', text: 'The Show Box licence has ended, so a new show can\'t be loaded. Contact us to renew.' };
    if (!covers(s.games, show)) { if (s.eo && eo.some(r => r.show === show)) return { ok: false, why: 'ended', text: 'The licence for this show has ended. Renew it on entsoffice.com.' };
      return { ok: false, why: 'package', text: 'This show isn\'t in your package.' }; }
    return { ok: true };
  }
  /* can its pages be opened? (the show that was already loaded keeps going after the licence ends) */
  const canServe = show => show === granted || canLoad(show).ok;
  function grant(show) { if (canLoad(show).ok) { granted = show; return true; } return false; }
  function frameOk(id) {
    const s = status();
    if (s.state === 'open') return true;
    if (s.state === 'none' || s.state === 'ended') return false;
    return covers(s.frames, id);
  }
  async function installEO(text) {
    const key = eoNorm(text), a = await eoActivate(key, fetchFn); if (!a.ok) return a;
    const rec = a.rec;
    if (rec.status === 'cancelled') return { ok: false, error: 'This licence has been cancelled. Contact EntsOffice.' };
    if (!rec.show) return { ok: false, error: `This key is for ${rec.product || 'a product'}, which this Show Box doesn't have.` };
    if (eoEnd(rec) <= now()) return { ok: false, error: `This licence ended on ${new Date(eoEnd(rec)).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}. Renew it on entsoffice.com.` };
    eo = eo.filter(r => r.key !== key && r.show !== rec.show).concat([rec]); saveEO();
    const had = asks.length; asks = asks.filter(x => !(x.kind === 'show' && x.id === rec.show)); if (asks.length !== had) save(ASKS, JSON.stringify(asks));
    log('EntsOffice key activated', key.slice(0, 7) + '…', rec.product, '->', rec.show, 'ends', rec.ends);
    return { ok: true, eo: rec, status: status() };
  }
  /* re-check the EO keys about once a day when online (a cancelled licence stops; a renewed one moves its end date). Offline: keep what we have. */
  async function recheckEO() {
    for (const r of eo.slice()) { if (Date.now() - (r.checked || 0) < 20 * 3600e3) continue;
      const a = await eoActivate(r.key, fetchFn); if (a.offline) return;
      if (a.ok) { Object.assign(r, a.rec); log('EntsOffice key re-checked', r.key.slice(0, 7) + '…', r.status, 'ends', r.ends); }
      else if (/isn't right|cancelled/i.test(a.error || '')) { r.status = 'cancelled'; r.checked = Date.now(); log('EntsOffice key no longer valid', r.key.slice(0, 7) + '…'); }
      saveEO(); } }
  if (eo.length && !o.noRecheck) { const rc = setInterval(() => recheckEO().catch(() => {}), 3600e3); rc.unref && rc.unref(); setTimeout(() => recheckEO().catch(() => {}), 20000).unref?.(); }
  function install(text) {
    if (isEO(text)) return installEO(text);
    const r = readKey(text, pub); if (!r.ok) return Object.assign(r, /^\s*EO/i.test(String(text)) ? { error: 'That doesn\'t look like a whole EntsOffice key. It looks like EO-XXXX-XXXX-XXXX-XXXX.' } : {});
    const t = now(), { end, grace } = dates(r.p, r.p.trial && !started[r.p.id] ? null : t);
    if (grace <= t) return { ok: false, error: `This key ended on ${new Date(end).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}. Ask us for a new one.` };
    cur = r; save(KEY, r.key + '\n'); dates(r.p, t);   /* a test key starts counting now */
    const had = asks.length; asks = asks.filter(x => !covers(x.kind === 'show' ? r.p.games : r.p.frames, x.id)); if (asks.length !== had) save(ASKS, JSON.stringify(asks));   /* requests the new key now covers are done */ log('licence key entered', r.p.id, r.p.park, 'games', r.p.games, 'frames', r.p.frames, 'ends', r.p.expires);
    return { ok: true, status: status() };
  }
  function remove(which) { if (which) { eo = eo.filter(r => r.key !== which); saveEO(); log('EntsOffice key removed', String(which).slice(0, 7) + '…'); return { ok: true, status: status() }; }
    if (cur) log('licence key removed', cur.p.id); cur = null; try { fs.unlinkSync(KEY); } catch (e) {} if (eo.length) { eo = []; saveEO(); } return { ok: true, status: status() }; }
  /* "Ask to add this": kept on the Mac, sent with the stats when it's next online */
  function ask(kind, id, title) {
    if (asks.some(a => a.kind === kind && a.id === id)) return asks;
    asks.push({ kind, id, title: String(title || id).slice(0, 60), at: new Date(clock()).toISOString() }); save(ASKS, JSON.stringify(asks));
    log('asked to add', kind, id); return asks;
  }
  return { keyText: () => cur ? cur.key : null, status, canLoad, canServe, grant, granted: () => granted, frameOk, install, remove, ask, setRequireKey: v => { requireKey = !!v; }, stop: () => clearInterval(tick) };
}
module.exports = { createLicence, readKey, PUBLIC_KEY, isEO, eoNorm, EO };

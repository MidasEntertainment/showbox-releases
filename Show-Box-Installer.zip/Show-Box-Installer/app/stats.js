/* Show Box stats: anonymous numbers about the shows, kept on the Mac and uploaded whenever it's online.
   - Games send one record when a game ends (or is abandoned): POST /api/stats [{ show, id, kind, start, end, completed, players, items, ... }]
     No names are ever stored: only counts, game settings and song or category titles.
   - Records live in <app data>/stats/records.jsonl. Each gets a sequence number; the uploader sends everything after the last one the sheet confirmed.
   - Upload, with nobody pressing anything: POST { install, park, client, version, records } to the stats sheet (a Google Sheet web app)
       * as soon as the Mac comes online (it checks every 15 minutes while it's offline, and 30 s after Show Box starts)
       * then once a week while it stays online
     Nothing is lost while it's offline: the next upload catches up.
   - The sheet address and key can be built into the installer (stats-defaults.json), so parks never type them.
   - Show reports: after a show, the desk asks the operator a few quick questions (see box/guard.js). Answers arrive as kind "report". */
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const ALLOWED = { show: 40, id: 60, kind: 20, role: 10, start: 0, end: 0, completed: 0, players: 0, phones: 0, items: 0, rounds: 0, theme: 60, mode: 30, size: 0, len: 10,
  paper: 0, demo: 0, song: 80, duet: 0, prizes: 0, version: 20,
  /* show report from the operator */
  game: 60, games: 0, minutes: 0, busy: 20, ages: 20, stayed: 20, left: 20, why: 160, crowd: 0, smooth: 0, tech: 160, notes: 400, skipped: 0,
  /* "Request this" from the dashboard: the sheet emails the client's administrator and tech manager (Clients tab), never us */
  client: 80, item: 80 };
const WEEK = 7 * 24 * 3600e3, NIGHT_GAP = 3600e3, REPORT_WINDOW = 12 * 3600e3, KARAOKE_IDLE = 20 * 60000;
const MAX_GAME_MIN = 180;

function createStats(o) {
  const DIR = path.join(o.dataDir, 'stats'), REC = path.join(DIR, 'records.jsonl'), CFG = path.join(DIR, 'config.json');
  try { fs.mkdirSync(DIR, { recursive: true }); } catch (e) {}
  const log = o.log || (() => {});
  let cfg = { install: '', park: '', client: '', uploadUrl: '', token: '', count: true, lastSentSeq: 0, lastUpload: null, lastError: '', offline: true };
  try { cfg = Object.assign(cfg, JSON.parse(fs.readFileSync(CFG, 'utf8'))); } catch (e) {}
  /* the stats sheet address and key, built into the installer by Karl so nobody at the park types them */
  try { const d = JSON.parse(fs.readFileSync(path.join(__dirname, 'stats-defaults.json'), 'utf8'));
    if (!cfg.uploadUrl && d.uploadUrl) cfg.uploadUrl = d.uploadUrl; if (!cfg.token && d.token) cfg.token = d.token; if (!cfg.client && d.client) cfg.client = d.client; } catch (e) {}
  if (!cfg.install) { cfg.install = 'sb-' + crypto.randomBytes(5).toString('hex'); }
  if (!cfg.park) cfg.park = o.defaultPark || '';
  const saveCfg = () => { try { fs.writeFileSync(CFG + '.tmp', JSON.stringify(cfg, null, 1)); fs.renameSync(CFG + '.tmp', CFG); } catch (e) { log('stats config save failed', String(e)); } };
  saveCfg();

  /* load records: last copy of each id wins */
  let seq = 0; const byId = new Map();
  try { for (const line of fs.readFileSync(REC, 'utf8').split('\n')) { if (!line) continue; try { const r = JSON.parse(line); seq = Math.max(seq, r.seq || 0); byId.set(r.show + '|' + r.id, r); } catch (e) {} } } catch (e) {}

  function clean(r) {
    const out = {};
    for (const [k, max] of Object.entries(ALLOWED)) {
      if (!(k in r)) continue; const v = r[k];
      if (typeof v === 'number' && isFinite(v)) out[k] = v;
      else if (typeof v === 'boolean') out[k] = v;
      else if (typeof v === 'string' && max) out[k] = v.slice(0, max);
    }
    return out;
  }
  function add(list) {
    let n = 0; const lines = [];
    for (const raw of [].concat(list).slice(0, 500)) {
      if (!raw || typeof raw !== 'object') continue;
      const r = clean(raw); if (!r.show || !r.id || !r.start || !r.end) continue;
      if (!cfg.count && r.kind !== 'request') continue;   /* stats switched off; requests still go */
      const key = r.show + '|' + r.id, old = byId.get(key);
      if (old && JSON.stringify(Object.assign({}, old, { seq: 0, at: 0 })) === JSON.stringify(Object.assign({}, r, { seq: 0, at: 0, park: old.park }))) continue; /* same record sent twice */
      r.seq = ++seq; r.at = Date.now(); r.park = cfg.park;
      byId.set(key, r); lines.push(JSON.stringify(r)); n++;
    }
    if (lines.length) { try { fs.appendFileSync(REC, lines.join('\n') + '\n'); } catch (e) { log('stats save failed', String(e)); } }
    return n;
  }
  const records = () => [...byId.values()].sort((a, b) => a.seq - b.seq);
  const minutesOf = r => Math.max(0, Math.min(MAX_GAME_MIN, (r.end - r.start) / 60000));
  /* what counts: real games (no demo teams) that finished, or ran at least 3 minutes */
  const counts = r => r.kind !== 'report' && !r.demo && (r.completed || minutesOf(r) >= 3);

  function summary() {
    const all = records().filter(counts), per = {};
    const t = { games: 0, minutes: 0, players: 0, phones: 0, songs: 0, shows: 0 };
    for (const r of all) {
      const s = per[r.show] || (per[r.show] = { games: 0, minutes: 0, players: 0, phones: 0, items: 0 });
      s.games++; s.minutes += minutesOf(r); s.players += r.players || 0; s.phones += r.phones || 0; s.items += r.items || 0;
      if (r.kind !== 'performance') t.games++; t.minutes += minutesOf(r); t.players += r.players || 0; t.phones += r.phones || 0;
      if (r.show === 'singo' || r.show === 'kidz-karaoke') t.songs += r.show === 'kidz-karaoke' ? 1 : (r.items || 0);
    }
    /* a "show" = a night's run of games: activity with no gap longer than an hour */
    const times = all.map(r => [r.start, r.end]).sort((a, b) => a[0] - b[0]); let lastEnd = 0;
    for (const [s, e] of times) { if (s - lastEnd > 3600e3) t.shows++; lastEnd = Math.max(lastEnd, e); }
    t.minutes = Math.round(t.minutes); for (const s of Object.values(per)) s.minutes = Math.round(s.minutes);
    const reps = records().filter(r => r.kind === 'report' && !r.skipped), scored = reps.filter(r => r.crowd > 0);
    t.reports = reps.length; t.crowdScore = scored.length ? Math.round(scored.reduce((a, r) => a + r.crowd, 0) / scored.length * 10) / 10 : null;
    return { park: cfg.park, client: cfg.client, install: cfg.install, totals: t, byShow: per, recorded: byId.size, first: all[0] ? new Date(all[0].start).toISOString() : null,
      upload: { url: cfg.uploadUrl ? cfg.uploadUrl.replace(/(\/s\/.{6}).*(\/exec)?$/, '$1…') : '', waiting: records().filter(r => r.seq > cfg.lastSentSeq).length, last: cfg.lastUpload, error: cfg.lastError, online: !cfg.offline,
      next: cfg.offline ? 'as soon as the Mac is online' : cfg.lastUpload ? new Date(Date.parse(cfg.lastUpload) + WEEK).toISOString() : 'soon' }, counting: cfg.count };
  }
  function csv() {
    const cols = ['park', 'show', 'kind', 'id', 'startISO', 'endISO', 'minutes', 'completed', 'players', 'phones', 'items', 'rounds', 'theme', 'mode', 'size', 'len', 'paper', 'song', 'duet', 'demo'];
    const q = v => v == null ? '' : /[",\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : String(v);
    return [cols.join(',')].concat(records().map(r => cols.map(c => q(c === 'startISO' ? new Date(r.start).toISOString() : c === 'endISO' ? new Date(r.end).toISOString() : c === 'minutes' ? minutesOf(r).toFixed(1) : r[c])).join(','))).join('\n') + '\n';
  }
  /* Is a show report waiting for the operator? One per show per night: after a game finishes,
     or for Kidz Karaoke once 3+ songs have been sung and nothing has played for 20 minutes. */
  function reportDue(show, now = Date.now()) {
    if (!cfg.count) return null;
    const mine = records().filter(r => r.show === show && r.end > now - REPORT_WINDOW);
    const plays = mine.filter(counts).sort((a, b) => a.start - b.start); if (!plays.length) return null;
    let nightStart = plays[plays.length - 1].start;
    for (let i = plays.length - 1; i > 0; i--) { if (plays[i].start - plays[i - 1].end > NIGHT_GAP) break; nightStart = plays[i - 1].start; }
    const night = plays.filter(r => r.start >= nightStart), last = night[night.length - 1];
    if (mine.some(r => r.kind === 'report' && r.end >= nightStart)) return null;
    if (show === 'kidz-karaoke') { if (night.length < 3 || now - last.end < KARAOKE_IDLE) return null; }
    else if (!night.some(r => r.completed)) return null;
    return { id: 'rep-' + show + '-' + nightStart.toString(36), show, start: nightStart, end: last.end, games: night.length,
      minutes: Math.round(night.reduce((a, r) => a + minutesOf(r), 0)), players: night.reduce((a, r) => Math.max(a, r.players || 0), 0), phones: night.reduce((a, r) => Math.max(a, r.phones || 0), 0) };
  }
  function setConfig(b) {
    if (typeof b.park === 'string') cfg.park = b.park.trim().slice(0, 60);
    if (typeof b.client === 'string') cfg.client = b.client.trim().slice(0, 60);
    if (typeof b.uploadUrl === 'string') { const u = b.uploadUrl.trim(); if (!u || /^https:\/\//.test(u) || /^http:\/\/127\.0\.0\.1[:/]/.test(u)) { if (u !== cfg.uploadUrl) { cfg.lastError = ''; cfg.offline = true; } cfg.uploadUrl = u; } }
    if (typeof b.token === 'string') cfg.token = b.token.trim().slice(0, 100);
    if (typeof b.count === 'boolean') cfg.count = b.count;
    saveCfg(); return summary();
  }
  function clear() { byId.clear(); try { fs.renameSync(REC, REC + '.cleared-' + Date.now()); } catch (e) {} cfg.lastSentSeq = seq; saveCfg(); }

  /* ---------- upload ---------- */
  let busy = false;
  /* checked every 15 minutes: send when the Mac has just come online, or a week after the last upload */
  function tick() {
    if (!cfg.uploadUrl) return;
    const last = cfg.lastUpload ? Date.parse(cfg.lastUpload) : 0;
    if (cfg.offline || !last || Date.now() - last >= WEEK) upload('auto');
  }
  async function upload(why) {
    if (busy || !cfg.uploadUrl) return { ok: false, why: cfg.uploadUrl ? 'busy' : 'no upload address set' };
    const waiting = records().filter(r => r.seq > cfg.lastSentSeq);
    busy = true;
    try {
      for (let i = 0; i < Math.max(1, waiting.length); i += 300) {
        const batch = waiting.slice(i, i + 300);
        const body = JSON.stringify({ token: cfg.token, install: cfg.install, park: cfg.park, client: cfg.client, version: o.version, sentAt: new Date().toISOString(), records: batch });
        const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 30000);
        let res, text;
        try { res = await fetch(cfg.uploadUrl, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body, redirect: 'follow', signal: ctl.signal }); text = await res.text(); }
        finally { clearTimeout(to); }
        let reply = null; try { reply = JSON.parse(text); } catch (e) {}
        if (!res.ok || !reply || !reply.ok) throw new Error(reply && reply.error ? reply.error : 'the sheet said ' + res.status);
        if (batch.length) cfg.lastSentSeq = batch[batch.length - 1].seq;
        cfg.lastUpload = new Date().toISOString(); cfg.lastError = ''; cfg.offline = false; saveCfg();
      }
      log('stats uploaded', waiting.length, 'records', why || '');
      return { ok: true, sent: waiting.length };
    } catch (e) {
      const msg = e.name === 'AbortError' ? 'timed out' : String(e.message || e);
      /* being offline is normal at the parks: only note it, try again later */
      if (cfg.lastError !== msg) log('stats upload failed:', msg);
      cfg.lastError = msg; cfg.offline = true; saveCfg(); return { ok: false, why: msg };
    } finally { busy = false; }
  }
  const timers = [setTimeout(tick, o.firstUploadMs || 30000), setInterval(tick, o.uploadEveryMs || 15 * 60000)];
  timers.forEach(t => t.unref && t.unref());

  return { add, summary, csv, setConfig, clear, upload, tick, reportDue, config: () => cfg, stop: () => timers.forEach(t => { clearTimeout(t); clearInterval(t); }) };
}
module.exports = { createStats };

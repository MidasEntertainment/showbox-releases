# Seasonal frames

A seasonal frame is a see-through layer the Show Box lays over everything on the stage screen: our games, QLab, videos, slides.
It never takes a click or the keyboard, and the operator turns it on or off from the "Frame" button on the desk (Mac or iPad) or the Frame menu.
The choice is remembered, so it comes back after a restart.

## Making a frame
Each frame is a folder in `app/frames/` (comes with the app). Later, seasonal content updates will drop folders into the Mac's app data `frames/` folder, which wins over the app's copy.

    frames/<id>/            id: lowercase letters, numbers and dashes, e.g. halloween-webs
      frame.json            {"name": "Halloween: cobwebs, spider and ghosts", "animations": "Spider and ghosts"}
                            name: what the operator sees (text before ":" shows on the desk button)
                            animations (code frames only): if set, the desk shows an on/off switch with this label. Off keeps the still parts
                            (cobwebs) and stops the moving ones. On by default; the Show Box calls showboxFrameAnim(true|false) in the page.
      and ONE of (Karl 2026-11-02: every frame is animated, no still pictures; PNG only as a stopgap):
      frame.png             still frame: 1920x1080 PNG with a transparent middle (stretched to the screen)
      frame.webm            animated frame from a video editor: VP9 WebM with an alpha channel (After Effects / Premiere via a WebM plug-in, or ffmpeg)
      frame.mov             animated frame: HEVC with alpha (Apple Compressor / Final Cut "HEVC 8-bit with alpha"), Mac only
      index.html            animated frame drawn in code, transparent background (see halloween-webs)

Every frame has: a border that is always there, a small moment every couple of minutes, and a big moment every 4 to 7 minutes
with 3 or 4 versions so it's different each time. The operator's switch turns the moments off and keeps the border.
The list of seasons and themes to make: https://claude.ai/artifact/FL4yVZduY6XzmpMV9EK9re

Tips: keep artwork to the outer 15% of the screen so lyrics, scores and QR codes stay clear. Make sure edges read on both dark and bright content (a soft dark outline helps).
Videos loop forever, so make the loop seamless. A long gap where nothing moves keeps the Mac cool while QLab runs.

## Included
- `halloween-webs`: cobwebs in the corners and along the top (always on). Animations, on by default, switchable on the desk ("Spider, ghosts and skeletons"):
  every couple of minutes (randomised) a spider crawls in from a corner or side onto a different web than last time, drops on its thread, dangles, climbs back and crawls off;
  every 4 to 7 minutes one of 5 (each once before any repeats): a loop-the-loop in from the right; a bobbing glide in from the left;
  ghosts rise from the bottom and one stops and lets off a green fart that hangs about then blows away; a chase (one darts in, stops, zooms off as the others chase it);
  a friendly cartoon skeleton (or two) leans in from a side or pops up near a bottom corner, waves at the room, looks round and ducks away. Ghosts always face the front (no tilting or turning). Code only, no video.
- `valentines-hearts`: hearts along the top and part way down the sides (none along the bottom), soft pink glow. Animations ("Balloons and paper planes"):
  one or two heart balloons in the frame itself (no strings) slowly fill up over 30 to 50 seconds and pop into little hearts; every couple of minutes heart balloons float up from the bottom;
  every 4 to 7 minutes one of 4: a paper plane loops across leaving hearts, a paper plane draws a big heart, heart cannons from the bottom corners, a gentle shower of hearts.
- `bonfire-night`: gold, orange and pink sparkle stars along the top and the top of each side, a still firework in each top corner, slow gentle twinkle. Animations ("Sparklers and fireworks"):
  every couple of minutes a sparkler writes a loop, spiral or heart in a top corner and leaves a fading glowing trail;
  every 4 to 7 minutes one of 4: a rocket volley from the bottom corners bursting across the top third, one big burst with falling gold willow,
  a Catherine wheel spinning in a top corner, gold fountains from both bottom corners. Silent; no full-screen flash; bursts are at least a third of a second apart.
- `christmas`: a realistic pine garland (hundreds of needles, dusted with snow) swagged along the top and down the sides, warm-white fairy lights that each twinkle slowly
  at their own random pace, glass baubles, red velvet bows, pine cones and holly in the top corners. Animations ("Snow, baubles, Santa, snowman and frost"): light snow down the sides;
  every couple of minutes a ripple of light runs along the garland and one bauble swings; every 4 to 7 minutes one of 4: a snowman pops up in a bottom corner and waves,
  Santa's sleigh and eight galloping reindeer cross a full moon in silhouette with a gold rim of light and a trail of magic dust, a swirl of snow, ice-fern frost from the bottom corners.
- `new-year`: black and gold: three strands of gold and black beads along the top with faceted gold stars, three glossy black and gold balloons in each top corner.
  Animations ("Shimmer, confetti, balloon drop and fireworks"): the balloons bob and a shimmer slides across one every few seconds; every couple of minutes gold and silver foil confetti;
  every 4 to 7 minutes one of 3: a black and gold balloon drop, a fireworks display (peony, chrysanthemum, ring, crackle, glitter, willow), a golden finale of willows. No drinks.

## Frame kit
New code frames are built on `app/box/frame-kit.js` (loaded with `<script src="/box/frame-kit.js">`): the frame gives `draw` (the border),
`small`, `bigs` (list) and optional `ambient`; the kit does the timing, the shuffled order of big moments, the operator's on/off switch and the test hooks
(`__small()`, `__big(i)`). See `frames/bonfire-night/index.html`.
Put anything that moves all the time on `k.over` (its own layer) and set `bake: true` so the border is turned into a plain picture once:
Realistic fireworks: `<script src="/box/fireworks.js"></script>`, then `Fireworks(k).launch({x, y, type, cols})` (see new-year).
Measured in testing, an SVG drop shadow in a live border dropped the frame rate from 60 to 20 frames a second. Plain web code, so it works the same on a future Windows Show Box.

#!/bin/bash
# Installs (or updates) Show Box on this Mac.
# Run it from Terminal:  bash ~/Downloads/Show-Box-Installer/install.sh
# It downloads the app engine (Electron, about 100 MB) from GitHub once, then builds
# "Show Box" in Applications from the files in this folder. Saved lyric timings are kept.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
EV=33.4.11
ARCH="$(uname -m)"; [ "$ARCH" = "arm64" ] || ARCH="x64"

say(){ printf '\n\033[1m%s\033[0m\n' "$1"; }

if [ ! -f "$HERE/app/main.js" ]; then echo "Can't find the app files next to this script. Unzip the installer first."; exit 1; fi

APPS="/Applications"; [ -w "$APPS" ] || { APPS="$HOME/Applications"; mkdir -p "$APPS"; }
DEST="$APPS/Show Box.app"
CACHE="$HOME/Library/Caches/ShowBox"; mkdir -p "$CACHE"
ZIP="$CACHE/electron-v$EV-darwin-$ARCH.zip"

if [ ! -s "$ZIP" ]; then
  say "Downloading the app engine (about 100 MB, first time only)…"
  curl -fL --progress-bar -o "$ZIP.part" "https://github.com/electron/electron/releases/download/v$EV/electron-v$EV-darwin-$ARCH.zip"
  mv "$ZIP.part" "$ZIP"
fi

say "Building Show Box…"
osascript -e 'tell application "Show Box" to quit' >/dev/null 2>&1 || true
sleep 1
TMP="$(mktemp -d)"
ditto -x -k "$ZIP" "$TMP"
rm -rf "$DEST"
mv "$TMP/Electron.app" "$DEST"
rm -rf "$TMP"
RES="$DEST/Contents/Resources"
rm -f "$RES/default_app.asar"
ditto "$HERE/app" "$RES/app"

# name and icon
PL="$DEST/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleName Show Box" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Show Box" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string Show Box" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier com.mytheatreschool.showbox" "$PL"
if [ -f "$HERE/app/icon.png" ]; then
  IS="$(mktemp -d)/ShowBox.iconset"; mkdir -p "$IS"
  for s in 16 32 128 256 512; do
    sips -z $s $s "$HERE/app/icon.png" --out "$IS/icon_${s}x${s}.png" >/dev/null
    sips -z $((s*2)) $((s*2)) "$HERE/app/icon.png" --out "$IS/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns "$IS" -o "$RES/electron.icns" 2>/dev/null || true
fi

# let it run on this Mac without the "unidentified developer" warning
xattr -cr "$DEST" 2>/dev/null || true
codesign --force --deep --sign - "$DEST" >/dev/null 2>&1 || true
touch "$DEST"

# a shortcut on the Desktop
ln -sfn "$DEST" "$HOME/Desktop/Show Box" 2>/dev/null || true

say "Show Box is installed in $APPS. Opening it now…"
echo "If the Mac asks whether Show Box may accept incoming network connections, click Allow (that's how the iPad connects)."
open "$DEST"
